package Physics;

import Systems.Point3D;

public class PhysicsObject3D extends PhysicsObject2D{
	public double Zo =0;
	public double Vzo =0;
	public double Azo =0;
	public Point3D prevPoint;
	public Vector3D prevVelocity;
	public double netForceZ = 0;
	public PhysicsObject3D(double mass,double Xo, double Vxo, double Axo, double Yo, double Vyo, double Ayo,double Zo, double Vzo, double Azo) {
		super(mass,Xo, Vxo, Axo, Yo, Vyo, Ayo);
		this.Zo=Zo;
		this.Vzo=Vzo;
		this.Azo=Azo;
		prevPoint = new Point3D(0,0,0);
		prevPoint.setLocation(Xo, Yo, Zo);
		prevVelocity=new Vector3D(Vxo,Vyo,Vzo);
		
	}
	public PhysicsObject3D() {
		super();
		prevPoint = new Point3D(0,0,0);
		prevPoint.setLocation(Xo, Yo, Zo);
		prevVelocity=new Vector3D(Vxo,Vyo,Vzo);
	}
	public PhysicsObject3D(double mass) {
		super(mass);
		prevPoint = new Point3D(0,0,0);
		prevPoint.setLocation(Xo, Yo, Zo);
		prevVelocity=new Vector3D(Vxo,Vyo,Vzo);
	}
	public void addForceZ(double Fz) {
		netForceZ+=Fz;
	}
	public void removeForceZ(double Fz) {
		netForceZ-=Fz;
	}
	public double calcAz() {
		Azo=netForceZ/mass;
		return Azo;
	}
	public void resetNet() {
		netForceX = 0;
		netForceY = 0;
		netForceZ = 0;
	}
	
	public Point3D runTime3D(double t) {
		Point3D out = new Point3D();
		out.setLocation(Xo+(Vxo*t)+((Axo/2)*(t*t)),Yo+(Vyo*t)+((Ayo/2)*(t*t)),Zo+(Vzo*t)+((Azo/2)*(t*t)));
		prevPoint=out;
		prevVelocity=new  Vector3D(Vxo+Axo*t,Vyo+Ayo*t,Vzo+Azo*t);
		return out;
	}
	public Point3D runNextTime3D(double t) {
		
		prevPoint.translate((prevVelocity.x*t)+((Axo/2)*(t*t)),(prevVelocity.y*t)+((Ayo/2)*(t*t)),(prevVelocity.z*t)+((Azo/2)*(t*t)));

		prevVelocity=prevVelocity.translate(Axo*t,Ayo*t,Azo*t);
		return prevPoint;
	}
	public void addVelVector(Vector3D V) {
		prevVelocity=prevVelocity.translate(V.x, V.y, V.z);
	}
	public void mulVelVector(Vector3D V) {
		prevVelocity=prevVelocity.mul(V.x, V.y, V.z);
	}
	public void divVelVector(Vector3D V) {
		prevVelocity=prevVelocity.div(V.x, V.y, V.z);
	}
	public void addForce(double Fx, double Fy, double Fz) {
		addForceX(Fx);
		addForceY(Fy);
		addForceZ(Fz);
		
	}
	public void calcA() {
		calcAx();
		calcAy();
		calcAz();
		
		
	}

	
	
}
