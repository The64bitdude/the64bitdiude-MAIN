package Physics;

public class PhysicsSystem {
	public PhysicsObject3D[][][] objects;
	public PhysicsSystem(int limitX,int limitY,int limitZ) {
		objects = new PhysicsObject3D[limitX][limitY][limitZ];
	}
	public PhysicsObject3D TorDia() {
		PhysicsObject3D TOR = new PhysicsObject3D();
		for(PhysicsObject3D[][] x:objects) {
			for(PhysicsObject3D[] y:x) {
				for(PhysicsObject3D z:y) {
					if(z!=null) {
						TOR.mass+=z.mass;
						TOR.addForce(z.netForceX,z.netForceY,z.netForceZ);
					}
				}
			}
		}
		return TOR;
		
	}
}
