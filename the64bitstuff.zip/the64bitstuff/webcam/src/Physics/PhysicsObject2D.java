package Physics;

public class PhysicsObject2D extends PhysicsObject{
	public double Yo =0;
	public double Vyo =0;
	public double Ayo =0;
	public double netForceY = 0;
	public PhysicsObject2D(double mass,double Xo, double Vxo, double Axo,double Yo, double Vyo, double Ayo) {
		super(mass,Xo, Vxo, Axo);
		this.Yo=Yo;
		this.Vyo=Vyo;
		this.Ayo=Ayo;
		
	}
	public PhysicsObject2D() {
		super();
	}
	public PhysicsObject2D(double mass) {
		super(mass);
	}
	public void addForceY(double Fy) {
		netForceY+=Fy;
	}
	public void removeForcey(double Fy) {
		netForceY-=Fy;
	}
	public void addForce(double Fx, double Fy) {
		addForceX(Fx);
		addForceY(Fy);

		
	}
	public void calcA() {
		calcAx();
		calcAy();
	
		
		
	}
	public void resetNet() {
		netForceX = 0;
		netForceY = 0;

	}
	public double calcAy() {
		Ayo=netForceY/mass;
		return Ayo;
		
	}
	public Point2D runTime2D(double t) {
		return new Point2D(Xo+(Vxo*t)+((Axo/2)*(t*t)),Yo+(Vyo*t)+((Ayo/2)*(t*t)));
	}
}
