package webcam;

public class WebCamera {

}
