package customlists;

public class Value<a,b,c> {
	public a valuea;
	public b valueb;
	public c valuec;
	public Value( a valuea,b valueb,c valuec) {
	
		this.valuea = valuea;
		this.valueb= valueb;
		this.valuec = valuec;
		
	}

}
