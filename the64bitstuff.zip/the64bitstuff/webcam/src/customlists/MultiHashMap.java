package customlists;

import java.util.ArrayList;

public class MultiHashMap<a,b,c,d> {
	ArrayList<Value<b,c,d>> values;
	
	public ArrayList<Value<b,c,d>> getValues(){
		return values;
	}
	
	public MultiHashMap(){
		values = new ArrayList<Value<b,c,d>>();
	}
	public int size() {
		return values.size();
	}
	public void put(a key,b value,c value2,d value3) {
		if(contains(key)){
			values.set(key.hashCode(),new Value<b,c,d>(value,value2,value3));
		}else {
		values.add(key.hashCode(),new Value<b,c,d>(value,value2,value3));
		}
	}
	public void puta(a key,b value) {
		if(contains(key)){
			values.set(key.hashCode(),new Value<b,c,d>(value,null,null));
		}else {
		values.add(key.hashCode(),new Value<b,c,d>(value,null,null));
		}
	}
	public void putb(a key,c value2) {
		if(contains(key)){
			values.set(key.hashCode(),new Value<b,c,d>(null,value2,null));
		}else {
		values.add(key.hashCode(),new Value<b,c,d>(null,value2,null));
		}
	}
	public void putc(a key,d value3) {
		if(contains(key)){
			values.set(key.hashCode(),new Value<b,c,d>(null,null,value3));
		}else {
		values.add(key.hashCode(),new Value<b,c,d>(null,null,value3));
		}
	}
	public boolean contains(a key) {
	
			return values.get(key.hashCode())!=null;	
		
	}
	public b getA(a key){
		return values.get(key.hashCode()).valuea;
	}
	public c getB(a key){
		return values.get(key.hashCode()).valueb;
	}
	public d getC(a key){
		return values.get(key.hashCode()).valuec;
	}

	public  boolean containsA(a key) {
		return values.get(key.hashCode()).valuea!=null;
	}
	public boolean containsB(a key) {
	return values.get(key.hashCode()).valueb!=null;
	}
	public boolean containsC(a key) {
	return values.get(key.hashCode()).valuec!=null;
	}
	public int containsWhich(a key) {
		int val = 0;
		int index =-1;
		val+=values.get(key.hashCode()).valuea!=null?1:0;
		if(val==1) {
			index = 0;
		}
		val+=values.get(key.hashCode()).valueb!=null?1:0;
		if(val==1) {
			index = 1;
		}
		val+=values.get(key.hashCode()).valuec!=null?1:0;
		if(val==1) {
			index = 2;
		}
		return index;
		
		
	}
	
}
