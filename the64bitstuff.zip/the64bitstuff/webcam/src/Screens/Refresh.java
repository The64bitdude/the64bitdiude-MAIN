package Screens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
 * 
 * @author  The64BitDude
 * @param sw is screenWidth
 * @param sh is screenHeight
 * @param c is the backround color
 * @param fps screen frames per second
 * @see #RefreshScreen(int, int, Color, int, int)
 * @see #RefreshScreen(int, int, Color, int)
 */

public abstract class Refresh implements Runnable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2395064685927837674L;
	/**
	 * The thread of this screen
	 * @author  The64BitDude
	 */
	public Thread T;
	
	/**
	 * set frames per second of the current screen
	 * @author  The64BitDude
	 */
	public int FPS;
	/**
	 * current frames per second of the current screen
	 * @author  The64BitDude
	 */
	public float currentFPS = 0;
	
	/**
	 * This refreshes at {@code fps} times per second
	 * 
	 * @author  The64BitDude
	 * @see #RefreshScreen(int)
	 */
	public Refresh() {
		FPS = 60;
		Start();
	}
	/**
	 * This refreshes at {@code fps} times per second
	 * 
	 * @author  The64BitDude
	 * @param fps screen frames per second
	 * @see #RefreshScreen()
	 */
	public Refresh(int fps) {
		FPS = fps;
		Start();
	}

	/**
	 * used to update values in your code every frame
	 * @author  The64BitDude
	 */
	public abstract void update();
	/**
	 * uses {@link Graphics} to update this frame's graphics every frame
	 * 
	 * @author  The64BitDude
	 * @param g is the {@link Graphics} of this frame and is updated every frame
	 */
	
	public void run() {
		initialize();
	
	long atime = System.nanoTime();
	long btime = atime;
	long dtime=((long) (1000000000f/FPS));
	while(T!=null) {
		btime = System.nanoTime();
		long tdif = (btime-atime);
		if(tdif>=dtime) {
			currentFPS = Math.round((1000000000f/tdif));
			atime = System.nanoTime();
			update();
			
		
		}
	}
		
	}
	/**
	 * used to initalize values that do not update every frame before you start updating
	 * @author  The64BitDude
	 */
	public abstract void initialize();
	
	public void Start() {
		T = new Thread(this);
		T.start();
	}
	
	

	
}
