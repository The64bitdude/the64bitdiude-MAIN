package Screens;

import java.awt.Color;
import java.awt.Graphics;
import java.net.UnknownHostException;

import javax.swing.JFrame;

import dataServer2.ConnectionManager;

public abstract class RefreshScreenConnection extends RefreshScreen {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ConnectionManager connectionManager;
	
	public RefreshScreenConnection(int sw, int sh, Color c, int fps) throws UnknownHostException {
		super(sw,sh,c,fps);
		// TODO Auto-generated constructor stub
	}

	public RefreshScreenConnection(int sw, int sh, Color c, int fps, int type) throws UnknownHostException {
		super(sw, sh, c, fps, type);
		
	}
	public void setScreen(RefreshScreen refreshScreen,JFrame frame) {
		try {
			connectionManager=new ConnectionManager(0) {
				
				@Override
				public void Message(String s) {
					StringDataEvent(s);
					
				}

				@Override
				public void Data(byte[] data) {
					byteDataEvent(data);
					
				}
				
			};
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setScreen(this,frame);
	}
	public abstract void setScreen(RefreshScreenConnection refreshScreen,JFrame frame);
	
	public abstract void StringDataEvent(String s);
	
	public abstract void byteDataEvent(byte[] data);

	
	
	
	

}
