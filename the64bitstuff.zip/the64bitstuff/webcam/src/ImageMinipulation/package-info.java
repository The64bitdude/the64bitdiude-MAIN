/**
 * 
 */
/**
 * @author s214714
 *
 */
package ImageMinipulation;