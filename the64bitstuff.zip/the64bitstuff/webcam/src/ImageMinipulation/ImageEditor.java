package ImageMinipulation;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ImageEditor {
	public BufferedImage img;
	public ImageEditor() {
		// TODO Auto-generated constructor stub
	}
	public ImageEditor(BufferedImage read) {
	this.img = read;
	}
	public BufferedImage fillPolygon(Polygon p,ImageObserver o,int start) {

		BufferedImage out = new BufferedImage(img.getWidth(),img.getHeight(), 2);
		ArrayList<Point> ps = new ArrayList<Point>();
		for(int i = 0;i<p.npoints;i++) {
			ps.add(new Point(p.xpoints[i],p.ypoints[i]));
		}
		
		ps.sort(new Comparator<Point>() {
			Point Ori = new Point(p.getBoundingBox().x,p.getBoundingBox().y);
			Point Ori2 = new Point((int)(p.getBoundingBox().getMaxX()),(int) p.getBoundingBox().getMaxY());
			@Override
			public int compare(Point o1, Point o2) {
				if(o1.distance(Ori)>o2.distance(Ori)) {
					return 1;
				}
				if(o1.distance(Ori2)>o2.distance(Ori2)) {
					return -1;
				}
				return 0;
			}
			
		});
		Point leftTop = ps.get(0);
		Point rightBottom = ps.get(3);
		Point leftBottom;
		Point rightTop;
		if(ps.get(2).y>ps.get(1).y) {
		leftBottom = ps.get(2);
		rightTop = ps.get(1);
		}else {
			 leftBottom = ps.get(1);
			rightTop = ps.get(2);
		}
		ps.clear();



double Width = 0;
try {
	Width =rightTop.x-leftTop.x;
}catch(Exception e) {
	
}
double Height = 0;
try {
Height =  leftBottom.y-leftTop.y ;
}catch(Exception e) {
	
}
double scaleX =0;
try {
	scaleX = img.getWidth()/Width;
}catch(Exception e) {
	
}
double scaleY =0;
try {
	scaleY= img.getHeight()/Math.abs(Height);
}catch(Exception e) {
	
}
double sy = 0;
try {
	
sy = (leftTop.y-rightTop.y)/(1.0*(rightTop.x-leftTop.x));
}catch(Exception e) {
	
}
double sx = 0;
try {
sx=((leftTop.x-leftBottom.x))/(1.0*(leftBottom.y-leftTop.y));
}catch(Exception e) {
	
}
for(int w = 0;w<Width;w++) {
	
	for(int h = 0;h<Math.abs(Height);h++) {
		try {
		out.setRGB((int) (w-h*sx+leftTop.x),(int) (h-w*sy)+leftTop.y,img.getRGB((int)(w*scaleX), (int) (h*scaleY)));
		}catch(Exception e) {
			
		}
		}
	
}
		Graphics2D g = out.createGraphics();

	//g.drawImage(img,ps.get(0).x,ps.get(0).y, (int)Width, (int)Math.abs(Height), o);

	g.draw(p);
	

		return out;
		
	}
	public BufferedImage fillPolygon(BufferedImage img,Polygon p) {
		BufferedImage out = new BufferedImage(img.getWidth(),img.getHeight(), 2);
		
		return out;
		
	}
	public BufferedImage darken(BufferedImage img,double percent) {
		BufferedImage out = new BufferedImage(img.getWidth(),img.getHeight(), 2);
		for(int y = 0;y<img.getHeight();y++) {
			for(int x = 0;x<img.getWidth();x++) {
				try {
					Color c =new Color(img.getRGB(x, y));
				out.setRGB(x, y, new Color((int) (c.getRed()*percent),(int)(c.getGreen()*percent),(int)(c.getBlue()*percent),c.getAlpha()).getRGB());
				}catch(Exception e) {
					
				}
			}
		}
		return out;
		
	}
	public BufferedImage invirt(BufferedImage img, int x, int y, int w1, int h1,boolean b) {
		BufferedImage outI;
		if(img!= null) {
			 outI = new BufferedImage(w1, h1,  img.getType());
		}else {
		 outI = new BufferedImage(w1, h1,  6);
		}
		for(int h = y;h<y+h1;h++) {
			for(int w = x;w<x+w1;w++) {
				Color c;
				if(w>=img.getWidth()||h>=img.getHeight()||h<0||w<0) {
					c = Color.BLACK;
				}else {
				c = new Color(img.getRGB(w, h));
				}
				Color invert = new Color(255-c.getRed(),255-c.getGreen(),255-c.getBlue());
				if(b) {
					if(!(w>img.getWidth()||h>img.getHeight())) {
						
						img.setRGB(w, h, invert.getRGB());
					}
			
				}else {	
					outI.setRGB(w-x, h-y, invert.getRGB());
				}
			}
		}
		return outI;
		
	}
	public void removeColor(BufferedImage img,Color color,int tolerence) {
		for(int h = 0;h<img.getHeight();h++) {
			for(int w = 0;w<img.getWidth();w++) {
				Color pixelColor = new Color(img.getRGB(w, h));
				int r = pixelColor.getRed();
				int g = pixelColor.getGreen();
				int b = pixelColor.getBlue();
				int a = pixelColor.getAlpha();
				if(r+tolerence>color.getRed()&&(r-tolerence<color.getRed())) {
					if(g+tolerence>color.getGreen()&&(g-tolerence<color.getGreen())) {
						if(b+tolerence>color.getBlue()&&(b-tolerence<color.getBlue())) {
							img.setRGB(w, h,(new Color(0,0,0,0)).getRGB());
						}
					}
				}
			}
			
		}
	}
	public void softblur(BufferedImage img,int x,int y,int width,int height,int amount,int n) {

		if(n != 0) {
			
		
if(n +amount !=1) {
		if(n % amount ==0) {
			n+=1;
		}
}

		for(int p = 0;p<width;p+=amount+n) {
			blur(img,x+p,y,width-p,height,amount,true);
			blur(img,x,y+p,width,height-p,amount,true);
			}
		}else {
			for(int p = 0;p<width;p+=1) {
				blur(img,x+p,y,width-p,height,amount,true);
				blur(img,x,y+p,width,height-p,amount,true);
				}
		}
			
		
		
	}
	public BufferedImage BBlur(BufferedImage img,int x,int y,int width,int height,int amount,boolean b) {
		ArrayList<ArrayList<Integer>> rgb5= new ArrayList<ArrayList<Integer>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		for(int h = 0;h<height;h++) {
			rgb5.add(new ArrayList<Integer>());
			for(int w = 0;w<width;w++) {
				double sumr = 0;
				double sumg = 0;
				double sumb = 0;
				double suma= 0;
				for(int dh = 0;dh<amount*2;dh++) {
					for(int dw = 0;dw<amount*2;dw++) {
						Color ave =new Color(img.getRGB(w-amount+dw+x, h-amount+dh+y));
						sumr +=ave.getRed();
						sumg += ave.getGreen();
						sumb += ave.getBlue();
						suma += ave.getAlpha();
					}
				}
				sumr /=amount*2*amount*2;
				sumg /=amount*2*amount*2;
				sumb /=amount*2*amount*2;
				suma /=amount*2*amount*2;
				Color out = new Color((int)sumr,(int)sumg,(int)sumb,(int)suma);
				rgb5.get(h).add(w, out.getRGB());
				
			}
		}
		for(int h = 0;h<height;h++) {
			for(int w = 0;w<width;w++) {
				if(b) {
					img.setRGB(w+x, h+y, rgb5.get(h).get(w));	
					}else {
					outI.setRGB(w, h,rgb5.get(h).get(w));
					}
			}
		}
		return outI;
	}
	public BufferedImage CBlur(BufferedImage img,int x,int y,int width,int height,int amount, boolean b) {
		ArrayList<ArrayList<Integer>> rgb5= new ArrayList<ArrayList<Integer>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		for(int h = 0;h<height;h++) {
			rgb5.add(new ArrayList<Integer>());
			for(int w = 0;w<width;w++) {
				double sumr = 0;
				double sumg = 0;
				double sumb = 0;
				double suma= 0;
				double sum = 0;
				for(int dh = -amount;dh<amount;dh++) {
					for(int dw = -amount;dw<amount;dw++) {
						if(Math.sqrt(Math.pow(dh, 2)+Math.pow(dw, 2))<=amount) {
							try {
						Color ave =new Color(img.getRGB(w+dw+x, h+dh+y));
						sumr +=ave.getRed();
						sumg += ave.getGreen();
						sumb += ave.getBlue();
						suma += ave.getAlpha();
						sum++;
							}catch(ArrayIndexOutOfBoundsException|NullPointerException e) {
								
							}
						}
					}
				}
				sumr /=sum;
				sumg /=sum;
				sumb /=sum;
				suma /=sum;
				Color out = new Color((int)sumr,(int)sumg,(int)sumb,(int)suma);
				rgb5.get(h).add(w, out.getRGB());
				
			}
		}
		
		for(int h = 0;h<height;h++) {
			for(int w = 0;w<width;w++) {
				try {
					if(b) {
					img.setRGB(w+x, h+y, rgb5.get(h).get(w));	
					}else {
					outI.setRGB(w, h,rgb5.get(h).get(w));
					}
				}catch(ArrayIndexOutOfBoundsException e) {
					
				}
			}
		}
		return outI;
	}
	
	public BufferedImage blur(BufferedImage img,int x,int y,int width,int height,int amount,boolean b)throws ArrayIndexOutOfBoundsException {
		ArrayList<ArrayList<Color>> rgb5= new ArrayList<ArrayList<Color>>();
		ArrayList<ArrayList<Point>> points= new ArrayList<ArrayList<Point>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		if(x+width > img.getWidth()) {
			width = img.getWidth()-x;
		}
		if(y+height > img.getHeight()) {
			height = img.getHeight()-y;
		}
		int countbox = 0;
		double countw = width/amount;
		double counth = height/amount;
		int count = 0;
		double tcount = countw*counth;
		int	realCount;
		rgb5.add(new ArrayList<Color>());
		points.add(new ArrayList<Point>());
		for(int i =0;i<=tcount;i++) {
			rgb5.add(new ArrayList<Color>());
			points.add(new ArrayList<Point>());
		}
		for(int h = 0;h<=height-amount;h+=amount) {
			for(int w = 0;w<=width-amount;w+=amount) {
				for(int i = 0;i<amount;i++) {
					for(int k = 0;k<amount;k++) {
						if((x+w+k > 0)&&(y+h+i > 0)){
				rgb5.get(countbox).add(new Color(img.getRGB(x+w+k, y+h+i)));
				points.get(countbox).add(new Point(x+w+k,y+h+i));
				
					}
					}
				}
				countbox++;
			}
		}
		for(int i = 0;i<tcount+1;i++) {
			double sumr = 0;
			double sumg = 0;
			double sumb = 0;
			double suma = 0;
			for(Color ave:rgb5.get(i)) {
				sumr += ave.getRed();
				sumg += ave.getGreen();
				sumb += ave.getBlue();
				suma += ave.getAlpha();
			}
			sumr/=amount*amount;
			sumb/=amount*amount;
			sumg/=amount*amount;
			suma/=amount*amount;
			for(Point p:points.get(i)) {
				if(b) {
				img.setRGB(p.x, p.y, (new Color((int)sumr,(int)sumg,(int)sumb,(int)suma).getRGB()));
				}else {
					outI.setRGB(p.x-x, p.y-y, (new Color((int)sumr,(int)sumg,(int)sumb,(int)suma).getRGB()));
				}
			}
		}
		return outI;
		
		
		
	}
	public BufferedImage blurPoly(BufferedImage img,Polygon poly,int amount,boolean b) {
		 BufferedImage thebuf = blur(img,poly.getBoundingBox().x, poly.getBoundingBox().y, poly.getBoundingBox().width, poly.getBoundingBox().height, amount, false);
		for(int h = 0;h<thebuf.getHeight();h++) {
			for(int w = 0;w<thebuf.getWidth();w++) {
				if(!poly.contains(poly.getBoundingBox().x+w,poly.getBoundingBox().y+h)) {
					thebuf.setRGB(w, h, (new Color(0,0,0,0)).getRGB());
				}else if(b){
					img.setRGB(poly.getBoundingBox().x+w, poly.getBoundingBox().x+h,thebuf.getRGB(w, h));
				}
			}
		}
		 return thebuf;
		
	}
	public BufferedImage cutPoly(BufferedImage img,Polygon poly) {
		for(int h = 0;h<img.getHeight();h++) {
			for(int w = 0;w<img.getWidth();w++) {
				if(!poly.contains(poly.getBoundingBox().x+w,poly.getBoundingBox().y+h)) {
					img.setRGB(w, h, (new Color(0,0,0,0)).getRGB());
				}
			}
		}
		 return img;
		
	}
}
