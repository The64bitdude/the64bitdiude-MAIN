package GameTypes;

import java.util.ArrayList;

public class Idol {
	public double TickSpeed = 0;
	public double FPS = 0;
	public double TPS = 0;
	public double time = 0;
	public double startMoney=0;
	public double Money=0;
	public ArrayList<Upgrade> Upgrades;
 /**
  * ticks per second
  * @author the64bitdude
  */
	public Idol(double tickspeed,double FPS,double startMoney) {
		TPS=tickspeed;
		this.FPS=FPS;
		TickSpeed=this.TPS/this.FPS;
		this.startMoney=startMoney;
		Money=this.startMoney;
		Upgrades=new ArrayList<Upgrade>();
	}
	public void update(float currentFPS) {
		time+=TPS/currentFPS;
	}
	public void resetTime() {
		time=0;
	}
	public void add(Upgrade U) {
		Upgrades.add(U);
	}
	public void collectAll() {
		double sum = 0;
		for(Upgrade U:Upgrades) {
			sum+=U.collect(time);
		}
		time = 0;
		Money+=sum;
	
	}
	public double getRate() {
		
			double sum = 0;
			for(Upgrade U:Upgrades) {
				sum+=U.currentRate;
			}
		
			return sum;
		
		
	}
	public void buy(int index) {
		Money = Upgrades.get(index).buy(Money);
	}
	public String toString() {
		return Money+"$"+"    current Rate " + (int)(Math.round(getRate())) +" units per second";
		
	}
	
}
