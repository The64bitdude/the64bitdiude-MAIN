package GameTypes;

public class Upgrade {
	public double CostIncreasePercent=0;
	public double RateIncreasePercent=0;
	public double startCost = 0;
	public double startRate = 0;
	public int timesAdded=0;
	public boolean enabled=false;
	public double currentCost = 0;
	public double currentRate = 0;
	public Upgrade(double percentUpPer,double startCost,double startRate,double RateIncreasePer,boolean StartEnabled) {
		CostIncreasePercent=percentUpPer;
		RateIncreasePercent=RateIncreasePer;
		this.startCost=startCost;
		this.startRate=startRate;
		currentCost=this.startCost;
		this.enabled=StartEnabled;
		if(this.enabled) {
		currentRate=this.startRate;
		}else {
			currentRate=0;	
		}

	}
	public double buy(double money) {
		if(money >=currentCost) {
			timesAdded+=1;
			double newMoney = money-currentCost;
		currentCost*=(1+CostIncreasePercent);
		if(this.enabled) {
		currentRate*=(1+RateIncreasePercent);
		}else {
			currentRate=this.startRate;
			this.enabled=true;
		}
		return newMoney;
		}else {
			return money;
		}
	}
	public double collect(double time) {
		return currentRate*time;
	}
	public String toString() {
		return "cost "+currentCost + "$ Rate: " +currentRate +"units per second    next rate: "+ currentRate*(1+RateIncreasePercent)+"units per second ";
	}
}
