module modlued {
	exports GameTypes;
	exports liquid;
	exports DataServer;
	exports RayTrace;
	exports AI1;
	exports Shapes;
	exports Screens;
	exports ImageMinipulation;
	exports Physics;
	exports Systems;

	requires java.desktop;
	requires slf4j.api;
	requires jdk.internal.le;
	requires jdk.unsupported;
	requires webcam.capture;
	requires java.base;
	requires jdk.crypto.ec;
	requires java.datatransfer;

}