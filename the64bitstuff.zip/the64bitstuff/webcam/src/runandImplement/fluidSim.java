package runandImplement;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;



import Screens.RefreshScreen;

public class fluidSim {
	public static void main(String[] args) {
		Dimension e = Toolkit.getDefaultToolkit().getScreenSize();
		new RefreshScreen(500,500,Color.BLACK,60,3) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			
			public int[][] grid;
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				//frame.setUndecorated(true);
				frame.setResizable(false);

			
				frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Icon.png"));
				frame.setTitle("FLUID SIMULATION");
				BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

				// Create a new blank cursor.
				Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
				    cursorImg, new Point(0, 0), "blank cursor");
				frame.getContentPane().setCursor(blankCursor);
			}
			int size = 30;
			int sizeb = 30;
			boolean pause =false;
			boolean pres = false;
			boolean zoom =false;
			boolean presz = false;
			boolean frame =false;
			boolean presf = false;
			boolean hold =false;
			boolean presh = false;
			int state=1;
			int bx=0;
			int by=0;
			int fireL=508;
			public void update() {
				if(PressedKeys.containsValue(true)||pres||presz||presf||presh) {
				if(PressedKeys.containsKey(KeyEvent.VK_R)) {
					if(PressedKeys.get(KeyEvent.VK_R)) {
						grid = new int[screenHeight][screenWidth]; 
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_SPACE)) {
					if(PressedKeys.get(KeyEvent.VK_SPACE)) {
						if(!pres) {
							pause=!pause;
							pres=true;
						}
					}
					if(!PressedKeys.get(KeyEvent.VK_SPACE)) {
						pres=false;
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_Z)) {
					if(PressedKeys.get(KeyEvent.VK_Z)) {
						if(!presz) {
							zoom=!zoom;
							presz=true;
						}
					}
					if(!PressedKeys.get(KeyEvent.VK_Z)) {
						presz=false;
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_F)) {
					if(PressedKeys.get(KeyEvent.VK_F)) {
						if(!presf) {
						frame = true;
						presf=true;
						}
						
	
					}
					if(!PressedKeys.get(KeyEvent.VK_F)) {
						presf=false;
					}
					
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_H)) {
					if(PressedKeys.get(KeyEvent.VK_H)) {
						if(!presh) {
						hold = !hold;
						presh=true;
						}
						
	
					}
					if(!PressedKeys.get(KeyEvent.VK_H)) {
						presh=false;
					}
					
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_1)) {
					if(PressedKeys.get(KeyEvent.VK_1)) {
						
						state= 1;
						
	
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_2)) {
					if(PressedKeys.get(KeyEvent.VK_2)) {
						state = 2;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_3)) {
					if(PressedKeys.get(KeyEvent.VK_3)) {
						state = 3;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_4)) {
					if(PressedKeys.get(KeyEvent.VK_4)) {
						state = 4;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_5)) {
					if(PressedKeys.get(KeyEvent.VK_5)) {
						state = 5;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_6)) {
					if(PressedKeys.get(KeyEvent.VK_6)) {
						state = 6;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_7)) {
					if(PressedKeys.get(KeyEvent.VK_7)) {
						state =7;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_8)) {
					if(PressedKeys.get(KeyEvent.VK_8)) {
						state = 8;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_9)) {
					if(PressedKeys.get(KeyEvent.VK_9)) {
						state =9;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_0)) {
					if(PressedKeys.get(KeyEvent.VK_0)) {
						state =10;
					}
					
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_I)) {
					if(PressedKeys.get(KeyEvent.VK_I)) {
						size++;
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_O)) {
					if(PressedKeys.get(KeyEvent.VK_O)) {
						if(size >= 1) {
						size--;
						}
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_K)) {
					if(PressedKeys.get(KeyEvent.VK_K)) {
						sizeb++;
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_L)) {
					if(PressedKeys.get(KeyEvent.VK_L)) {
						if(sizeb >= 1) {
						sizeb--;
						}
					}
					
				}
				}
				if((rightMousePressed)||(leftMousePressed)||hold) {
					double deltaX = 0;
					double deltaY = 0;
					double deltaA = 0;
					double deltaD = 0;
					deltaX=mouseX-bx;
					deltaY=mouseY-by;
					deltaA = deltaY/deltaX;
					if(!(deltaX==0&&deltaY==0)) {
					for(int dax = 0;dax<=Math.abs(deltaX);dax++) {
						if(deltaX<0) {
							dax*=-1;
						}
					for(int i = 0;i<=size;i++) {
						for(int k = 0;k<=size;k++) {
							if(((dax+bx)>(size/2))&&((dax*deltaA)+by>(size/2)+1)&&((dax*deltaA)+by+size/2<screenHeight-1)&&((dax+bx)+size/2<screenWidth-1)) {
						if((rightMousePressed))	{
							
									if((state<4)&&(state!=3)) {
					
						
						if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
							grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=(state*2)-1;
						}
						}else if(state==3){
					
					
						
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=4;
							}
						}else if(state==4){
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=fireL;
							}
						}else if(state==5) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=518;
							}
						}else if(state==6) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=519;
							}
						}else if(state==7) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=520;
							}
						}else if(state==8) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=522;
							}
						}else if(state==9) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=524;
							}
						}else if(state==10) {
							if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]==0) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=526;
							}
						}
									
						
								}
						
						if(leftMousePressed) {
							
									
										if(grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]>=1) {
								grid[(int) ((dax*deltaA)+by-size/2+i)][(dax+bx)-size/2+k]=0;
										}
							
									
								
							
						}
						}
						}
						}
						if(dax <0) {
							dax*=-1;
						}
					}
						for(int dax = 0;dax<=Math.abs(deltaY);dax++) {
							if(deltaY<0) {
								dax*=-1;
							}
						for(int i = 0;i<=size;i++) {
							for(int k = 0;k<=size;k++) {
								if(((dax/deltaA)+bx>size/2)&&((dax+by)>size/2)&&((dax+by)+size/2<screenHeight-1)&&((dax/deltaA)+bx+size/2<screenWidth-1)) {
							if((rightMousePressed))	{
							
								if((state<4)&&(state!=3)) {
									
									
									if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
										grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=(state*2)-1;
									}
									}else if(state==3){
								
								
									
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=4;
										}
									}else if(state==4){
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=fireL;
										}
									}else if(state==5) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=518;
										}
									}else if(state==6) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=519;
										}
									}else if(state==7) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=520;
										}
									}else if(state==8) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=522;
										}
									}else if(state==9) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=524;
										}
									}else if(state==10) {
										if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]==0) {
											grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=526;
										}
									}
									
							}
							if(leftMousePressed) {
								
										
											if(grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]>=1) {
									grid[(int) ((dax+by)-size/2+i)][(int) ((dax/deltaA)+bx-size/2+k)]=0;
											}
								
										
										
								
							}
							}
							}
							}
							if(dax <0) {
								dax*=-1;
							}
						}
					}else {
						for(int i = 0;i<=size;i++) {
							for(int k = 0;k<=size;k++) {
								if((mouseX>size/2)&&(mouseY>size/2)&&(mouseY+size/2<screenHeight)&&(mouseX+size/2<screenWidth)) {
							if((rightMousePressed)||hold)	{
				
									if((state<4)&&(state != 3)) {
									
									
									if(	grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
										grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=(state*2)-1;
									}
									}else if(state==3){
								
								
									
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=4;
										}
									}else if(state==4){
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=fireL;
										}
									}else if(state==5) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=518;
										}
									}else if(state==6) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=519;
										}
									}else if(state==7) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=520;
										}
									}else if(state==8) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=522;
										}
									}else if(state==9) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=524;
										}
									}else if(state==10) {
										if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]==0) {
											grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=526;
										}
									}
									
									
							}
								
							if(leftMousePressed) {
								
										
											if(grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]>=1) {
									grid[(int) (mouseY-size/2+i)][(int) (mouseX-size/2+k)]=0;
											}
								
										
									
							}
						
							}
								}
							}
					}
				}
				
				bx =mouseX;
				by=mouseY;
				if(!pause) {
				updateB();
				}else if(frame){
					updateB();
					frame = false;
				}
		
				
				
			}

				private void upd2(int x,int y) {
					if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)&&(y>=1)) {
					
					if((grid[y][x]>=8)&&grid[y][x] <=508){
						grid[y][x]--;
						ArrayList<Integer> g = new 	ArrayList<Integer>();
					
						g.add(0);
						g.add(1);
						g.add(2);
						g.add(3);
						g.add(4);
						g.add(5);
						g.add(6);
						g.add(7);
						g.add(8);
						g.add(9);
						g.add(10);
						g.add(11);
						g.add(12);
						g.add(13);
						g.add(14);
						g.add(15);
						g.add(16);
						g.add(17);
						g.add(18);
						g.add(19);
						
						Collections.shuffle(g);
						
						int count =0;
				
						for(int i = 0;(i<g.size())&&(count<1);i++) {
							switch(g.get(i)) {
							case 0:if(grid[y-1][x]==0) {
								grid[y-1][x]=grid[y][x]-1;
								grid[y][x]=0;
								count++;
							};break;
							case 1:if(grid[y-1][x+1]==0) {
								grid[y-1][x+1]=grid[y][x]-1;
								grid[y][x]=0;
								count++;
							};break;
							case 2:if(grid[y-1][x-1]==0) {
								grid[y-1][x-1]=grid[y][x]-1;
								grid[y][x]=0;
								count++;
							};break;
							case 3:if(grid[y-1][x]==3) {
								grid[y][x]-=1;
								grid[y-1][x]=fireL-1;
								count++;
							};break;
							case 4:if(grid[y-1][x-1]==3) {
								grid[y][x]-=1;
								grid[y-1][x-1]=fireL-1;
								count++;
							};break;
							case 5:if((grid[y-1][x+1]==3)) {
								grid[y][x]-=1;
								grid[y-1][x+1]=fireL-1;
								count++;
							};break;
							case 6:if((grid[y][x-1]==0)) {
								grid[y][x-1]=grid[y][x]-1;
								grid[y][x]=0;
								count++;
							};break;
							case 7:if((grid[y][x+1]==0)) {
								grid[y][x+1]= grid[y][x]-1;
								grid[y][x]=0;
								count++;
							};break;
							case 8:if((grid[y][x-1]==3)) {
								grid[y][x]-=1;
								grid[y][x-1]=fireL-1;
								count++;
							};break;
							case 9:if((grid[y][x+1]==3)) {
								grid[y][x]-=1;
								grid[y][x+1]=fireL-1;
								count++;
							};break;
							case 10:if((grid[y+1][x]==3)) {
								grid[y][x]-=1;
								grid[y+1][x]=fireL-1;
								count++;
							};break;
							case 11:if((grid[y-1][x]==1)) {
								grid[y-1][x]=grid[y][x]-1;
								grid[y][x]=2;
								count++;
							};break;
							case 12:if((grid[y-1][x+1]==1)) {
								grid[y-1][x+1]=grid[y][x]-1;
								grid[y][x]=2;
								count++;
							};break;
							case 13:if((grid[y-1][x-1]==1)) {
						
								grid[y-1][x-1]=grid[y][x]-1;
								grid[y][x]=2;
								count++;
							};break;
							case 14:if((grid[y][x-1]==520)) {
								grid[y][x]-=1;
								grid[y][x-1]=fireL-1;
								count++;
							};break;
							case 15:if((grid[y][x+1]==520)) {
								grid[y][x]-=1;
								grid[y][x+1]=fireL-1;
								count++;
							};break;
							case 16:if((grid[y-1][x]==520)) {
								grid[y][x]-=1;
								grid[y-1][x]=fireL-1;
								count++;
							};break;
							case 17:if(grid[y+1][x]==520) {
								grid[y][x]-=1;
								grid[y+1][x]=fireL-1;
								count++;
							};break;
							case 18:if(grid[y-1][x-1]==520) {
								grid[y][x]-=1;
								grid[y-1][x-1]=fireL-1;
								count++;
							};break;
							case 19:if((grid[y-1][x+1]==520)) {
								grid[y][x]-=1;
								grid[y-1][x+1]=fireL-1;
								count++;
							};break;
							}
						}
						
					}else if((grid[y][x]==6)||(grid[y][x]==7)) {
						grid[y][x]=0;
					}
					}
					
				
			}
			

			
					
			private void upd(int x,int y) {
					if((y<grid.length-1)&&(x>=2)&&(x<grid[y].length-2)) {
					if(grid[y][x] == 5) {
						grid[y][x]=4;
					}else if(grid[y][x]==4){
						ArrayList<Integer> g = new 	ArrayList<Integer>();

						g.add(0);
				
						g.add(3);
						g.add(4);
						
						g.add(5);
						g.add(6);
						g.add(7);
						g.add(8);
						g.add(9);
						g.add(10);
						g.add(11);
						g.add(12);
						g.add(13);
				
				
						g.add(17);
						g.add(18);
						g.add(19);
						g.add(20);
						g.add(21);
						g.add(22);
						g.add(23);
						g.add(24);
						g.add(25);
						g.add(26);
						g.add(27);
						g.add(28);
						g.add(29);
						Collections.shuffle(g);
						
						int count =0;
				
						for(int i = 0;(i<g.size())&&(count<1);i++) {
							switch(g.get(i)) {
							case 0:if(grid[y+1][x]==0) {
								grid[y][x]=0;
								grid[y+1][x]=5;
								count++;
							};break;
							case 3:if((grid[y][x+1]==0)&&(((grid[y-1][x]==(4))||(grid[y-1][x]==(5)))||((grid[y][x-1]==(4))||(grid[y][x-1]==(5))))) {
							
						
								grid[y][x]=0;
								grid[y][x+1]=5;
								count++;
							
								
							};break;
							case 4:if((grid[y][x-1]==0)&&(((grid[y-1][x]==(4))||(grid[y-1][x]==(5)))||((grid[y][x+1]==(4))||(grid[y][x+1]==(5))))) {
								
										grid[y][x]=0;
										grid[y][x-1]=5;
										count++;
									
							
							};break;
							case 5:if((grid[y-1][x]==1)) {
								grid[y][x]=2;
								grid[y-1][x]=5;
								count++;
							};break;
							case 6:if((grid[y-1][x+1]==1)) {
								grid[y][x]=2;
								grid[y-1][x+1]=5;
								count++;
							};break;
							case 7:if((grid[y-1][x-1]==1)) {
								grid[y][x]=2;
								grid[y-1][x-1]=5;
								count++;
							};break;
							case 8:if((grid[y+1][x]>=6)&&((grid[y+1][x]<=508))) {
								grid[y+1][x]=0;
								count++;
							};break;
							case 9:if((grid[y+1][x+1]>=6)&&((grid[y+1][x+1]<=508))) {
								grid[y+1][x+1]=0;
								count++;
							};break;
							case 10:if((grid[y+1][x-1]>=6)&&((grid[y+1][x-1]<=508))) {
								grid[y+1][x-1]=0;
								count++;
							};break;
							case 11:if((grid[y-1][x]>=6)&&((grid[y-1][x]<=508))) {
								grid[y-1][x]=0;
								count++;
							};break;
							case 12:if((grid[y-1][x+1]>=6)&&((grid[y-1][x+1]<=508))) {
								grid[y-1][x+1]=0;
								count++;
							};break;
							case 13:if((grid[y-1][x-1]>=6)&&((grid[y-1][x-1]<=508))) {
								grid[y-1][x-1]=0;
			 				count++;
							};break;
							case 17:if((grid[y][x-1]==518)) {
								if((int)(Math.random()*15)==1) {
								grid[y][x-1]=2;
								count++;
								}
							};break;
							case 18:if((grid[y][x+1]==518)) {
								if((int)(Math.random()*15)==1) {
								grid[y][x+1]=2;
								count++;
								}
							};break;
							case 19:if(grid[y+1][x]==518) {
								if((int)(Math.random()*15)==1) {
								grid[y+1][x]=2;
			
								count++;
								}
							};break;
							case 20:if(grid[y+1][x-1]==518) {
								if((int)(Math.random()*15)==1) {
								grid[y+1][x-1]=2;
								count++;
								}
							};break;
							case 21:if((grid[y+1][x+1]==518)) {
								if((int)(Math.random()*15)==1) {
								grid[y+1][x+1]=2;
								count++;
								}
							};break;
							case 22:if(grid[y-1][x]==3) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 23:if(grid[y-1][x-1]==3) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 24:if((grid[y-1][x+1]==3)) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 25:if((grid[y][x-1]==3)) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 26:if((grid[y][x+1]==3)) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 27:if(grid[y+1][x]==3) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 28:if(grid[y+1][x-1]==3) {
								if((int)(Math.random()*1000)==1) {
									grid[y][x]=3;
								count++;
								}
							};break;
							case 29:if((grid[y+1][x+1]==3)) {
								if((int)(Math.random()*1000)==1) {
								grid[y][x]=3;
								count++;
								}
							};break;
							
							}
						}
						
					}
					}
					
				
			}
			private void upd4(int x,int y) {
				if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)) {
				if(grid[y][x] == 521) {
					grid[y][x]=520;
				}else if(grid[y][x]==520){
					ArrayList<Integer> g = new 	ArrayList<Integer>();
			for(int i =0;i<15;i++) {
					g.add(0);
				}
					g.add(3);
					g.add(4);
					g.add(5);
					g.add(6);
					g.add(7);
					g.add(8);
					g.add(9);
					g.add(10);
					g.add(11);
					g.add(12);
					Collections.shuffle(g);
					
					int count =0;
			
					for(int i = 0;(i<g.size())&&(count<1);i++) {
						switch(g.get(i)) {
						case 0:if(grid[y+1][x]==0) {
							grid[y][x]=0;
							grid[y+1][x]=521;
							count++;
						};break;
						case 3:if(grid[y][x+1]==0) {
							grid[y][x]=0;
							grid[y][x+1]=520;
							count++;
						};break;
						case 4:if(grid[y][x-1]==0) {
							grid[y][x]=0;
							grid[y][x-1]=520;
							count++;
						};break;
						case 5:if((grid[y+1][x]==1)) {
							grid[y][x]=2;
							grid[y+1][x]=521;
							count++;
						};break;
						case 6:if((grid[y+1][x+1]==1)) {
							grid[y][x]=2;
							grid[y+1][x+1]=521;
							count++;
						};break;
						case 7:if((grid[y+1][x-1]==1)) {
							grid[y][x]=2;
							grid[y+1][x-1]=521;
							count++;
						};break;
						case 8:if(grid[y][x+1]==1) {
							grid[y][x]=2;
							grid[y][x+1]=521;
							count++;
						};break;
						case 9:if(grid[y][x-1]==1) {
							grid[y][x]=2;
							grid[y][x-1]=521;
							count++;
						};break;
						case 10:if((grid[y-1][x]==4)) {
							grid[y][x]=5;
							grid[y-1][x]=521;
							count++;
						};break;
						case 11:if((grid[y-1][x+1]==4)) {
							grid[y][x]=5;
							grid[y-1][x+1]=521;
							count++;
						};break;
						case 12:if((grid[y-1][x-1]==4)) {
							grid[y][x]=5;
							grid[y-1][x-1]=521;
							count++;
						};break;
						
						
						
						}
					}
					
				}
				}
				
			
		}
			private void upd3(int x,int y) {
				if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)) {
				if(grid[y][x] == 2) {
					grid[y][x]=1;
				}else if(grid[y][x]==1){
					ArrayList<Integer> g = new 	ArrayList<Integer>();

					g.add(0);
					g.add(1);
					g.add(2);
					g.add(3);
					g.add(4);
					g.add(5);
					Collections.shuffle(g);
					
					int count =0;
			
					for(int i = 0;(i<g.size())&&(count<1);i++) {
						switch(g.get(i)) {
						case 0:if(grid[y+1][x]==0) {
							grid[y][x]=0;
							grid[y+1][x]=2;
							count++;
						};break;
						case 1:if(grid[y+1][x+1]==0) {
							grid[y][x]=0;
							grid[y+1][x+1]=2;
							count++;
						};break;
						case 2:if(grid[y+1][x-1]==0) {
							grid[y][x]=0;
							grid[y+1][x-1]=2;
							count++;
						};break;
						case 3:if((grid[y-1][x]==520)) {
							grid[y][x]=521;
							grid[y-1][x]=2;
							count++;
						};break;
						case 4:if((grid[y-1][x+1]==520)) {
							grid[y][x]=521;
							grid[y-1][x+1]=2;
							count++;
						};break;
						case 5:if((grid[y-1][x-1]==520)) {
							grid[y][x]=521;
							grid[y-1][x-1]=2;
							count++;
						};break;
						
						}
					}
					
				}
				}
				
			
		}
			private void upd7(int x,int y) {
				if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)&&(y>=1)) {
				 if(grid[y][x]==526){
					ArrayList<Integer> g = new 	ArrayList<Integer>();

					g.add(0);
					g.add(1);
					g.add(2);
					g.add(3);
					g.add(4);
					g.add(5);
					g.add(6);
					g.add(7);
					Collections.shuffle(g);
					
					int count =0;
			
					for(int i = 0;(i<g.size())&&(count<1);i++) {
						switch(g.get(i)) {
						case 0:if(grid[y-1][x]!=(0|526)) {
							grid[y-1][x]=0;
							count++;
						};break;
						case 1:if(grid[y-1][x+1]!=(0|526)) {
							grid[y-1][x+1]=0;
							count++;
						};break;
						case 2:if(grid[y-1][x-1]!=(0|526)) {
							grid[y-1][x-1]=0;
							count++;
						};break;
						case 3:if(grid[y][x-1]!=(0|526)) {
							grid[y][x-1]=0;
							count++;
						};break;
						case 4:if(grid[y][x+1]!=(0|526)) {
							grid[y][x+1]=0;
							count++;
						};break;
						case 5:if(grid[y+1][x]!=(0|526)) {
							grid[y+1][x]=0;
							count++;
						};break;
						case 6:if(grid[y+1][x-1]!=(0|526)) {
							grid[y+1][x-1]=0;
							count++;
						};break;
						case 7:if(grid[y+1][x+1]!=(0|526)) {
							grid[y+1][x+1]=0;
							count++;
						};break;
						}
					}
					
				}
				}
				
			
		}
			private void upd5(int x,int y) {
				if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)&&(y>=1)) {
				if(grid[y][x] == 523) {
					grid[y][x]=522;
				}else if(grid[y][x]==522){
					ArrayList<Integer> g = new 	ArrayList<Integer>();

					g.add(0);
					g.add(1);
					g.add(2);
					g.add(3);
					g.add(4);
					g.add(5);
					g.add(6);
					g.add(7);
					g.add(8);
					Collections.shuffle(g);
					
					int count =0;
			
					for(int i = 0;(i<g.size())&&(count<1);i++) {
						switch(g.get(i)) {
						case 0:if(grid[y-1][x]==0) {
							grid[y][x]=0;
							grid[y-1][x]=523;
							count++;
						};break;
						case 1:if(grid[y-1][x+1]==0) {
							grid[y][x]=0;
							grid[y-1][x+1]=523;
							count++;
						};break;
						case 2:if(grid[y-1][x-1]==0) {
							grid[y][x]=0;
							grid[y-1][x-1]=523;
							count++;
						};break;
						case 3:if((grid[y-1][x]==(4)||grid[y-1][x]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y-1][x]=5;
							count++;
							}else{
							grid[y][x]=5;
							grid[y-1][x]=523;
							count++;
								
							}
						};break;
						case 4:if((grid[y-1][x+1]==(4))||(grid[y-1][x+1]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y-1][x+1]=5;
							count++;
							}else {
								grid[y][x]=5;
								grid[y-1][x+1]=523;
								count++;
							}
						};break;
						case 5:if((grid[y-1][x-1]==(4))||(grid[y-1][x-1]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y-1][x-1]=5;
							count++;
							}else {
								grid[y][x]=5;
								grid[y-1][x-1]=523;
								count++;
							}
						};break;
						case 6:if((grid[y+1][x]==(4))||(grid[y+1][x]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y+1][x]=5;
							count++;
							}else{
							grid[y][x]=5;
							grid[y+1][x]=523;
							count++;
								
							}
						};break;
						case 7:if((grid[y+1][x+1]==(4))||(grid[y+1][x+1]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y+1][x+1]=5;
							count++;
							}else {
								grid[y][x]=5;
								grid[y+1][x+1]=523;
								count++;
							}
						};break;
						case 8:if((grid[y+1][x-1]==(4))||(grid[y+1][x-1]==(5))) {
							if((int)(Math.random()*15)==1) {
							grid[y][x]=5;
							grid[y+1][x-1]=5;
							count++;
							}else {
								grid[y][x]=5;
								grid[y+1][x-1]=523;
								count++;
							}
						};break;
						}
					}
					
				}
				}
				
			
		}
			private void upd6(int x,int y) {
				if((y<grid.length-1)&&(x>=1)&&(x<grid[y].length-1)) {
				if(grid[y][x] == 525) {
					grid[y][x]=524;
				}else if(grid[y][x]==524){
					ArrayList<Integer> g = new 	ArrayList<Integer>();

					g.add(0);
					g.add(1);
					g.add(2);
					g.add(3);
					g.add(4);
					g.add(5);
					g.add(6);
					g.add(7);
					g.add(8);
					g.add(9);
					g.add(10);
					g.add(11);
					g.add(12);
					g.add(13);
					g.add(14);
					g.add(15);
					g.add(16);
					g.add(17);
					g.add(18);
					g.add(19);
					g.add(20);
					g.add(21);
					g.add(22);
					g.add(23);
					g.add(24);
					g.add(25);
					g.add(26);
					g.add(27);
				
					Collections.shuffle(g);
					
					int count =0;
			
					for(int i = 0;(i<g.size())&&(count<1);i++) {
						switch(g.get(i)) {
						case 0:if(grid[y+1][x]==0) {
							grid[y][x]=0;
							grid[y+1][x]=525;
							count++;
						};break;
						case 1:if(grid[y][x+1]==0) {
							grid[y][x]=0;
							grid[y][x+1]=524;
							count++;
						};break;
						case 2:if(grid[y][x-1]==0) {
							grid[y][x]=0;
							grid[y][x-1]=524;
							count++;
						};break;
						case 3:if((grid[y-1][x]==4)) {
				
							grid[y-1][x]=523;
							count++;
						};break;
						case 4:if((grid[y-1][x+1]==4)) {
				
							grid[y-1][x+1]=523;
							count++;
						};break;
						case 5:if((grid[y-1][x-1]==4)) {
				
							grid[y-1][x-1]=523;
							count++;
						};break;
						case 6:if((grid[y+1][x]==522)) {
							grid[y][x]=523;
							grid[y+1][x]=525;
							count++;
						};break;
						case 7:if((grid[y+1][x+1]==522)) {
							grid[y][x]=523;
							grid[y+1][x+1]=525;
							count++;
						};break;
						case 8:if((grid[y+1][x-1]==522)) {
							grid[y][x]=523;
							grid[y+1][x-1]=525;
							count++;
						};break;
						case 9:if((grid[y+1][x]==4)) {
					
							grid[y+1][x]=523;
							count++;
						};break;
						case 10:if((grid[y+1][x+1]==4)) {
					
							grid[y+1][x+1]=523;
							count++;
						};break;
						case 11:if((grid[y+1][x-1]==4)) {
			
							grid[y+1][x-1]=523;
							count++;
						};break;
						case 12:
							if((int)(Math.random()*10000)==1) {
							grid[y][x]=508;
							count++;
							}
						;break;
						case 13:if((grid[y+1][x]>=6)&&(grid[y+1][x]<=508)) {
							grid[y][x]=508;
							grid[y+1][x]=525;
							count++;
						};break;
						case 14:if((grid[y+1][x+1]>=6)&&(grid[y+1][x+1]<=508)) {
							grid[y][x]=508;
							grid[y+1][x+1]=525;
							count++;
						};break;
						case 15:if((grid[y+1][x-1]>=6)&&(grid[y+1][x-1]<=508)) {
							grid[y][x]=508;
							grid[y+1][x-1]=525;
							count++;
						};break;
						case 16:if((grid[y+1][x]==518)) {
							if((int)(Math.random()*1000)==1) {
							grid[y+1][x]=525;
							count++;
							}
						};break;
						case 17:if((grid[y+1][x+1]==518)) {
							if((int)(Math.random()*200)==1) {
							grid[y+1][x+1]=525;
							count++;
							}
						};break;
						case 18:if((grid[y+1][x-1]==518)) {
							if((int)(Math.random()*200)==1) {
							grid[y+1][x-1]=525;
							count++;
							}
						};break;
						case 19:if((grid[y-1][x]==518)) {
							if((int)(Math.random()*200)==1) {
							grid[y-1][x]=525;
							count++;
							}
						};break;
						case 20:if((grid[y-1][x+1]==518)) {
							if((int)(Math.random()*200)==1) {
							grid[y-1][x+1]=525;
							count++;
							}
						};break;
						case 21:if((grid[y-1][x-1]==518)) {
							if((int)(Math.random()*200)==1) {
							grid[y-1][x-1]=525;
							count++;
							}
						};break;
						case 22:if((grid[y+1][x]==0)) {
							if((int)(Math.random()*150)==1) {
							grid[y][x]=518;
							count++;
							}
						};break;
						case 23:if((grid[y+1][x+1]==0)) {
							if((int)(Math.random()*150)==1) {
								grid[y][x]=518;
							count++;
							}
						};break;
						case 24:if((grid[y+1][x-1]==0)) {
							if((int)(Math.random()*150)==1) {
								grid[y][x]=518;
							count++;
							}
						};break;
						case 25:if((grid[y-1][x]==0)) {
							if((int)(Math.random()*150)==1) {
								grid[y][x]=518;
							count++;
							}
						};break;
						case 26:if((grid[y-1][x+1]==0)) {
							if((int)(Math.random()*150)==1) {
								grid[y][x]=518;
							count++;
							}
						};break;
						case 27:if((grid[y-1][x-1]==0)) {
							if((int)(Math.random()*150)==1) {
								grid[y][x]=518;
							count++;
						}
						};break;
						
						}
					}
					
				}
				}
				
			
		}
			private void updateB() {
				for(int y = 0;y<grid.length;y+=1) {
					for(int x = 0;x<grid[y].length;x+=2) {
						if(grid[y][x]!=0) {
							if(grid[y][x]<=508||grid[y][x]>=520) {
						upd3(x,y);
						upd(x,y);
						upd2(x,y);
						upd4(x,y);
						 upd5(x,y);	
						 upd6(x,y);	
						 upd7(x,y);	
							}
						}
					
					}
					for(int x = grid[y].length-1;x>=1;x-=2) {
						if(grid[y][x]!=0) {
							if(grid[y][x]<=508||grid[y][x]>=520) {
						upd3(x,y);
						upd(x,y);
						upd2(x,y);
						upd4(x,y);
						 upd5(x,y);	
						 upd6(x,y);		
						 upd7(x,y);	
						 }
						}
			
					}
					
				}
				
			}
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				g2.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
				g2.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
				g2.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,RenderingHints.VALUE_COLOR_RENDER_SPEED);
			g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,RenderingHints.VALUE_STROKE_PURE);
				g2.setColor(Color.BLACK);
				g2.fillRect(0,0, screenWidth, screenHeight);
				g2.setColor(Color.WHITE);
				Rectangle R = new Rectangle(mouseX-sizeb/2, mouseY-sizeb/2, sizeb,sizeb);
				Rectangle R2 = new Rectangle(mouseX-size/2, mouseY-size/2, size, size);
				try {
				for(int y=0;y<grid.length;y++) {
					
					for(int x=0;x<grid[y].length;x++) {
						int xc=grid[y][x];
						if((xc >= 1)&&(xc<3)) {
							g2.setColor(Color.WHITE);
						
						}else if((xc == 3)) {
							g2.setColor(Color.ORANGE.darker().darker());
					
						}else if((xc >= 6)&&(xc<509)){
							int ra = (int) (Math.random()*xc/2+1);
							int ga = (int) (Math.random()*ra*0.67+1);
							int ba = (int) (Math.random()*ga*0.67+1);
							g2.setColor(new Color(ra,ga,ba));
						
						
						}else if((xc >= 4)&&(xc<509)){
							g2.setColor(Color.BLUE);
						
						}else if(xc ==518) {
							g2.setColor(Color.GRAY);
						}else if(xc ==519) {
							g2.setColor(Color.CYAN);
						}else if(xc ==520||xc ==521) {
							g2.setColor(Color.green.darker().darker());
						}else if(xc ==522||xc ==523) {
							g2.setColor(Color.lightGray);
						}else if(xc ==524||xc ==525) {
							g2.setColor(Color.red.darker());
						}else if(xc == 526||xc == 527) {
							g2.setColor(Color.MAGENTA);
						}
						
						if(xc>=1) {
							
							if(zoom) {
								if(R.contains(x, y)) {
									double sizeA = ((screenWidth*12.0*30)/sizeb)/1000;
									g2.fillRect((int)(sizeA*(x-(mouseX-sizeb/2))), (int)(sizeA*(y-(mouseY-sizeb/2))),(int)(sizeA),(int)(sizeA));
								}
								
								g2.drawLine(x, y, x, y);
							}else {
							g2.drawLine(x, y, x, y);
							}
						}
						
					}
				
				}
			}catch(NullPointerException e) {
				
			}
				if(state==2) {
					g2.setColor(Color.ORANGE.darker().darker());
				}else if(state==3) {
					g2.setColor(Color.BLUE);
				}else if(state==1){
					g2.setColor(Color.WHITE);
				}else if(state==4){
						g2.setColor(Color.RED);
					}else if(state==5){
						g2.setColor(Color.GRAY);
					}else if(state==6){
						g2.setColor(Color.CYAN);
					}else if(state == 7) {
						g2.setColor(Color.GREEN.darker().darker());
					}else if(state == 8) {
						g2.setColor(Color.lightGray);
					}else if(state == 9) {
						g2.setColor(Color.red.darker());
					}else if(state == 10) {
							g2.setColor(Color.MAGENTA);
						}
			
				g2.draw(R2);
				g2.drawString(currentFPS+"", 20, 20);
				if(zoom) {
				if(R.contains(R2)||size==0) {
					g2.drawRect(0, 0, ((screenWidth*12*30)/1000), ((screenWidth*12*30)/1000));
					double sizeA = ((screenWidth*12.0*30)/sizeb)/1000;
					g2.drawRect((int)(sizeA*(R2.x-(mouseX-sizeb/2))), (int)(sizeA*(R2.y-(mouseY-sizeb/2))),(int)((sizeA) * (R2.width+1)),(int)((sizeA) * (R2.height+1)));
					
					}
				}
				g2.dispose();
				
			}

			@Override
			public void initialize() {
				grid = new int[screenHeight][screenWidth]; 
			
				
			}
		
		};
	}
}
