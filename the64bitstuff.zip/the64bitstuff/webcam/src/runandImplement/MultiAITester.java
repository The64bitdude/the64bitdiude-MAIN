package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Arrays;

import javax.swing.JFrame;

import AI2.Brain;
import AI2.DoubleBrain;
import Screens.RefreshScreen;

public class MultiAITester {
public static void main(String[] args) {
	
	new RefreshScreen(500,500,Color.black,60,3) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		int x=0;
		int n=0;
		int y=0;
		boolean notclicking=true;
		int speed=500;
		public void update() {
			
			for(int i =0;i<speed;i++) {
			/*x+=20;
			if(x>= screenWidth) {
				x=n;
				y++;
			}
			if(y>= screenHeight) {
				y=0;
				x=n;
				n++;
			}
			if(n>=20) {
				n=0;
			}*/
		
			x=(int) (Math.random()*500);
			y=(int) (Math.random()*500);
			double per =(test.getOut(new double[]{x,y})[0]+1.0)/2.0;
			
			art.setRGB(x,y,new Color((int)(255.0*per),(int)(255.0*per),(int) (255.0*per)).getRGB());
		}
		if(mousePressed&&notclicking) {
			test = new DoubleBrain(2,1,new int[] {500,500,500,500,500,500},2, 500, 0, Brain.A_TANH, Brain.C_SE, 10);
			x=0;
			y=0;
			n=0;
		
			
			notclicking=false;
		}else if(!mousePressed) {
			notclicking=true;
		}
			
		}

		@Override
		public void paint(Graphics g) {
			g.drawImage(art,0,0,this);
			g.dispose();
		}
		BufferedImage art;
		DoubleBrain test;
		@Override
		public void initialize() {
		test = new DoubleBrain(2,1,new int[] {500,500,500,500,500,500},2, 500, 0, Brain.A_TANH, Brain.C_SE, 10);
			art = new BufferedImage(screenWidth,screenHeight,1);
		
	
			
		}
		
	};
}
}
