package runandImplement;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import DataServer.DataServer;
import DataServer.SBD;


public class serverTester {
	public static void main(String[] args) {
		
		new DataServer(1234) {
		
			@Override
			public void define() {
		
				
			}

			@Override
			public void itorate() {
			
				
			}

			@Override
			public SBD send() {
				// TODO Auto-generated method stub
				String out = "helloa";
			/*	try {
					return new SBD(2,ImageData(ImageIO.read(new File("src/Images/test.png"))));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			*/
				return new SBD(1, StringData(out));
			}

			@Override
			public void receive(String s) {
				System.out.println(s);
				
			}

			@Override
			public void receive(BufferedImage image) {
				JFrame frame = new JFrame();
				frame.setSize(image.getWidth(),image.getHeight());
				frame.setVisible(true);
				JPanel pnl = new JPanel();
				frame.add(pnl);
				pnl.add(new JLabel(new ImageIcon(image)));
				
				
			}
			
		};
		
		
		
	}

	

}
