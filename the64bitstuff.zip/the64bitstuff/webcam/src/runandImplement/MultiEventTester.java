package runandImplement;

import EventMaker.MultiThreadEvent;

public class MultiEventTester {
	public static void main(String[] args) {
		MultiThreadEvent<String> saver = new MultiThreadEvent<String>() {

			@Override
			public void run() {
				
				data.add("test");
				
				
			}
			
		};
		Thread bob =new Thread(saver);
		
		for(int i =0;i<3;i++) {
			
		try {
	
			
			bob=new Thread(saver);
			bob.start();
			bob.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		}
		for(String out:saver.data) {
			System.out.print(out);
		}
	}
}
