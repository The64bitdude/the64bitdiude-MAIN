package runandImplement;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;




import Physics.PhysicsObject3D;
import Physics.PhysicsSystem;
import Physics.Vector3D;
import Screens.RefreshScreen;
import Screens.RefreshScreen3D;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.PolygonWr;

public class refreshS3D {
	
	

	public static void main(String[] args) {
		new RefreshScreen3D(500,500,Color.BLACK,60,3,70) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			private PhysicsObject3D bob;
			Point3D savedSight;
			Point3D savedpos;
			boolean toggle=true;
			@Override
			public void Update() {
				defaultCameraMovement(4,false);
				//bob.runNextTime3D(1/currentFPS);
			if(this.isKeyPressed(KeyEvent.VK_C)&&toggle) {
				toggle=false;
				savedSight=camera.getcamV().mul(100,100,100).getPoint();
				savedpos=camera.cam.getMoved(0, 0, 0);
			}else if(!this.isKeyPressed(KeyEvent.VK_C)) {
				toggle=true;
			}
				
			
				
			}

			@Override
			public ArrayList<PolygonWr> calcPaint(Graphics3D g3) {
				
				ArrayList<PolygonWr> out =new ArrayList<PolygonWr>();
				
				g3.shadeRect3D2(camera,bob.prevPoint.x,bob.prevPoint.y,bob.prevPoint.z,50,50,50,Color.RED,out);
			
				if(savedpos!=null) {
				
				g3.shadeRect3D2(camera,savedpos.x-25,savedpos.y-25,savedpos.z-25,50,50,50,Color.ORANGE,out);
				}
				g3.setColor(Color.GREEN);
				
				
			
				return out;
			}
			protected void preDrawFrame(Graphics3D g3) {
				g3.setColor(Color.BLACK);
				g3.fillRect(0, 0, screenWidth*4, screenHeight*4);
				g3.setColor(Color.BLUE);
				g3.drawRect(0, 0, screenWidth, screenHeight);
				
			}
			@Override
			public void drawFrame(Graphics3D g3) {
			
				g3.setColor(Color.GREEN);
				if(savedpos!=null) {
				g3.drawLine(savedpos.project(camera), savedpos.getMoved(savedSight.x, savedSight.y, -savedSight.z).project(camera));
				}
				g3.drawString(bob.prevVelocity.x+" "+bob.prevVelocity.y+" "+bob.prevVelocity.z,bob.prevPoint.getMoved(0,0,-20).project(this.camera) );
				g3.drawString(bob.prevPoint.x+" "+bob.prevPoint.y+" "+bob.prevPoint.z,bob.prevPoint.project(this.camera) );
				g3.drawCirclePoint3D(new Point3D(0,0,0), camera, 10);
			}

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
			
			PhysicsSystem sys;
			@Override
			public void initialize() {
				sys=new PhysicsSystem(2,2,2);
				sys.objects[0][0][0]=new PhysicsObject3D(100);
				sys.objects[1][0][0]=new PhysicsObject3D(100);
				bob=sys.TorDia();
				bob.addVelVector(new Vector3D(0,20,-100));
				bob.addForce(00,00,bob.mass*10);
				bob.calcA();
			}

			
			

			
			
		};

	}

}
