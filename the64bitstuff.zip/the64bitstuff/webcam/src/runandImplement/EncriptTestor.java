package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Polygon;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.swing.JFrame;

import AI2.Brain;
import AI2.ReEnforcedAI;
import Screens.RefreshScreen;
import Systems.Encript;

public class EncriptTestor {

 public static void main(String[] args) {
	new RefreshScreen(1500,750,Color.black,60,3) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub

		}
int x=32;
int y=32;

int lasty=0;
String in ="it looks like a lie";
String pass ="or does it";
		@Override
		public void update() {
	
			for(int i=0;i<500;i++) {
			if(x<screenWidth) {
		x++;
			}else if(y<=screenHeight-50){
				
				y+=50;
			
				x=32;
			}else if(lasty<=50){
				lasty++;
				y=32+lasty;
			}
			/*if(mousePressed) {
				x=mouseX;
				y=mouseY;
			}*/
			if(lasty<=50){
String val =Encript.encript(in+Encript.val(x),pass+Encript.val(y))[1];
//linesDone[x][y]=true;
//System.out.println(val);
long[] vals = Encript.ArrayLongVal(val);

for(long v:vals) {

			points[x][(int)(v%screenHeight)]=true;
	
}
			}
			}


				
				//	System.out.println(decript(encript(in+(char)i,pass+(char)i2)[1],encript(in+(char)i,pass+(char)i2)[0]));
				//System.out.println(in+val(i));
				//System.out.println(pass+val(i2));
				//	System.out.println(encript(in+(char)i,pass+(char)i2)[0]);
			
			

			
		}
		boolean[][] points = new boolean[screenWidth+1][screenHeight+1];;
		@Override
		public void paint(Graphics g) {
			
			g.setColor(Color.BLACK);
	g.fillRect(0,0, screenWidth, screenHeight);
	/*if(!mousePressed) {
	g.setColor(Color.blue);
	for(int i =0;i<linesDone.length;i++) {
	for(int i2 =0;i2<linesDone[i].length;i2++) {
	if(linesDone[i][i2]) {
		g.drawLine(i, i2, i,i2);
	}

	}
	}
	}*/
	
	g.setColor(Color.white);

			for(int i =0;i<points.length;i++) {
				for(int i2 =0;i2<points[i].length;i2++) {
				if(points[i][i2]) {
				g.drawLine(i, i2, i,i2);
				}
				}
			}
			g.setColor(Color.green);
			g.drawLine(x, y, x, y);
			if(mousePressed) {
				g.setColor(Color.BLACK);
				String val =Encript.encript(in+Encript.val(mouseX),pass+Encript.val(mouseY))[1];
				g.fillRect(mouseX-5,mouseY-50,val.length()*8,54);
				g.setColor(Color.RED);
				g.drawRect(mouseX-5,mouseY-50,val.length()*8,54);
				g.drawString(val,mouseX,mouseY);
				g.drawString(in+Encript.val(mouseX),mouseX,mouseY-40);
				g.drawString(pass+Encript.val(mouseY),mouseX,mouseY-20);
			
				long[] vals = Encript.ArrayLongVal(val);
				int i =0;
				for(long v:vals) {
					
					g.setColor(Color.BLACK);
					g.fillRect(mouseX-10,(int)(v%screenHeight)-10,20,20);
					g.setColor(Color.RED);
					g.drawRect(mouseX-10,(int)(v%screenHeight)-10,20,20);
					g.drawLine(mouseX, (int)(v%screenHeight), mouseX, (int)(v%screenHeight));
					g.drawString(i+"", mouseX, (int)(v%screenHeight));
				
				i++;
				}
			
			}
		}
	

		@Override
		public void initialize() {
			points = new boolean[screenWidth+1][screenHeight+1];
			in="";
			pass="";
			for(int i =0;i<20;i++) {
				in+=(char)((int)(97*Math.random())+32);
				pass+=(char)((int)(97*Math.random())+32);
			}
		}
		
	};
 
 }
 }
 