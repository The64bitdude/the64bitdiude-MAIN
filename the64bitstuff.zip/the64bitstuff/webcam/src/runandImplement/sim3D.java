package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

import javax.swing.JFrame;

import Screens.RefreshScreen;
import Systems.Graphics3D;
import Systems.Point3D;



public class sim3D {
	public static void main(String[] args) {
		
		
		new RefreshScreen(500,500,Color.BLACK,60,3) {

		
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				points= new ArrayList<Point3D>();
				points2= new ArrayList<Point3D>();
				points3= new ArrayList<Point3D>();
				
			}
			int prevX = 250;
			int prevY = 250;
			@Override
			public void update() {
				if(PressedKeys.containsKey(KeyEvent.VK_W)) {
					if(PressedKeys.get(KeyEvent.VK_W)) {
						cam.y+=4*Math.cos(Math.toRadians(ang1));
						cam.x+=4*Math.sin(Math.toRadians(ang1));
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_S)) {
					if(PressedKeys.get(KeyEvent.VK_S)) {
						cam.y-=4*Math.cos(Math.toRadians(ang1));
						cam.x-=4*Math.sin(Math.toRadians(ang1));
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_A)) {
					if(PressedKeys.get(KeyEvent.VK_A)) {
				cam.x-=4*Math.cos(Math.toRadians(ang1));
				cam.y+=4*Math.sin(Math.toRadians(ang1));
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_D)) {
					if(PressedKeys.get(KeyEvent.VK_D)) {
						cam.x+=4*Math.cos(Math.toRadians(ang1));
						cam.y-=4*Math.sin(Math.toRadians(ang1));
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_Q)) {
					if(PressedKeys.get(KeyEvent.VK_Q)) {
					cam.z+=4;	
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_E)) {
					if(PressedKeys.get(KeyEvent.VK_E)) {
					cam.z-=4;	
					}
				}
				ang1 = ((mouseX-250)/500.0)*360;
				ang2 = ((mouseY-250)/500.0)*360;
				try {
				if(cam.distance(points3.get(points3.size()-1)) > 10) {
					points3.add(new Point3D((int)cam.getX(),(int)cam.getY(),(int)cam.getZ()+100));
				}
				}catch(Exception e) {
					
				}
				x+=3;
				
			}
			double x=0;
			double y=0;
			double ang1 = 0;
			double ang2 = 0;
			double FOV = 70;
			double dis = (screenWidth*(Math.tan(Math.toRadians(FOV))/2));
			
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				Graphics3D g3= new Graphics3D(g2);
				g3.fillRect(0, 0, screenWidth, screenHeight);
				g3.setColor(Color.WHITE);
				Point projb = null;
				for(Point3D p:points) {
					
					//System.out.println("L  :"+L.toString());
					//System.out.println("P  :"+p.toString());
					//System.out.println("");
					g3.setColor(new Color((int)p.x,(int)p.y,(int)p.z));
					Point proj = p.project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
					g3.drawCirclePoint(proj,10);
					
					//g3.drawString(""+Math.round(p.x)+","+Math.round(p.y)+","+Math.round(p.z)+"",proj.x,proj.y);
					//g3.drawString(""+Math.round(p.x-cam.x)+","+Math.round(p.y-cam.y)+","+Math.round(p.z-cam.z)+"",proj.x,proj.y);
					//System.out.println(""+Math.round(proj.x)+","+Math.round(proj.y));
			
					
				}
				projb=null;
				for(Point3D p:points2) {
					
					Point proj = p.project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
					g3.drawCirclePoint(proj,10);
					if(projb !=null) {
					g3.drawLine(proj, projb);
					}
					projb=proj;
				}
				projb=null;
			
				for(int i = 0;i<points3.size();i++) {
					Point proj = points3.get(i).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
					g3.drawCirclePoint(proj,10);
					if(projb !=null) {
					g3.drawLine(proj, projb);
					}
					projb=proj;
				}
				
				
				g3.drawRect3D(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),(int) (-100+x),-100,-100,100,100,100,screenWidth/2,screenHeight/2,true);
				
				g3.drawCirclePoint((new Point3D(0,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.GREEN);
				g3.drawCirclePoint((new Point3D(100,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.BLUE);
				g3.drawCirclePoint((new Point3D(0,100,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.RED);
				g3.drawCirclePoint((new Point3D(0,-100,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.CYAN);
				g3.drawCirclePoint((new Point3D(-100,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.drawString( currentFPS+"", 20, 20);
				g3.dispose();
		
				
			}
			ArrayList<Point3D> points= new ArrayList<Point3D>();
			ArrayList<Point3D> points2= new ArrayList<Point3D>();
			ArrayList<Point3D> points3= new ArrayList<Point3D>();
		
			Point3D cam =new Point3D(100,-100,100);
			@Override
			public void initialize() {
				System.gc();
				dis = (screenWidth*(Math.tan(Math.toRadians(FOV))/2));
			//	cam =new Point3D(100,-100,100);
			//	points = new ArrayList<Point3D>();
				for(int i = 0;i<=255;i+=25) {
					for(int k = 0;k<=255;k+=25) {
						for(int l = 0;l<=255;l+=25) {
							points.add(new Point3D(i,k,l));	
						}
					}
				}
				
				/*for(int i = 0;i<360;i+=18) {
					for(int k = 0;k<360;k+=18) {
						if(k==0) {
							for(double l = 200;l<800;l+=100) {
								points.add(new Point3D(l,i,k));	
							}
						}
				points.add(new Point3D(810.0,i,k));
						
					}
				}*/
				for(int i = 0;i<360;i+=18) {
					for(int k = 0;k<360;k+=18) {
				points2.add(new Point3D(200.0,i,k));
						
					}
				}
				points3.add(new Point3D(100,-100,100));
				
			
				
				
				
			}
			
		};
		}
}
