package runandImplement;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import DataServer.DataClient;
import DataServer.SBD;

public class DataClientTester {

	public static void main(String[] args) {
		try {
			new DataClient(InetAddress.getLocalHost(),1234) {
				
				@Override
				public SBD send() {
					// TODO Auto-generated method stub
					String out = "bewo";
					
					return new SBD(1,StringData(out));
				}

				@Override
				public void receive(String s) {
					System.out.println(s);
					
				}

				@Override
				public void define() {
					
					
					
					
				}

				@Override
				public void itorate() {
					
					
					
				}

				@Override
				public void receive(BufferedImage image) {
					JFrame frame = new JFrame();
					frame.setSize(image.getWidth(),image.getHeight());
					frame.setVisible(true);
					JPanel pnl = new JPanel();
					frame.add(pnl);
					pnl.add(new JLabel(new ImageIcon(image)));
					
				}
				
			};
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
