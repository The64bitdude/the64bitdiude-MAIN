package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JFrame;

import Screens.RefreshScreen;
import dataServer2.ClientHandler;
import dataServer2.MultiConnectionAcceptor;

public class webtester {
public static void main(String[] args) {
	MultiConnectionAcceptor mca=new MultiConnectionAcceptor(new Scanner(System.in).nextInt()) {

		@Override
		public void DataReceived(byte[] readAllBytes) {
			System.out.println(Arrays.toString(readAllBytes));
			
		}
		
	};
	

}
}
