package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import AI2.Brain;
import AI2.ReEnforcedAI;
import AI2.UnsupervisedAI;
import Screens.RefreshScreen;

public class ReEnforcedAItester {
	
	public static void main(String[] args) {
		int rez = 32;
		new RefreshScreen(rez*20,rez*20,Color.black,60,3) {
			Rectangle[][] grid;
			double[][] active;
			private int typeing2;
			private BufferedImage[] data;
	
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void update() {
			
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						
						if(grid[x][y].contains(mouseX, mouseY)&&mousePressed) {
							if(grid[x][y].contains(mouseX, mouseY)&&isKeyPressed(KeyEvent.VK_SHIFT)) {
								active[x][y]=0;
						
							}else{
								active[x][y]=1;
								
							}
						
							currentguess=network.getOUT2(streach(active),0);
							currentNUM = MAX(currentguess);
							//System.out.println(network.toString(streach(active)));
						}
					}
				}
if(isKeyPressed(KeyEvent.VK_C)) {
	active=new double[rez][rez];
}
				for(int i =0;i<10;i++) {
				if(isKeyPressed(KeyEvent.VK_0+i)&&(typeing!=i)&&!isKeyPressed(KeyEvent.VK_U)) {
					double[] vals = new double[10];
					for(double val:vals) {
						val =0;
					}
					vals[i]=1;
					
					network.RunAI(streach(active),vals,0.5);
					//System.out.println(network.layers[0].ider+"");
					typeing=i;
				}else if(!isKeyPressed(KeyEvent.VK_0+i)&&typeing==i){
					typeing=-1;
				}
				}
			
				if(isKeyPressed(KeyEvent.VK_R)) {
					network.Randomize(0.5);
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_T)&&typeing2==-1) {
					typeing2 = 1;
					data=new BufferedImage[network.outputSize];
					for(int i=0;i<data.length;i++) {
						data[i]=new BufferedImage(rez*20,rez*20,1);
						
						}
					for(int x=0;x<rez-1;x++) {
						for(int y=0;y<rez-1;y++) {
							double[][] dat=new double[rez][rez];
							dat[x][y]=1;
							double[] currentgues=network.getOUT2(streach(dat),0);
							for(int i=0;i<data.length;i++) {
								for(int x2=0;x2<rez;x2++) {
									for(int y2=0;y2<rez;y2++) {
								data[i].setRGB(x*20+x2, y*20+y2, new Color((int)(255.0*currentgues[i]),(int)(255.0*currentgues[i]),(int)(255.0*currentgues[i])).getRGB());
									}
								}
									}
						}
					}
					//System.out.println(network.toString(streach(active)));
				}else if(!isKeyPressed(KeyEvent.VK_T)){
					typeing2=-1;
				}
				if(isKeyPressed(KeyEvent.VK_E)) {
					try {
						network.Export(new File("src/AI2/AIW.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_I)) {
					try {
						network.Import(new File("src/AI2/AIW.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_X)) {
					try {
						if(on) {
						network.ExportSets(new File("src/AI2/DataSet.dat"),JOptionPane.showConfirmDialog(this, "do you not want to erase all perivious datasets?")==1);
						on = false;
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}else {
					on=true;
				}
				if(isKeyPressed(KeyEvent.VK_M)) {
					try {
						network.ImportSets(new File("src/AI2/DataSet.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				
			}
		boolean on =true;
			private int MAX(double[] in) {
				int out = 0;
				for(int i = 0;i<in.length;i++) {
					if(in[i]>in[out]) {
						out=i;
					}
				}
				return out;
			}

			private double[] streach(double[][] active) {
				double[] out = new double[active.length*active.length];
				int count =0;
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						out[count]=active[x][y];
						count++;
					}
				}
				return out;
			}
			int currentNUM = 0;
			double[] currentguess;
			int typeing =-1;
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				g2.setColor(Color.BLACK);
				g2.fillRect(0, 0, rez*20, rez*20);
			
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						if(active[x][y]==1) {
							g2.setColor(Color.WHITE);
							g2.fill(grid[x][y]);
						}
					}
				}
				for(int i =0;i<network.outputSize;i++) {
				if(isKeyPressed(KeyEvent.VK_0+i)&&isKeyPressed(KeyEvent.VK_U)) {
					g2.drawImage(data[i],0,0,this);
				
			
				
							
				}
				}
				g2.setColor(Color.GREEN);
				if(currentguess!=null) {
				for(int i =0;i<currentguess.length;i++) {
				g2.drawString(i+"   :   "+currentguess[i],20,i*20+20);
				}
				g2.setColor(Color.YELLOW);
				
				g2.drawString(currentNUM+" : "+currentguess[currentNUM],20,220);
				}
				g2.dispose();
				
			}
			ReEnforcedAI network;
			@Override
			public void initialize() {
			network = new ReEnforcedAI(new int[] {rez*rez,rez*rez/4,rez,10}, 10,1,0);
				grid=new Rectangle[rez][rez];
				active=new double[rez][rez];
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						grid[x][y]=new Rectangle(x*20,y*20,20,20);
					}
				}
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						active[x][y]=0;
					}
				}


			
			}
			
			
		};




	}

}
