package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.swing.JFrame;

import AI2.Brain;
import Screens.RefreshScreen;

public class BrainTester {
	
	public static void main(String[] args) {
		int rez = 32;
		new RefreshScreen(rez*20,rez*20,Color.black,60,3) {
			Rectangle[][] grid;
			double[][] active;
	
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void update() {
			
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						
						if(grid[x][y].contains(mouseX, mouseY)&&mousePressed) {
							if(grid[x][y].contains(mouseX, mouseY)&&isKeyPressed(KeyEvent.VK_SHIFT)) {
								active[x][y]=0;
						
							}else{
								active[x][y]=1;
								
							}
						
							currentguess=network.getOUT2(streach(active),0);
							currentNUM = MAX(currentguess);
							//System.out.println(network.toString(streach(active)));
						}
					}
				}
if(isKeyPressed(KeyEvent.VK_C)) {
	active=new double[rez][rez];
}
				for(int i =0;i<10;i++) {
				if(isKeyPressed(KeyEvent.VK_0+i)&&(typeing!=i)) {
					double[] vals = new double[10];
					for(double val:vals) {
						val =0;
					}
					vals[i]=1;
					
					network.Train(streach(active),vals,0.5);
					//System.out.println(network.layers[0].ider+"");
					typeing=i;
				}else if(!isKeyPressed(KeyEvent.VK_0+i)&&typeing==i){
					typeing=-1;
				}
				}
				if(isKeyPressed(KeyEvent.VK_ENTER)) {
					network.applyTrainedVals();
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_R)) {
					network.Randomize(1);
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_E)) {
					try {
						network.Export(new File("src/AI2/AIW.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_I)) {
					try {
						network.Import(new File("src/AI2/AIW.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				
			}
			private int MAX(double[] in) {
				int out = 0;
				for(int i = 0;i<in.length;i++) {
					if(in[i]>in[out]) {
						out=i;
					}
				}
				return out;
			}

			private double[] streach(double[][] active) {
				double[] out = new double[active.length*active.length];
				int count =0;
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						out[count]=active[x][y];
						count++;
					}
				}
				return out;
			}
			int currentNUM = 0;
			double[] currentguess;
			int typeing =-1;
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				g2.setColor(Color.BLACK);
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						if(active[x][y]==1) {
							g2.setColor(Color.WHITE);
						}else {
							g2.setColor(Color.BLACK);	
						}
						g2.fill(grid[x][y]);
					}
				}
				g2.setColor(Color.GREEN);
				if(currentguess!=null) {
				for(int i =0;i<currentguess.length;i++) {
				g2.drawString(i+"   :   "+currentguess[i],20,i*20+20);
				}
				g2.setColor(Color.YELLOW);
				
				g2.drawString(currentNUM+" : "+currentguess[currentNUM],20,220);
				}
				g2.dispose();
				
			}
			Brain network;
			@Override
			public void initialize() {
			network = new Brain(new int[] {rez*rez,rez*rez/4,rez,10},Brain.A_SIG,Brain.C_SE);
				grid=new Rectangle[rez][rez];
				active=new double[rez][rez];
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						grid[x][y]=new Rectangle(x*20,y*20,20,20);
					}
				}
				for(int x=0;x<rez;x++) {
					for(int y=0;y<rez;y++) {
						active[x][y]=0;
					}
				}


			
			}
			
			
		};




	}

}
