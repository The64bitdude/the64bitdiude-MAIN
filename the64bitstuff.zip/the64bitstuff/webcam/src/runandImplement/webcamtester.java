package runandImplement;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import com.github.sarxos.webcam.Webcam;

import Screens.RefreshScreen;

public class webcamtester {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				SystemCamera=Webcam.getDefault();
				SystemCamera.open();
			
				img = SystemCamera.getImage();
				this.setSize(new Dimension(img.getWidth()*2,img.getHeight()*2));
				this.setPreferredSize(new Dimension(img.getWidth()*2,img.getHeight()*2));
				screenWidth=img.getWidth()*2;
				screenHeight=img.getHeight()*2;
			}

			@Override
			public void update() {
				img = SystemCamera.getImage();
				
			}

			@Override
			public void paint(Graphics g) {
				if(img !=null) {
			g.drawImage(img,0,0,this);
				}
				g.drawImage(getColor(img,new Color(255,0,0),0,0),img.getWidth(),img.getHeight(),this);
				g.drawImage(subtract(img,getColor(img,new Color(mouseX*255/screenWidth,255-((mouseX*mouseY)*255/(screenWidth*screenHeight)),mouseY*255/screenHeight),0,0)),img.getWidth(),0,this);
				g.drawImage(getBW(img,0,200),0,img.getHeight(),this);
				g.dispose();
				
			}
			public BufferedImage getBW(BufferedImage img2,int brightness,int contrast) {
				BufferedImage out = new BufferedImage(img2.getWidth(),img2.getHeight(),1);
				for(int x=0;x<img2.getWidth();x++) {
					for(int y=0;y<img2.getHeight();y++) {
						Color color=new Color(img2.getRGB(x, y));
					double average =color.getBlue()*color.getRed()*color.getGreen()/(255.0*255.0);
				average = (average>(255-contrast))?255:average*255.0/(255-contrast);
					average*=(255-brightness)/255.0;
					average+=brightness;
				
						out.setRGB(x, y,new Color((int)average,(int)average,(int)average).getRGB());
				
					}
				}
				return out;
			}
			public BufferedImage subtract(BufferedImage img2,BufferedImage img3) {
				BufferedImage out = new BufferedImage(img2.getWidth(),img2.getHeight(),1);
				for(int x=0;x<img2.getWidth();x++) {
					for(int y=0;y<img2.getHeight();y++) {
						Color color1=new Color(img2.getRGB(x, y));
						Color color2=new Color(img3.getRGB(x, y));
				
						out.setRGB(x, y,new Color((color1.getRed()-color2.getRed())>0?color1.getRed()-color2.getRed():0,(color1.getGreen()-color2.getGreen())>0?color1.getGreen()-color2.getGreen():0,(color1.getBlue()-color2.getBlue())>0?color1.getBlue()-color2.getBlue():0).getRGB());
					}
					
				}
				return out;
			}
			public BufferedImage getColor(BufferedImage img2, Color c,int brightness,int contrast) {
				BufferedImage out = new BufferedImage(img2.getWidth(),img2.getHeight(),1);
				for(int x=0;x<img2.getWidth();x++) {
					for(int y=0;y<img2.getHeight();y++) {
						Color color=new Color(img2.getRGB(x, y));
				
						double r =color.getRed();
						r = (r>(255-contrast))?255:r*255.0/(255.0-contrast);
						r*=(255-brightness)/255.0;
						r+=brightness;
						double g =color.getGreen();
						g = (g>(255-contrast))?255:g*255.0/(255.0-contrast);
						g*=(255-brightness)/255.0;
						g+=brightness;
						double b =color.getBlue();
						b = (b>(255-contrast))?255:b*255.0/(255.0-contrast);
						b*=(255-brightness)/255.0;
						b+=brightness;
						
						out.setRGB(x, y,new Color((int)(r*c.getRed()/255),(int)(g*c.getGreen()/255),(int)(b*c.getBlue()/255)).getRGB());
				
					}
				}
				return out;
			}
			BufferedImage img;
Webcam SystemCamera;
			@Override
			public void initialize() {
			
		
			
				
				
			}
			
		};

	}

}
