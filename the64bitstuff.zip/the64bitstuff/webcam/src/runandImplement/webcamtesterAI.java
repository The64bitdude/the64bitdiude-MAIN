package runandImplement;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import com.github.sarxos.webcam.Webcam;

import AI2.ReEnforcedAI;
import Screens.RefreshScreen;

public class webcamtesterAI {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				SystemCamera=Webcam.getDefault();
				SystemCamera.open();
			
				img = SystemCamera.getImage();
				this.setSize(new Dimension(img.getWidth(),img.getHeight()));
				this.setPreferredSize(new Dimension(img.getWidth(),img.getHeight()));
				screenWidth=img.getWidth();
				screenHeight=img.getHeight();
				
			}

			@Override
			public void update() {
			
				img = SystemCamera.getImage();
				if(mousePressed) {
					AI.RunAI(getData(img), new double[] {AI.normalize(mouseX,this.getSize().width,0),AI.normalize(mouseX,this.getSize().height,0)},0.03);
					System.out.println("\n"+mouseX+" "+this.getSize().width);
					System.out.println(mouseY+" "+this.getSize().height);
				System.out.println("\n"+AI.normalize(mouseX,this.getSize().width,0));
				System.out.println(AI.normalize(mouseY,this.getSize().height,0));
				double[] out = AI.getOUT2(getData(img), 0);
				System.out.println(out[0]);
				System.out.println(out[1]);
				}
				
			}

			private double[] getData(BufferedImage img2) {
				double[] out=new double[img2.getWidth()*img2.getHeight()/2500];
				int i =0;
				for(int x=0;x<img2.getWidth()-10;x+=50) {
					for(int y=0;y<img2.getHeight()-10;y+=50) {
						out[i]=img2.getRGB(x, y);
						i++;
					}
				}
				return out;
			}

			@Override
			public void paint(Graphics g) {
				if(img !=null) {
			g.drawImage(img,0,0,this);
				}
				double[] out = AI.getOUT2(getData(img), 0);
			
				int x=(int) AI.denormailize(out[0],this.getSize().width,0);
				int y=(int) AI.denormailize(out[1],this.getSize().height,0);
				g.setColor(Color.GREEN);
				g.fillRect(x-10,y-10,20,20);
				g.dispose();
				
			}
			
			BufferedImage img;
Webcam SystemCamera;
private ReEnforcedAI AI;

			@Override
			public void initialize() {
			AI=new ReEnforcedAI(new int[] {screenWidth*screenHeight/2500,100,2}, -1, Integer.MAX_VALUE, Integer.MIN_VALUE);

			
				
				
			}
			
		};

	}

}
