package runandImplement;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

import javax.imageio.ImageIO;

import dataServer2.ByteImage;




public class ClientTester {

	public static void main(String[] args) {
		try {
			Socket s = new Socket("10.209.48.133",1234);
			
			OutputStream o = s.getOutputStream();
			new Thread(new ConnectionPrinter(s,0)).start();;
			Scanner in = new Scanner(System.in);
			String ea="hello world";
			while(!ea.equals("0")) {
			ea =in.nextLine();
			o.write((ea+" ").getBytes());
			}
			in.close();
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	
		}
	}


