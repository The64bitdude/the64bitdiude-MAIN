package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import Screens.RefreshScreen;

public class jPaint {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void update() {
				// TODO Auto-generated method stub
				
			}
int black =255;
BufferedImage colors;
			@Override
			public void paint(Graphics g) {
				g.drawImage(colors, 0,0, this);
			
				
			}

			@Override
			public void initialize() {
				colors=new BufferedImage(4073,4073,2);
				int count=0;
				for(int x=0;x<255;x++ ) {
					for(int y=0;y<255;y++ ) {
						for(int z=0;z<255;z++ ) {
							int color=new Color(x,y,z).getRGB();
				
							System.out.println(count%4073+","+count/4073+","+color);
							colors.setRGB(count%4073, count/4073, color);
							count++;
						}
					}
				}
				
			}
			
		};

	}

}
