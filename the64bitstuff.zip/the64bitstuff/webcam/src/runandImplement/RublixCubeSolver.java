package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;

import javax.swing.JFrame;

import GameTypes.ButtonG;
import Screens.RefreshScreen;

public class RublixCubeSolver {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void update() {
				int index=0;
				for(ButtonG b:buttons) {
					if(b.isClicked(mouseX, mouseY, this.rightMousePressed)&&b.pos!=4) {
						int hold=b.state+0;
					b.state=holdstate;
					
					buttons.get(lastIndex).state=hold;
					lastIndex=index;
				
					}
					if(b.isClicked(mouseX, mouseY, this.leftMousePressed)&&b.pos!=4) {
						holdstate=b.state;
						lastIndex=index;
					}
					index++;
					
				}
				
			}
			int holdstate=0;
			int lastIndex=0;
			//0 green
			//1 red 
			//2 white
			//3 orange
			//4 blue 
			//5 yellow
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				g2.fillRect(0,0,screenWidth,screenHeight);
				g2.setColor(Color.white);
			int count1=0;
			int count2=0;
			int count3=0;
			int count4=0;
			int count5=0;
			int count6=0;
			int index=0;
			for(ButtonG b:buttons) {
				g2.setColor(Color.white);
				switch(b.state) {
				case 0: g2.setColor(Color.green);count1++;break;
				case 1 : g2.setColor(Color.red);count2++;break;
				case 2 : g2.setColor(Color.white);count3++;break;
				case 3 : g2.setColor(Color.orange);count4++;break;
				case 4 : g2.setColor(Color.blue);count5++;break;
				case 5 : g2.setColor(Color.yellow);count6++;
				}
			
				g2.fill(b);
				if(lastIndex==index) {
					g2.fill(new Rectangle(40,20,41,41));
					g2.setColor(Color.MAGENTA);
					g2.draw(b);
					
				}
				g2.setColor(Color.black);
				g2.drawString(b.side+":"+b.pos+":"+b.state,b.x+10,b.y+20);
				index++;
			}
			g2.setColor(Color.GREEN);
			g2.drawString(count1+"",20,200);
			g2.setColor(Color.red);
			g2.drawString(count2+"",20,220);
			g2.setColor(Color.white);
			g2.drawString(count3+"",20,240);
			g2.setColor(Color.orange);
			g2.drawString(count4+"",20,260);
			 g2.setColor(Color.blue);
			g2.drawString(count5+"",20,280);
			 g2.setColor(Color.yellow);
			g2.drawString(count6+"",20,300);
			if((count1==count2)&&(count1==count3)&&(count1==count4)&&(count1==count5)&&(count1==count6)) {
				
				g2.drawString("true",20,320); 
				
			}else {
			
				g2.drawString("false",20,320);
			}
				g2.dispose();
			}
		
			ArrayList<ButtonG> buttons;
			@Override
			public void initialize() {
				buttons=new ArrayList<ButtonG>();
				int count2= 0;
				for(int i=0;i<6;i++){
					int ix=0;
					int iy=0;
					switch(i) {
					
					case 0:ix = 250-61;iy=1;break;
					case 1:ix = 250-61-41*3;iy=1+41*3;break;
					case 2:ix = 250-61;iy=1+41*3;break;
					case 3:ix = 250-61+41*3;iy=1+41*3;break;
					case 4:ix = 250-61;iy=1+41*6;break;
					case 5:ix = 250-61;iy=1+41*9;break;
					
					}
					int count = 0;
					for(int x=0;x<3;x++) {
						for(int y=0;y<3;y++) {
							buttons.add(new ButtonG(x*41+ix,y*41+iy,40,40,i,count,count2));
							count++;
							count2++;
						}
					}
				}
				
			}
			
		};
	}
}
