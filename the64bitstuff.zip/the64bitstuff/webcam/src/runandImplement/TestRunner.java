package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import ImageMinipulation.ImageEditor;
import Screens.RefreshScreen;
import Systems.Graphics3D;

public class TestRunner {
	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.BLACK,60,3) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				frame.setTitle("bobs tips and triks");
			}

			@Override
			public void update() {
				if(isKeyPressed(KeyEvent.VK_I)) {
					image = 0;
				}
if(isKeyPressed(KeyEvent.VK_U)) {
					image = 1;
				}
if(isKeyPressed(KeyEvent.VK_O)) {
	image = 3;
}
if(isKeyPressed(KeyEvent.VK_H)) {
	draw = true;
}
if(isKeyPressed(KeyEvent.VK_G)) {
	draw = false;
}
				
			}

			@Override
			public void paint(Graphics g) {
				g.setColor(Color.BLACK);
				g.fillRect(0,0, screenWidth*4, screenHeight*4);
				g.setColor(Color.WHITE);
				Polygon p = new Polygon();
				Polygon p2 = new Polygon();
				Polygon p3 = new Polygon();
				Polygon p4 = new Polygon();
				p.addPoint(0, 0);
				p.addPoint(100, 50);
				p.addPoint(150, 100);
				p.addPoint(50, 50);
			
				p2.addPoint(0, 100);
				p2.addPoint(100, 75);
				p2.addPoint(150, 0);
				p2.addPoint(50, 25);
				
				p3.addPoint(0,0);
				p3.addPoint(100, 0);
				p3.addPoint(mouseX-200,mouseY-200);
				p3.addPoint(0,100);
				
				p4.addPoint(0, 100);
				p4.addPoint(0, 200);
				p4.addPoint(150, 0);
				p4.addPoint(50, 25);
				
			
				Graphics3D g3 = new Graphics3D(g);
				if(draw) {
				g3.drawImage(p,image>0?image>1?test3:test2:test,128,0,0);
				g3.drawImage(p2,image>0?image>1?test3:test2:test,128,200,2);
				g3.drawImage(p3,image>0?image>1?test3:test2:test,016,200,200);
				g3.drawImage(p4,image>0?image>1?test3:test2:test,128,0,200);
				}else {
					g3.fillImage(p,image>0?image>1?test3:test2:test,128,0,0);
					g3.fillImage(p2,image>0?image>1?test3:test2:test,128,200,2);
					g3.fillImage(p3,image>0?image>1?test3:test2:test,128,200,200);
					g3.fillImage(p4,image>0?image>1?test3:test2:test,128,0,200);
		}
				
				g3.dispose();
				
			}
			int image = 0;
			boolean draw =false;
			public BufferedImage test;
			public BufferedImage test2;
			public BufferedImage test3;
			@Override
			public void initialize() {
			
				try {
					test = ImageIO.read(new File("src/Images/testImage.jpg"));
					test2 = ImageIO.read(new File("src/Images/grid.jpg"));
					test3 = ImageIO.read(new File("src/Images/bobross.jpg"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}

		};
	}
}
