package runandImplement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class encript_test {
public static void main(String[] args) {
	//4294967296L
	String in=new Scanner(System.in).nextLine();
	System.out.println("+ & -");
	String in2=new Scanner(System.in).nextLine();
	System.out.println("=");
	
	in =clean(in);
	in2 =clean(in2);
	String ins = sub(in2,in);
	String ina = add(in2,in);
	//ina=subadd(new long[] {4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L},4294967296L);
	long[] passv=subdivide(ina,10L);
	long[] passv3=subdivide(ina,4294967296L);
	long[] passv2=subdivide(ins,4294967296L);
	String j="";
	
	System.out.println(subadd(passv,10L));
	System.out.println(subadd(passv2,4294967296L));
	
	//System.out.println(Arrays.toString(subdivide(subadd(passv,4294967296L),4294967296L)));
	System.out.println(Arrays.toString(hex(passv3)));
	System.out.println(Arrays.toString(hex(passv2)));
	System.out.println(toString(passv));
	System.out.println(Arrays.toString(passv));
	System.out.println(Arrays.toString(passv2)+"\n");
	
	/*in=add(in,"1");
	
while(!j.equals(in)) {
	
	//String[] inv=hexsub(in,6);
	String k=j;
	new Thread(new Runnable() {
		public void run() {
		long[] passv=subdivide(k,4294967296L);
		//passv=new long[] {4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L,4294967295L};

		//System.out.println(Long.parseLong("ffffffff",16));
		//System.out.println(in);
		//System.out.println(Arrays.toString(inv));
		System.out.println(subadd(passv,4294967296L));
		//System.out.println(Arrays.toString(subdivide(subadd(passv,4294967296L),4294967296L)));
		System.out.println(Arrays.toString(hex(passv)));
		System.out.println(Arrays.toString(passv)+"\n");
		}
	}).start();
	
j=add(j,"1");
}*/


}
private static String toString(long[] passv) {
	String out="";
	for(long l :passv) {
		out+=l;
	}
	return out;
}
long[] untobase10String(String in){
	char[] vals= in.toCharArray();
	long[] out=new long[in.length()];
	int i =0;
	for(char c:vals) {
		out[i]=(int)(c-48);
		i++;
	}
	return out;
	
}
private static String tobaseString(long[] passv,int startchar) {
	String out="";
	for(long l :passv) {
		out+=(char)(l+startchar);
	}
	return out;
}
static long[] untoString(String in,int startchar){
	char[] vals= in.toCharArray();
	long[] out=new long[in.length()];
	int i =0;
	for(char c:vals) {
		out[i]=(long)(c-startchar);
		i++;
	}
	return out;
	
}
private static String clean(String in) {
	for(int i =0;i<in.length();i++) {
		try {
			Long.parseLong(in.substring(i, i+1),36);
		
		}catch(Exception e) {
		
			in=in.substring(0, i)+in.substring(i+1);
			i--;
		
		}
	
	}
	return in;
}
private static String[] str(long[] passv) {
	String[] out = new String[passv.length];
	for(int i =0;i<passv.length;i++) {
		out[i]=Long.toString(passv[i],36);
	}
	return out;
}
private static String[] hex(long[] passv) {
	String[] out = new String[passv.length];
	for(int i =0;i<passv.length;i++) {
		out[i]=Long.toHexString(passv[i]);
	}
	return out;
}
private static long[] subdivide(String in, long n) {
	double val=in.length()/(Math.log(n)/Math.log(36));
	long[] out = new long[(int) Math.ceil(val)];
	int i=0;
	//System.out.println(val);
	while(i<out.length) {
		out[i]=remainder(in,n);
		in=div(in,n);
		//System.out.println(in);
		i++;
	}
	
	
	out=reverse(out);
		return out;
	}
private static long[] reverse(long[] in) {
	long[] out=new long[in.length];
	for(int i=0;i<=in.length/2;i++) {
	
		out[i]=in[in.length-1-i];
		out[in.length-1-i]=in[i];
		
	}
	
	return out;
}
private static String subadd(long[] in, long n) {
	in=reverse(in);
	String out="";
	int i=0;
	for(long val:in) {
		
		out =add(out,mul(val,pow(n,i)));
		i++;
	}
	
	
	
	
		return out;
	
	}

private static String add(String in, String mul) {
	String out ="";
	long carryover=0;
	//System.out.println(in+" "+mul);
	int k=Math.min(in.length(),mul.length())-1;
	for(int i =Math.max(in.length(),mul.length())-1;i>=0;i--) {
		long inv=(in.length()>mul.length())?Long.parseLong(in.substring(i, i+1),36):((k>=0)?Long.parseLong(in.substring(k, k+1),36):0);
		long inv2=(in.length()>mul.length())?((k>=0)?Long.parseLong(mul.substring(k, k+1),36):0):Long.parseLong(mul.substring(i, i+1),36);
		long sum=inv2+inv+carryover;
		carryover=sum/36;
		out=Long.toString(sum%36,36)+out;
		k--;
	}
	out=(carryover>0?Long.toString(carryover,36):"")+out;
	return out;
	
}
private static String sub(String in, String mul) {
	if(in.length()>mul.length()) {
		String buf=in;
		in=mul;
		mul=buf;
	}else if(in.length()==mul.length()){
		for(int i =0;i<in.length();i++) {
		if(in.charAt(i)>mul.charAt(i)) {
			String buf=in;
			in=mul;
			mul=buf;
			i=in.length();
		}
		}
	}
	String out ="";
	long carryover=0;
	//System.out.println(in+" "+mul);
	int k=Math.min(in.length(),mul.length())-1;
	for(int i =Math.max(in.length(),mul.length())-1;i>=0;i--) {
		long inv=(in.length()>mul.length())?Long.parseLong(in.substring(i, i+1),36):((k>=0)?Long.parseLong(in.substring(k, k+1),36):0);
		long inv2=(in.length()>mul.length())?((k>=0)?Long.parseLong(mul.substring(k, k+1),36):0):Long.parseLong(mul.substring(i, i+1),36);
	
		long sum=inv2-inv-carryover;
		if(sum<0) {
			 sum+=36;
			 carryover=1;
		 }else {
			 carryover=0;
		 }
		out=Long.toString(sum,36)+out;
		k--;
	}
	out=(carryover>0?Long.toString(carryover,36):"")+out;
	return out;
	
}

private static String mul( long val, String in) {
	String out="";
	//System.out.println(val+" "+in);
	for(int i=in.length()-1;i>=0;i--) {
		long inv=Long.parseLong(in.substring(i, i+1),36);
		out = add(out,pow32(val*inv,in.length()-1-i));
	}
	
	return out;
}

private static String pow32(long v, int n) {
	String pow="";
	pow+=Long.toString(v, 36);
	for(int i=0;i<n;i++ ) {
		pow+="0";
	}
	return pow;
}
private static String pow(long val, long n) {

	String out="1";
	for(long k=0;k<n;k++) {
		
		out=mul(val,out);
	}
	//System.out.println(Long.parseLong(out,36));
	// TODO Auto-generated method stub
	return out;
}
private static String div(String in, long n) {
	// TODO Auto-generated method stub
	return div(in,n,0,0);
}
private static String div(String in, long n,long ext,int index) {
//	System.out.println(in+" "+n+" "+ext+" "+index);
	if(index+1<=in.length()) {
	String eval=Long.toString(ext,36);
	long val=Long.parseLong(eval+in.substring(index, index+1),36);
	if(val<n) {
		in=in.substring(0,index)+"0"+in.substring(index+1);
		return div(in,n,val,index+1);
	}else {
		in=in.substring(0,index)+Long.toString(val/n,36)+in.substring(index+1);
		return div(in,n,val%n,index+1);
	}
	}
	return in;
}

private static long remainder(String in, long n) {
	
	
	return remainder(in,n,0,0);
}
private static long remainder(String in, long n,long ext,int index) {
//	System.out.println(in+" "+n+" "+ext+" "+index);
	if(index+1<=in.length()) {
	String eval=Long.toString(ext,36);
	long val=Long.parseLong(eval+in.substring(index, index+1),36);
	if(val<n) {
		in=in.substring(0,index)+"0"+in.substring(index+1);
		return remainder(in,n,val,index+1);
	}else {
		in=in.substring(0,index)+Long.toString(val/n,36)+in.substring(index+1);
		return remainder(in,n,val%n,index+1);
	}
	}
	return ext;
}

private static String[] hexsub(String in, int n) {
int val=(int)Math.ceil(in.length()/((double)n));
String[] out = new String[val];
for(int i=0;i<val-1;i++) {
	
	out[i]=Long.toHexString(Long.parseLong(in.substring(i*n,(i+1)*n ), 36));
}
out[val-1]=Long.toHexString(Long.parseLong(in.substring((val-1)*n ), 36));
	return out;
}
private static String[] valsub(String in, int n,int regex) {
int val=(int)Math.ceil(in.length()/((double)n));
String[] out = new String[val];
for(int i=0;i<val-1;i++) {
	
	out[i]=Long.toHexString(Long.parseLong(in.substring(i*n,(i+1)*n ), 36));
}
out[val-1]=Long.toHexString(Long.parseLong(in.substring((val-1)*n ), 36));
	return out;
}


}
