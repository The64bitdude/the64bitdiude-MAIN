package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;

import AI2.Brain;

import AI2.RewardedBasedAI;
import AI2.UnsupervisedAI;
import Screens.RefreshScreen;

public class generationalAITester {
	public static void main(String[] args) {
	new RefreshScreen(500,500,Color.BLACK,-1,3) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}
int aix=250;
int aiy=250;
int ai2x=250;
int ai2y=250;
int tx=250;
int ty=250;
int frame=0;
long times=0;
long times2=0;
		@Override
		public void update() {
			if(this.mousePressed) {
				tx=mouseX;
				ty=mouseY;
			}
		int dx = tx-aix;
		int dy=ty-aiy;
		if(!isKeyPressed(KeyEvent.VK_G)&&(frame>30)&&(frame<60)) {
network.addSingularStates(new double[] {network.normalize(tx, 500, 0),network.normalize(ty, 500, 0),network.normalize(aix, 500, 0),network.normalize(aiy, 500, 0)}, 0.01);
		
		}else if(frame>30){
			frame=0;
		}else {
			frame++;
		}
		
			
double[] out=network.getOut(new double[] {network.normalize(tx, 500, 0),network.normalize(ty, 500, 0),network.normalize(aix, 500, 0),network.normalize(aiy, 500, 0)});

//double[] out2=perfect(new double[] {network.normalize(tx, 500, 0),network.normalize(ty, 500, 0),network.normalize(ai2x, 500, 0),network.normalize(ai2y, 500, 0)});

int maxi =0;
int maxi2 =0;	
			for(int i =0;i<out.length;i++) {
			
				if(out[i]>out[maxi]) {
					maxi=i;
					
				}
				/*if(out2[i]>out2[maxi2]) {
					maxi2=i;
					
				}*/
			
			}
		
			switch(maxi) {
			case 0:aix-=1;break;
			case 1:aiy-=1;break;
			case 2:aix+=1;break;
			case 3:aiy+=1;break;
			}
			
			/*switch(maxi2) {
			case 0:ai2x-=1;break;
			case 1:ai2y-=1;break;
			case 2:ai2x+=1;break;
			case 3:ai2y+=1;break;
			}*/
			if(aix>500||aix<0) {
				aix=(int) (Math.random()*500);
				aiy=(int) (Math.random()*500);
			}
			if(aiy>500||aiy<0) {
				aix=(int) (Math.random()*500);
				aiy=(int) (Math.random()*500);
			
			}
			if(Math.sqrt(dx*dx+dy*dy)<5) {
				tx=(int) (Math.random()*500);
				ty=(int) (Math.random()*500);
				ai2x=(int) (Math.random()*500);
				ai2y=(int) (Math.random()*500);
			
			}
		
		}

		private double[] perfect(double[] inputs) {
			double maxreward=0;
			double[] maxout=new double[4];
			
			for(int i =0;i<4;i++) {
			double[] out=new double[4];
			out[i]=1;
			
			double rew = Reward(out,inputs);
			if(rew>maxreward) {
				maxreward =rew;
				maxout=out;
				
			}else if(rew>=maxreward){
				maxreward =rew;
				maxout[i]=1;
			}
			}
			
			return maxout;
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, screenWidth, screenHeight);
			g.setColor(Color.GREEN);
			g.fillRect(aix-5, aiy-5, 10, 10);
			g.setColor(Color.ORANGE);
			g.fillRect(ai2x-5, ai2y-5, 10, 10);
			g.setColor(Color.RED);
			g.drawRect(tx-5, ty-5, 10, 10);
			
			// TODO Auto-generated method stub
			
		}
		public double Reward(double[] out,double[] in) {
			int tempx=(int) (network.denormailize(in[2],500,0));
			int tempy=(int) (network.denormailize(in[3],500,0));
			int aix =tempx;
			int aiy=tempy;
			int tx=(int) network.denormailize(in[0],500,0);
			int ty=(int) network.denormailize(in[1],500,0);
			for(int i =0;i<out.length;i++) {
				if(out[i]==1) {
				switch(i) {
				case 0:tempx-=1;break;
				case 1:tempy-=1;break;
				case 2:tempx+=1;break;
				case 3:tempy+=1;break;
				}
				}
			}
			int dx = tx-tempx;
			int dy=ty-tempy;
			int d2x = tx-aix;
			int d2y=ty-aiy;
			return Math.sqrt(d2x*d2x+d2y*d2y)- Math.sqrt(dx*dx+dy*dy);
		}
	
boolean[][] grid;
RewardedBasedAI network;
		@Override
		public void initialize() {
			tx=(int) (Math.random()*500);
			ty=(int) (Math.random()*500);
	
			RewardedBasedAI network=new RewardedBasedAI(4,4,new int[] {500,100},0){

				@Override
				public double reward(double[] out,double[] in) {
					// TODO Auto-generated method stub
					return Reward(out,in);
				}

				
				
			}; 
			this.network=network;
				
			
	
			grid=new boolean[500][500];
			
		}
		
	};
	}
}
