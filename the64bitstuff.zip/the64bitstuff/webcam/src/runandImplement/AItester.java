package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;

import AI1.NeuralNetWork;
import Screens.RefreshScreen;

public class AItester {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.BLACK,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
			int x =0;
			int y =0;
			@Override
			public void update() {
				// TODO Auto-generated method stub
			x++;
			y++;
				
				AI.learn(0.2, new double[] {x,y}, new double[] {mouseX,mouseY}, 2,0);
				
			
			}

			@Override
			public void paint(Graphics g) {

				Graphics2D g2 = (Graphics2D)g;
				g2.fillRect(0,0,screenWidth,screenHeight);
				g2.setColor(Color.WHITE);
				//AI.ToDraw(g2,50);
				for(int x=0;x<200;x++) {
					for(int y=0;y<200;y++) {
					double[] out = AI.GetOut(new double[] {x,y});
		  		g2.fillRect((int)(out[0])-5,(int)out[1]-5,10,10);
					}
				}
				
				g2.dispose();
				
			}
			NeuralNetWork AI;
			@Override
			public void initialize() {
				
			AI=new NeuralNetWork(new int[]{20,50},2,2);	
			
			}};

	}

}
