package runandImplement;

import java.util.Arrays;
import java.util.Scanner;

import Systems.Encript;

public class runerENCH {

	public static void main(String[] args) {
		Scanner bob =new Scanner(System.in);
		String in = bob.nextLine();
		String pass = bob.nextLine();
		String val[] =Encript.encript(in,pass);
		System.out.println(val[0]);
		System.out.println(val[1]);
		System.out.println(Encript.decript(val[1], val[0]));
	}

}
