package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import AI2.Brain;
import AI2.UnsupervisedAI;
import Screens.RefreshScreen;

public class UnsupervisedAItester2d {
	
	public static void main(String[] args) {
		int rez = 32;
		new RefreshScreen(rez*20,rez*20,Color.black,60,3) {
			
			double[] active;
			private int typeing2;
			private int typeing3;
	
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void update() {
			
				
						
						if(this.mousePressed) {
							active=new double[2];
								active[0]=mouseX;
								active[1]=mouseY;
								
								
								currentguess=network.getOUT2(active,0);
								currentNUM = MAX(currentguess);
							//System.out.println(network.getOUT2(new double[] {mouseX,mouseY},0)[0]);
							//System.out.println(network.toString(streach(active)));
						}
						
				
if(isKeyPressed(KeyEvent.VK_C)) {
	network.TrainDATIN.clear();
	for(int i =0;i<network.outputSize;i++) {
	network.CT[i].clear();
	}
}
				
				if(isKeyPressed(KeyEvent.VK_ENTER)) {
					network.addData(active,10);
					
			
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_L)) {
					network.RunAI(0.03);
		
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_R)) {
					network.ResetClusters();
				}
				if(isKeyPressed(KeyEvent.VK_T)&&typeing2==-1) {
					typeing2 = 1;
					data=new BufferedImage[network.outputSize];
					for(int i=0;i<data.length;i++) {
						data[i]=new BufferedImage(rez*20,rez*20,1);
						
						}
					for(int x=0;x<rez*20;x++) {
						for(int y=0;y<rez*20;y++) {
							int xf=x;
							int yf=y;
							new Thread(new Runnable() {

								@Override
								public void run() {
							double[] currentgues=network.getOUT2(new double[] {xf,yf},0);
							for(int i=0;i<data.length;i++) {
								data[i].setRGB(xf, yf, new Color((int)((255.0*currentgues[i]/2.0)+255/2),(int)((255.0*currentgues[i]/2.0)+255/2),(int)((255.0*currentgues[i]/2.0)+255/2)).getRGB());
							}
}
								
							}).start();
						}
					}
					//System.out.println(network.toString(streach(active)));
				}else if(!isKeyPressed(KeyEvent.VK_T)){
					typeing2=-1;
				}
				if(isKeyPressed(KeyEvent.VK_Y)&&typeing3==-1) {
					typeing3 = 1;
					data=new BufferedImage[network.outputSize];
					for(int i=0;i<data.length;i++) {
						data[i]=new BufferedImage(rez*20,rez*20,1);
						
						}
					for(int x=0;x<rez*20;x+=20) {
						for(int y=0;y<rez*20;y+=20) {
							int xf=x;
							int yf=y;
							new Thread(new Runnable() {

								@Override
								public void run() {
									double[] currentgues=network.getOUT2(new double[] {xf,yf},0);
									for(int i=0;i<data.length;i++) {
										for(int k=0;k<20;k++){
											for(int k2=0;k2<20;k2++){
										data[i].setRGB(xf+k,yf+k2, new Color((int)((255.0*currentgues[i]/2.0)+255/2),(int)((255.0*currentgues[i]/2.0)+255/2),(int)((255.0*currentgues[i]/2.0)+255/2)).getRGB());
											}
											}
										}
									
								}
								
							}).start();
							
						}
					}
					//System.out.println(network.toString(streach(active)));
				}else if(!isKeyPressed(KeyEvent.VK_Y)){
					typeing3=-1;
				}
				if(isKeyPressed(KeyEvent.VK_E)) {
					try {
						network.Export(new File("src/AI2/AIW3.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_I)) {
					try {
						network.Import(new File("src/AI2/AIW3.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
				if(isKeyPressed(KeyEvent.VK_X)&&typeing==-1) {
					typeing = 1;
					try {
						network.ExportSets(new File("src/AI2/DataSet3.dat"),JOptionPane.showConfirmDialog(this, "do you want to erase all perivious datasets?")==JOptionPane.YES_OPTION);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}else if(!isKeyPressed(KeyEvent.VK_X)){
					typeing=-1;
				}
				if(isKeyPressed(KeyEvent.VK_M)) {
					try {
						network.ImportSets(new File("src/AI2/DataSet3.dat"));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//System.out.println(network.toString(streach(active)));
				}
			
				
			}
			private int MAX(double[] in) {
				int out = 0;
				for(int i = 0;i<in.length;i++) {
					if(in[i]>in[out]) {
						out=i;
					}
				}
				return out;
			}

			private double[] streach(double[][] active) {
				double[] out = new double[active.length*active.length];
				int count =0;
				for(int x=0;x<active.length;x++) {
					for(int y=0;y<active[x].length;y++) {
						out[count]=active[x][y];
						count++;
					}
				}
				return out;
			}
			private int streachIndex(int yS,int x,int y) {
				return x*yS+y;
			}
			
			int currentNUM = 0;
			double[] currentguess;
			int typeing =-1;
			BufferedImage[] data;
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				g2.setColor(Color.BLACK);
				g2.fillRect(0, 0, rez*20, rez*20);
			
				for(int i =0;i<network.outputSize;i++) {
					g2.setColor(Color.GREEN);
					
					
					if(isKeyPressed(KeyEvent.VK_0+i)) {
						g2.drawImage(data[i],0,0,this);
					
				
					
								
					}
					if(currentNUM==i) {
						g2.setColor(Color.YELLOW);
					}
					for(int V=0;V<network.CT[i].size();V++) {
					
						g2.drawLine((int)network.scaleUp(network.TrainDATIN.get(network.CT[i].get(V))[0]),(int)network.scaleUp(network.TrainDATIN.get(network.CT[i].get(V))[1]),(int)  network.scaleUp(network.CM[i][0]),(int) network.scaleUp(network.CM[i][1]));
					}	
					g2.setColor(Color.RED);		
					g2.fillRect((int)(network.scaleUp(network.CM[i][0])), (int)network.scaleUp(network.CM[i][1]),10,10);
							
						
					
				
				}
				
			
				
				g2.setColor(Color.GREEN);
				if(currentguess!=null) {
				for(int i =0;i<currentguess.length;i++) {
				g2.drawString(i+"   :   "+currentguess[i],20,i*20+20);
				}
				g2.setColor(Color.YELLOW);
				
				g2.drawString(currentNUM+" : "+currentguess[currentNUM],20,220);
				}
				g2.dispose();
				
			}
			UnsupervisedAI network;
			@Override
			public void initialize() {
			network = new UnsupervisedAI(new int[] {2,rez*rez/20,rez*20,rez,3},100,rez*20,0,UnsupervisedAI.A_TANH,UnsupervisedAI.C_SE);
				//network.addLayer(5, network.A_SIG, 1);
				active=new double[2];
				
			
					


			
			}
			
			
		};




	}

}
