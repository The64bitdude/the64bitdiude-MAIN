package runandImplement;

public class BasicsTester {

	public static void main(String[] args) {
		String val="-14";
		int from=10;
		int to=2;
		System.out.println(Integer.toString(Integer.parseInt(val, from),to));
		String x,y;
		x= "APLUS";
		y="APLUSCS";
		System.out.println(x.compareTo(y));
		
		
	}

}
