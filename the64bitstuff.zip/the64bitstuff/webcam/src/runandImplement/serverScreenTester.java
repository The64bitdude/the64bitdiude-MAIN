package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import javax.swing.JFrame;

import DataServer.DataServerScreen;
import DataServer.DataSystemScreen;
import DataServer.SBD;
import Screens.RefreshScreen;

public class serverScreenTester {

	public static void main(String[] args) {
		new DataServerScreen(500,500,Color.BLACK,60,1234) {
			boolean receved=false;
			@Override
			public SBD send() {
				// TODO Auto-generated method stub
				if(!receved) {
					return new SBD(1,StringData("test"));
				}else {
					return new SBD(1,StringData("ok"));
				}
			}

			@Override
			public void receive(String s) {
				System.out.println(s);
				receved=true;
			}

			@Override
			public void receive(BufferedImage image) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void define() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void itorate() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void paint(Graphics g) {
				// TODO Auto-generated method stub
				
			}

		};
	}

}
