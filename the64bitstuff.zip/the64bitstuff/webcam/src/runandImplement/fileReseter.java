package runandImplement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class fileReseter {

	public static void main(String[] args) {
		File readFile=new File("src/dataServer2/read.dat");
FileWriter e;
try {
	e = new FileWriter(readFile);
	e.write(" ");
} catch (IOException e2) {
	// TODO Auto-generated catch block
	e2.printStackTrace();
}


}}
