package runandImplement;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JFrame;

import Physics.Vector3D;
import Screens.RefreshScreen;
import Screens.RefreshScreen3D;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.PointD;
import Systems.PolygonWr;

public class VectorTesting {

	public static void main(String[] args) {
		new RefreshScreen3D(1000,750,Color.BLACK,60,3,70) {

			@Override
			public void Update() {
				defaultCameraMovement(5, true);
			
				camV=new Vector3D(Math.sin(camera.angle1)*Math.cos(camera.angle2),Math.cos(camera.angle1)*Math.cos(camera.angle2),Math.sin(camera.angle2));
				C=new Vector3D(Math.sin(camera.angle1 + Math.PI/2),Math.cos(camera.angle1+ Math.PI/2),0);

				D=camV.cross(C);
			
		
				
			}

			@Override
			public ArrayList<PolygonWr> calcPaint(Graphics3D g3) {
				// TODO Auto-generated method stub
				return null;
			}

	
			public int div=30;
			public int limit = 1;
			public int llimit = 800;
			public void drawFrame(Graphics3D g3) {
				g3.fillRect(0, 0, 1000, 750);
				
				g3.setColor(Color.WHITE);
				for(int j =-limit;j<limit;j+=div) {
				for(int k =-limit;k<limit;k+=div) {
					ArrayList<PointD> PS=new ArrayList<PointD>();
					Point before = null;
				for(int i =-llimit;i<llimit;i+=div) {
					
						g3.setColor(Color.WHITE);
					
				
				PointD a2=A.mul(i-div, i-div, i-div).translate(j, 0, k).getPoint().project(camera);
			PS.add(a2);
				PointD a1=A.mul(i, i, i).translate(j, 0, k).getPoint().project(camera);
				g3.drawString(i+"",a2.x,a2.y);
				//g3.drawString(a2.getDist()-a1.getDist()+"",a2.x,a2.y-i*20/div-60);
				if(before != null) {
					//g3.drawString("[X : "+(before.x-(a1.x-a2.x))+" ] , [Y : "+(before.y-(a1.y-a2.y))+" ]",a2.x,a2.y-i*20/div-40);
				}
				before = new Point((a1.x-a2.x),(a1.y-a2.y));
				//g3.drawString("[X : "+(a1.x-a2.x)+" ] , [Y : "+(a1.y-a2.y)+" ]",a2.x,a2.y-i*20/div-20);
				g3.drawPoint((a1.x-a2.x), (a1.y-a2.y));
				g3.drawLine(a2,a1);
				}
				for(PointD p:PS) {
					System.out.println(p.toString()+p.getDist());
				}
				for(int i =-llimit;i<llimit;i+=div) {
					
					g3.setColor(Color.WHITE);
				
			g3.drawString(i+"",B.mul(i-div, i-div, i-div).translate(0, j, k).getPoint().project(camera));
			g3.drawLine(B.mul(i-div, i-div, i-div).translate(0, j, k).getPoint().project(camera),B.div(1, 1, 1).mul(i, i, i).translate(0, j, k).getPoint().project(camera));
			}
				}
				}
				
				g3.setColor(Color.RED);
			g3.drawLine(new Point3D(0,0,0).project(camera),C.mul(100,100,100).getPoint().project(camera));

			g3.setColor(Color.BLUE);
			g3.drawLine(new Point3D(0,0,0).project(camera),D.mul(100,100,100).getPoint().project(camera));
			g3.setColor(Color.GREEN);
			g3.drawLine(new Point3D(0,0,0).project(camera),camV.mul(100,100,100).getPoint().project(camera));
			g3.drawLine(screenWidth/2, 0, (screenWidth/2), screenHeight);
			g3.drawLine(0,  screenHeight/2, screenWidth, screenHeight/2);
			g3.setColor(Color.ORANGE);
			g3.drawRect(-camera.panel/2+screenWidth/2, -camera.panel/2+screenHeight/2, camera.panel,camera.panel);
			g3.drawCirclePoint(-(camera.panel*(Math.tan(camera.angle1)/Math.cos(camera.angle2)))+screenWidth/2, -(camera.panel*Math.tan(camera.angle2))+screenHeight/2,10);
			
			}
			

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
Vector3D A;
Vector3D B;
Vector3D C;
Vector3D D;
Vector3D camV;
			@Override
			public void initialize() {
			A=new Vector3D(0,1,00);
			B=new Vector3D(1,0,0);
			C=new Vector3D(100,0,0);
			
			//D = A.cross(B);
			}

			@Override
			protected void preDrawFrame(Graphics3D g3) {
				// TODO Auto-generated method stub
				
			}
			
		};
	}

}
