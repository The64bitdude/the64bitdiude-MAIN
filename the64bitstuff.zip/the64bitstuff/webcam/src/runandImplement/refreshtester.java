package runandImplement;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

import Screens.RefreshScreen;

public class refreshtester {
 public static void main(String[] args) {
	 new RefreshScreen(500,500,Color.BLACK,60,3) {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void update() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void paint(Graphics g) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void initialize() {
			// TODO Auto-generated method stub
			
		}
		 
	 };
 }
}
