package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;

import Screens.RefreshScreen;
import Systems.DataManager;

public class AIpredataPrototype1 {
	static DataManager data;
	
public static void main(String[] args) {
	data = new DataManager();


	//System.out.println(data.toString("numbers"));
	new RefreshScreen(1000,750,Color.BLACK,60) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void update() {
			if(num<32000) {
			
			for(int i3 =1;i3<num;i3++) {
			for(int i =0;i<i3;i++) {

				//long time =System.nanoTime();
				data.addData("numbers",(int)(Math.random()*Integer.MAX_VALUE)+1);
				//System.out.println(System.nanoTime()-time + " ( "+i+" , "+ i2+ " ) ");
			
			}
			long time =System.nanoTime();
			//System.out.println( data.contains("numbers",1));
			//System.out.println(System.nanoTime()-time);
			//data.contains("numbers",1);
			//time =System.nanoTime();
			//System.out.println( data.duplicates("numbers"));
			data.duplicates("numbers");
			//System.out.println(System.nanoTime()-time);
			long time2=System.nanoTime()-time;
			if(i3==num-1) {
				graph.add(time2);
			}
			data.clear("numbers");
			}
			
			num+=32;
			}
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, screenWidth,screenHeight);
			g.setColor(Color.WHITE);
			for(int x=0;x<graph.size();x++) {
				g.drawLine(x, (int)((graph.get(x))/(1000)), x, (int)((graph.get(x))/(1000)));
			}
			g.dispose();
		}
int num;
ArrayList<Long> graph = new ArrayList<Long>();
		@Override
		public void initialize() {
			num = 1000;
			
			graph = new ArrayList<Long>();
			
		}
		
	};
}
}
