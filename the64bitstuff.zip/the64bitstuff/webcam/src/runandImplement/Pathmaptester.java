package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;

import AI1.Path;
import AI1.PathMap;
import Screens.RefreshScreen;

public class Pathmaptester {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,10,3) {

			
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
			boolean state=true;
			@Override
			public void update() {
			
				if(isKeyPressed(KeyEvent.VK_1)) {
					state = true;
				}
				if(isKeyPressed(KeyEvent.VK_2)) {
					state = false;
				}
				if(isKeyPressed(KeyEvent.VK_R)) {
					state = false;
					m.reset(15,15);
				}
				
				if(mousePressed) {
			
					m.setOBS(mouseX/16, mouseY/16, 	state);
				
							m.generate(startX, startY);
						
				}
			
			}
	
			@Override
			public void paint(Graphics g) {
				g.setColor(Color.black);
				g.fillRect(0, 0, screenWidth, screenHeight);
			
				Path p = m.findPath(startX, startY, mouseX/gridsize, mouseY/gridsize);
				g.setColor(Color.white);
				
					for(int x = 0;x<m.map.length;x++) {
						for(int y = 0;y<m.map[x].length;y++) {
							if(m.map[x][y]!=-1&&m.map[x][y]*(255.0/brightness)<255) {
								
								if(m.map[x][y]==0) {
									g.setColor(Color.BLACK);
								}else {
								g.setColor(new Color(255-(int)(m.map[x][y]*(255.0/brightness)),0,0));
								}
								g.fillRect(x*gridsize, y*gridsize, gridsize, gridsize);
								g.setColor(Color.BLACK);
								g.drawRect(x*gridsize, y*gridsize, gridsize, gridsize);
								g.setFont(g.getFont().deriveFont(gridsize*1.0f));
								g.drawString(""+m.map[x][y],x*gridsize,y*gridsize+gridsize);
								}
							
						}
					}
					for(int x = 0;x<m.map.length;x++) {
						for(int y = 0;y<m.map[x].length;y++) {
							
							if(m.map[x][y]==-1) {
							
							g.setColor(new Color(0,255,0));
							
							g.drawRect(x*gridsize, y*gridsize, gridsize,  gridsize);
							}
						}
					}
					
				g.setColor(Color.white);
				try {
				for(Point s :p.path) {
					g.drawRect(s.x*gridsize, s.y*gridsize, gridsize, gridsize);
				}
				}catch(Exception e) {
					
				}
				g.dispose();
			}
		double brightness=25;
			int gridsize=16;
			int startX = 15;
			int startY = 15;
			PathMap m ;
			@Override
			public void initialize() {
				int size = (int)Math.round(30.0*16/gridsize);
				m = new PathMap(size,size);
				
				/*for(int i = 0;i<50;i++) {
					for(int k = 0;k<50;k++) {
						if((int)(Math.random()*10)==1) {
						m.setOBS(i, k, true);
						}
						
						}
					}*/
				
				
			}
			
		};
		
	}

}
