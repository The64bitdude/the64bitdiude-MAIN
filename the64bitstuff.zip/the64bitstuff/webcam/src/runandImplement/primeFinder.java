package runandImplement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.TreeSet;

public class primeFinder {
 
 public static int OverEstimate(int Nprimes) {
	 return (int) Math.ceil(Math.PI*Nprimes*Math.log10(Nprimes+1.0)+2.0);
 }
 
 public static String[] roundHexPrimes(int Nprimes,double power) {
	 int endval=OverEstimate(Nprimes);
		
		
	 int[] primes =  primes(endval);
	 String[] vals = new String[Nprimes];
	
	 for(int i =0;i<Nprimes;i++) {
		 vals[i]= Double.toHexString(Math.pow(primes[i],power));
	
		
	 }
	 return vals;
 }
 public static int[] primes(int limit) {
	 ArrayList<Integer>  primes=new ArrayList<Integer>();
	 
	 for(Integer i =2;i<=limit;i++) {
		 primes.add(i);
		
	
	 }
	
	
	 for(Integer i=2;i<=primes.size();i++) {
		 ArrayList<Integer> oldprimes = new  ArrayList<Integer>();
		 oldprimes.addAll(primes);
		
		 for(int i2:oldprimes) {
			 primes.remove((Integer)(i*i2));
		 }
	

	 }
	int[] out = new int[primes.size()];
	
	 for(int i=0;i<primes.size();i++) {
		 out[i]=primes.get(i);
		
	 }
	 return out;
 }
 public static long[] primes(long limit) {
	 ArrayList<Long>  primes=new ArrayList<Long>();
	 
	 for(Long i =2L;i<=limit;i++) {
		 primes.add(i);
		
	
	 }
	
	
	 for(Long i=2L;i<=primes.size();i++) {
		 ArrayList<Long> oldprimes = new  ArrayList<Long>();
		 oldprimes.addAll(primes);
		
		 for(long i2:oldprimes) {
			 primes.remove((Long)(i*i2));
		 }
	

	 }
	long[] out = new long[primes.size()];
	
	 for(int i=0;i<primes.size();i++) {
		 out[i]=primes.get(i);
		
	 }
	 return out;
 }
 

}
