package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;

import Screens.RefreshScreen;
import Screens.RefreshScreen3D;
import Systems.Graphics3D;
import Systems.PolygonWr;

public class Teleprompter {

	public static void main(String[] args) {
	new RefreshScreen3D(500,500,Color.BLACK,60,3,70) {

		@Override
		public void Update() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public ArrayList<PolygonWr> calcPaint(Graphics3D g3) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void drawFrame(Graphics3D g3) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void initialize() {
			// TODO Auto-generated method stub
			
		}

		
		
	};

	}

}
