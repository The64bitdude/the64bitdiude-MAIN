package runandImplement;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.awt.Point;
import java.awt.Polygon;

import java.awt.RenderingHints;

import java.awt.Toolkit;

import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


import javax.imageio.ImageIO;

import javax.swing.JFrame;

import Screens.RefreshScreen;
import Systems.BlockMap;
import Systems.Camera;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.PointVector;
import Systems.PolygonWr;
import Systems.Rect3D;
import Systems.Shader;
import Systems.TCSIndex;




public class sim3D3Gridmap {

	public static void main(String[] args) {
		
		//Dimension e = Toolkit.getDefaultToolkit().getScreenSize();

		new RefreshScreen(1000,750,Color.BLACK,60,3) {

			private static final long serialVersionUID = 1L;
			BlockMap map;
			
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			
				frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Icon.png"));
				frame.setTitle("grid 3d thing");
				BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

				// Create a new blank cursor.
				Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
				    cursorImg, new Point(0, 0), "blank cursor");
				frame.getContentPane().setCursor(blankCursor);
				
				
				
			}
			double prevX =0;
			double prevY = 0;
			
			private boolean click = true;
			byte state = 1;
			int speed =8;
			int jumpspeed =0;
			int count =0;
			int lacount =0;
			int pigcount =0;
			int suncount =0;
			int gtime =0;
			int rendersize = 100;
					boolean hold =false;
					boolean hold2 =false;
					boolean hold3=false;
					boolean hold4=false;
					boolean hold5=false;
					boolean hold6=false;
					boolean gravity =false;
			 boolean paused = false;
			 boolean paused2 = false;
			boolean gridshow = false;
	
			private int rez = 16;
			private int rez2= 32;
		boolean flashlight=false;
			boolean dosun=true;
			
			public void update() {
		
			if(camera.cam.x>((sizeB-rendersize)*map.size)||camera.cam.x<(rendersize*map.size)||camera.cam.y>((sizeB-rendersize)*map.size)||camera.cam.y<(rendersize*map.size)||(isKeyPressed(KeyEvent.VK_R)&&paused&&!hold5)) {

				hold5=true;
				
				map.map=null;
				
					map =new BlockMap(sizeB,sizeB,125,100,map.seed);
					System.gc();
					map.tperlin(20,15,2,25,5,50,(int)Math.round((camera.cam.x+prevX)/map.size-(sizeB)/2),(int)Math.round((camera.cam.y+prevY)/map.size-(sizeB)/2));
					prevX+=camera.cam.x-(sizeB*map.size)/2;
					prevY+=camera.cam.y-(sizeB*map.size)/2;
					double addy = camera.cam.y-(int)(camera.cam.y);
					double addx = camera.cam.x-(int)(camera.cam.x);
					camera.cam.x=(sizeB*map.size)/2+addx;
					camera.cam.y=(sizeB*map.size)/2+addy;
					paused=false;
					count=2;
					
				
				
					
			}else if(!isKeyPressed(KeyEvent.VK_R)) {
				hold5=false;
			}
				if(count == 0) {
					if(!paused ||paused2) {
						allShading.clear();
						if(flashlight) {
							allShading.addLight(new PointVector(camera.cam,camera.getcamV().mul(2550,2550,-2550)));
						}
					interactions(map,rendersize);
					paused2=false;
					}
					
				count =2;
				}
				if(suncount == 0) {
					
					sunAngle -= Math.toRadians(1);
					if(sunAngle < 0 ){
						sunAngle = Math.toRadians(180);
				}
					doShading(dosun);
			
					suncount =(int) Math.round(	60*10/180.0*60.0);
				}
				suncount--;
				count--;
				if(speed!=8) {
					speed = 8;	
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_SHIFT)) {
					if(PressedKeys.get(KeyEvent.VK_SHIFT)) {
						speed=24;
					}
				}
				
				
				if(PressedKeys.containsKey(KeyEvent.VK_Z)) {
					if(PressedKeys.get(KeyEvent.VK_Z)) {
						speed =(int) (36*60/currentFPS);
					}
				}
				
				if(gravity) {
					try {
						int state =map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z+10*gtime)/map.size))];
						int state2 =map.map[(int)(camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int)(((camera.cam.z+10*gtime)/map.size))+1];
						int state3 =map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z+10*gtime)/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
					
						camera.cam.z+=2*gtime;
						gtime++;
					
					}else {
						if(jumpspeed > 0) {
							jumpspeed=0;
						}
						gtime=0;
					}
					}catch(Exception e) {
						
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_SPACE)) {
					if(PressedKeys.get(KeyEvent.VK_SPACE)) {
						if(gravity) {
							jumpspeed=(int) (0.1*map.size);
						}
						
					}else {
						
					
						
					}
				}
				camera.cam.z-=jumpspeed;
				if(PressedKeys.containsKey(KeyEvent.VK_W)) {
					if(PressedKeys.get(KeyEvent.VK_W)) {
						try {
						int state = map.map[(int) ((camera.cam.x+speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y+speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))];
						int state2 = map.map[(int) ((camera.cam.x+speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y+speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))+1];
						int state3 = map.map[(int) ((camera.cam.x+speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y+speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
							camera.cam.y+=speed*Math.cos(camera.angle1)*(60/currentFPS);
							camera.cam.x+=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
						}catch(Exception e) {
							camera.cam.y+=speed*Math.cos(camera.angle1)*(60/currentFPS);
							camera.cam.x+=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_S)) {
					if(PressedKeys.get(KeyEvent.VK_S)) {
						try {
						int state = map.map[(int) ((camera.cam.x-speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y-speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))];
						int state2 = map.map[(int) ((camera.cam.x-speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y-speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))+1];
						int state3 = map.map[(int) ((camera.cam.x-speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y-speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.z/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
						camera.cam.y-=speed*Math.cos(camera.angle1)*(60/currentFPS);
						camera.cam.x-=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
						}catch(Exception e) {
							camera.cam.y-=speed*Math.cos(camera.angle1)*(60/currentFPS);
							camera.cam.x-=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_A)) {
					if(PressedKeys.get(KeyEvent.VK_A)) {
						try {
						int state = map.map[(int) ((camera.cam.x-speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y+8*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))];
						int state2 = map.map[(int) ((camera.cam.x-speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y+8*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))+1];
						int state3 = map.map[(int) ((camera.cam.x-speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y+8*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
						camera.cam.x-=speed*Math.cos(camera.angle1)*(60/currentFPS);
						camera.cam.y+=8*Math.sin(camera.angle1)*(60/currentFPS);
						}
						}catch(Exception e) {
							camera.cam.x-=speed*Math.cos(camera.angle1)*(60/currentFPS);
							camera.cam.y+=8*Math.sin(camera.angle1)*(60/currentFPS);
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_D)) {
					if(PressedKeys.get(KeyEvent.VK_D)) {
						try {
						int state = map.map[(int) ((camera.cam.x+speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y-speed*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))];
						int state2 = map.map[(int) ((camera.cam.x+speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y-speed*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))+1];
						int state3 = map.map[(int) ((camera.cam.x+speed*Math.cos(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.y-speed*Math.sin(camera.angle1)*(60/currentFPS))/map.size)][(int) ((camera.cam.z/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
						camera.cam.x+=speed*Math.cos(camera.angle1)*(60/currentFPS);
						camera.cam.y-=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
						}catch(Exception e) {
							camera.cam.x+=speed*Math.cos(camera.angle1)*(60/currentFPS);
							camera.cam.y-=speed*Math.sin(camera.angle1)*(60/currentFPS);
						}
					}
				}
			
				if(isKeyPressed(KeyEvent.VK_Q)||isKeyPressed(KeyEvent.VK_CONTROL)) {
						try {
						int state =map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z+speed*(60/currentFPS))/map.size))];
						int state2 =map.map[(int)(camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int)(((camera.cam.z+speed*(60/currentFPS))/map.size))+1];
						int state3 =map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z+speed*(60/currentFPS))/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
					camera.cam.z+=speed*(60/currentFPS);	
						}
						}catch(Exception e) {
							camera.cam.z+=speed*(60/currentFPS);
						}
					
				}
				if(isKeyPressed(KeyEvent.VK_E)||isKeyPressed(KeyEvent.VK_SPACE)) {
					
						try {
						int state = map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z-(speed*(60/currentFPS)))/map.size))];
						int state2 = map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z-(speed*(60/currentFPS)))/map.size))+1];
						int state3 = map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) (((camera.cam.z-(speed*(60/currentFPS)))/map.size))+2];
						if(((state==0||state==5)||state==11||state==12)&&((state2==0||state2==5)||state2==11||state2==12)&&((state3==0||state3==5)||state3==11||state3==12)){
					camera.cam.z-=speed*(60/currentFPS);	
						}
						}catch(Exception e) {
							camera.cam.z-=speed*(60/currentFPS);	
						}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_1)) {
					if(PressedKeys.get(KeyEvent.VK_1)) {
						state = 1;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_2)) {
					if(PressedKeys.get(KeyEvent.VK_2)) {
						state = 2;
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_3)) {
					if(PressedKeys.get(KeyEvent.VK_3)) {
						state = 3;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_4)) {
					if(PressedKeys.get(KeyEvent.VK_4)) {
						state = 4;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_5)) {
					if(PressedKeys.get(KeyEvent.VK_5)) {
						state = 5;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_6)) {
					if(PressedKeys.get(KeyEvent.VK_6)) {
						state = 6;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_COMMA)) {
					if(PressedKeys.get(KeyEvent.VK_COMMA)) {
						state = 0;
					}
				}
				if(isKeyPressed(KeyEvent.VK_PERIOD)) {
						state = 17;
					
				}
				if(isKeyPressed(KeyEvent.VK_SLASH)) {
					state = 18;
				
			}
				
				if(isKeyPressed(KeyEvent.VK_SEMICOLON)) {
					flashlight=true;
					
				}else {
					flashlight=false;
				}
				if(isKeyPressed(KeyEvent.VK_OPEN_BRACKET)) {
					if(!hold6) {
						dosun=!dosun;
						doShading(dosun);
						hold6=true;
					}
					
					
				}else {
				hold6=false;
					
				
				}
				if(PressedKeys.containsKey(KeyEvent.VK_7)) {
					if(PressedKeys.get(KeyEvent.VK_7)) {
						state =7;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_8)) {
					if(PressedKeys.get(KeyEvent.VK_8)) {
						state =8;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_9)) {
					if(PressedKeys.get(KeyEvent.VK_9)) {
						state =9;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_0)) {
					if(PressedKeys.get(KeyEvent.VK_0)) {
						state =10;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_L)) {
					if(PressedKeys.get(KeyEvent.VK_L)) {
						state =11;
					}
				}if(PressedKeys.containsKey(KeyEvent.VK_J)) {
					if(PressedKeys.get(KeyEvent.VK_J)) {
						state =12;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_H)) {
					if(PressedKeys.get(KeyEvent.VK_H)) {
						state =13;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_B)) {
					if(PressedKeys.get(KeyEvent.VK_B)) {
						state =14;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_F2)) {
					if(PressedKeys.get(KeyEvent.VK_F2)) {
						state =15;
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_C)) {
					if(PressedKeys.get(KeyEvent.VK_C)) {
						if(!hold4) {
							gridshow = !gridshow;
							
						hold4 = true;
						}
						
					}else {
						hold4 =false;
					
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_I)) {
					if(PressedKeys.get(KeyEvent.VK_I)) {
				
				
				for(int i = 0;i<= Math.round(rendersize*Math.sqrt(2));i++) {
					try {
						for(int i2 = -2;i2<= 2;i2++) {
							for(int i3 = -2;i3<= 2;i3++) {
								for(int i4 = -2;i4<=2;i4++) {
					int x1 = (int)((camera.cam.x+i2*map.size+map.size*i*Math.sin(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int y1 =  (int)((camera.cam.y+i3*map.size+map.size*i*Math.cos(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int z1 =  (int)((camera.cam.z+i4*map.size+map.size*i*Math.sin(camera.angle2))/map.size);
					if(((x1-camera.cam.x/map.size)<rendersize/2)&&((x1-camera.cam.x/map.size)>-rendersize/2)&&((y1-camera.cam.y/map.size)>-rendersize/2)&&((y1-camera.cam.y/map.size)<rendersize/2)){
						map.map[x1][y1][z1]=0;	
					}
					
					
							}
							}
						}
					}catch(Exception e) {
						
					}
				}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_I)) {
					if(PressedKeys.get(KeyEvent.VK_I)) {
				
				
				for(int i = state==0?0:10;i<= Math.round(rendersize*4);i++) {
					try {
						for(int i2 = -2;i2<= 2;i2++) {
							for(int i3 = -2;i3<= 2;i3++) {
								for(int i4 = -2;i4<=2;i4++) {
									try {
					int x1 = (int)((camera.cam.x+i2*map.size+map.size*i*Math.sin(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int y1 =  (int)((camera.cam.y+i3*map.size+map.size*i*Math.cos(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int z1 =  (int)((camera.cam.z+i4*map.size+map.size*i*Math.sin(camera.angle2))/map.size);
					if(((x1-camera.cam.x/map.size)<rendersize/2)&&((x1-camera.cam.x/map.size)>-rendersize/2)&&((y1-camera.cam.y/map.size)>-rendersize/2)&&((y1-camera.cam.y/map.size)<rendersize/2)){
						map.map[x1][y1][z1]=state;	
					}
					
									}catch(Exception e) {
										
									}
							}
									
							}
						}
					}catch(Exception e) {
						
					}
				}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_V)) {
					if(PressedKeys.get(KeyEvent.VK_V)&&!paused) {
		
				
				
				for(int i = 0;i<= sizeB;i++) {
					try {
						for(int i2 = -8;i2<= 8;i2++) {
							for(int i3 = -8;i3<= 8;i3++) {
								for(int i4 = -8;i4<=8;i4++) {
								
					int x1 = (int)((camera.cam.x+i2*map.size+map.size*i*Math.sin(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int y1 =  (int)((camera.cam.y+i3*map.size+map.size*i*Math.cos(camera.angle1)*Math.cos(camera.angle2))/map.size);
					int z1 =  (int)((camera.cam.z+i4*map.size+map.size*i*Math.sin(camera.angle2))/map.size);
					map.map[x1][y1][z1]=0;	
					
				
									
							}
									
							}
						}
					}catch(Exception e) {
						
					}
				}
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_X)) {
					if(PressedKeys.get(KeyEvent.VK_X)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
							for(int z=1;z<=map.map[x][y].length-1;z++) {
										try {
										if(map.map[x][y][z]==state) {
											map.map[x][y][z]=0;
										}
										}catch(Exception e) {
											
										}
									}
								
							}
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_X)) {
					if(PressedKeys.get(KeyEvent.VK_X)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
							for(int z=1;z<=map.map[x][y].length-1;z++) {
										try {
										if(map.map[x][y][z]==state) {
											map.map[x][y][z]=0;
										}
										}catch(Exception e) {
											
										}
									}
								
							}
						}
					}
					
				}
				if(PressedKeys.containsKey(KeyEvent.VK_K)) {
					if(PressedKeys.get(KeyEvent.VK_K)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								
									for(int z=1;z<=map.map[x][y].length-1;z++) {
										try {
											map.map[x][y][z]=0;
										}catch(Exception e) {
											
										}
									}
								
							}
						}
					}
				}if(PressedKeys.containsKey(KeyEvent.VK_M)) {
					if(PressedKeys.get(KeyEvent.VK_M)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int camZ=(int)Math.round(cam.z/map.size)+2;
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								try {
									for(int z=1;z<camZ;z++) {
										if(map.map[x][y][z]==state) {
											map.map[x][y][z]=0;
										}
										
									}
								}catch(Exception e) {
									
								}
							}
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_N)) {
					if(PressedKeys.get(KeyEvent.VK_N)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int camZ=(int)Math.round(cam.z/map.size)+2;
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								try {
									for(int z=1;z<camZ;z++) {
										
											map.map[x][y][z]=0;
										
									}
								}catch(Exception e) {
									
								}
							}
						}
					}
				}
				if(isKeyPressed(KeyEvent.VK_R)&&!paused&&!hold5){
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								try {
									for(int z=1;z<100;z++) {
										if(map.map[x][y][z]==0&&((int)(Math.random()*500)==1)) {
											map.map[x][y][z]=5;
										}
									}
								}catch(Exception e) {
									
								}
							}
						
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_F)) {
					if(PressedKeys.get(KeyEvent.VK_F)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								try {
									for(int z=1;z<100;z++) {
										if(map.map[x][y][z]==0&&((int)(Math.random()*100)==1)) {
											map.map[x][y][z]=5;
										}
									}
								}catch(Exception e) {
									
								}
							}
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_P)) {
					if(PressedKeys.get(KeyEvent.VK_P)) {
						if(!hold) {
						paused = !paused;
						hold = true;
						}
						
					}else {
						hold =false;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_V)) {
					if(PressedKeys.get(KeyEvent.VK_V)) {
						if(!hold3) {
							paused2 = true;
							
						hold3 = true;
						}
						
					}else {
						hold3 =false;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_O)) {
					if(PressedKeys.get(KeyEvent.VK_O)) {
						if(!hold2) {
						gravity = !gravity;
						hold2=true;
						}
						
					}else {
						hold2=false;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_G)) {
					if(PressedKeys.get(KeyEvent.VK_G)) {
						Point3D cam = camera.cam;
						int camX=(int)Math.round(cam.x/map.size);
						int camY=(int)Math.round(cam.y/map.size);
						int camZ=(int)Math.round(cam.z/map.size)+2;
						int halfchunk =(int)Math.round(rendersize/2);
						for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
							for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
								
									for(int z=camZ;z<=map.map[x][y].length-1;z++) {
										try {
										if(map.map[x][y][z]==0) {
											map.map[x][y][z]=5;
										}
										}catch(Exception e) {
											
										}
									}
								
							}
						}
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_Y)) {
					if(PressedKeys.get(KeyEvent.VK_Y)) {
				sunAngle += Math.toRadians(1);
				if(sunAngle >Math.toRadians(180) ){
					sunAngle = Math.toRadians(180);
				}
				doShading(dosun);
				
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_T)) {
					if(PressedKeys.get(KeyEvent.VK_T)) {
				sunAngle -= Math.toRadians(1);
				if(sunAngle < 0 ){
					sunAngle = 0;
				}
				doShading(dosun);
					}
				}
				camera.angle1 = Math.toRadians(((mouseX-screenWidth/2.0)/screenWidth)*360);
				camera.angle2 = Math.toRadians(((mouseY-screenHeight/2.0)/screenHeight)*180);
				camera.updateV();
			
				Graphics3D g3= new Graphics3D();
				polys=g3.shade(map,camera,rendersize,allShading );
				int x = 0;
				int y = 0;
				int z =  0;
				for(int i = 0;i<= 5;i++) {
					try {
					x = (int)((camera.cam.x+map.size*i*Math.sin(camera.angle1)*Math.cos(camera.angle2))/map.size);
					y =  (int)((camera.cam.y+map.size*i*Math.cos(camera.angle1)*Math.cos(camera.angle2))/map.size);
					z =  (int)((camera.cam.z+map.size*i*Math.sin(camera.angle2))/map.size);
					if(map.map[x][y][z]!=0&&map.map[x][y][z]!=5) {
						i=map.size*6;
					}
					}catch(Exception e) {
						
					}
				}
				
				selec = g3.shadeR(map, camera,x,y,z);
					if(mousePressed) {
						try {
							
						if(click) {
							if((map.map[x][y][z]==0)||map.map[x][y][z]==5) {
							map.map[x][y][z]=state;
							}else if(map.map[x][y][z]!=0) {
							map.map[x][y][z]=0;
							}
							
							
							click = false;
						}else if(state ==5 ) {
							if((map.map[x][y][z]==0)) {
								map.map[x][y][z]=state;
								}
						}else if(state ==11 ) {
							if((map.map[x][y][z]==0)) {
								map.map[x][y][z]=state;
								}
						}
						else if(state ==12 ) {
							if((map.map[x][y][z]==0)) {
								map.map[x][y][z]=state;
								}
						}
						else if(state ==10 ) {
							if((map.map[x][y][z]!=state)) {
								map.map[x][y][z]=state;
							}
								
						}else if(state ==7 ) {
							if((map.map[x][y][z]!=state)) {
								map.map[x][y][z]=state;
							}
								
						}
						}catch(Exception e) {
							
						}
					}else {
						
						
						click  = true;
					}
				try {
					
					
					sun = g3.shadeRect3D(camera, new Rect3D(camera.cam.x-1000*Math.cos(sunAngle),camera.cam.y,camera.cam.z+1000*Math.sin(-sunAngle),100), false);
				}catch(OutOfMemoryError e) {
					System.out.println("memory");
				}catch(Exception e) {
					
				}
			
			}
			
		
			private void doShading(boolean dosun) {
				
				Shader shading = new Shader(Color.GREEN,b,rez);
				shading.sideImages[2]=bt;
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(1, shading);
				shading = new Shader(new Color(124,98,0),bl,rez);
				if(dosun) {
				shading.shade(sunAngle);
				}else {
					shading.shadeA(0.60);
				}
				allShading.put(2, shading);
				shading = new Shader(new Color(25,200,0),ble,rez,true);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(3, shading);
				shading = new Shader(new Color(0,200,255));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(4, shading);
				shading = new Shader(new Color(0,0,255,100),true);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(5, shading);
				shading = new Shader(new Color(255,255,255,50),true);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(6, shading);
				shading = new Shader(new Color(250, 240, 50));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(7, shading);
				shading = new Shader(new Color(255, 255, 255));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(8, shading);
				shading = new Shader(new Color(183, 184, 186));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(9, shading);
				shading = new Shader(new Color(255, 0, 0));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(10, shading);
				shading = new Shader(new Color(200, 0, 0),true);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(11, shading);
				shading = new Shader(new Color(0, 200, 0,100),true);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(12, shading);
				shading = new Shader(new Color(255, 100, 100),bp,rez);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(13, shading);
				shading = new Shader(new Color(255, 50, 50));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(14, shading);
				shading = new Shader(new Color(0, 0, 0),bb,rez2);
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(15, shading);
				shading = new Shader(new Color(255, 125, 0));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(16, shading);
				shading = new Shader(new Color(200, 0, 255));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(17, shading);
				shading = new Shader(new Color(255, 255, 255));
				if(dosun) {
					shading.shade(sunAngle);
					}else {
						shading.shadeA(0.60);
					}
				allShading.put(18, shading);
				
			}
			//left
			//back
			//down
			//up
			//forward
			//right
			
			ArrayList<PolygonWr> polys = new ArrayList<PolygonWr>();
		
			ArrayList<Polygon> selec = new ArrayList<Polygon>();
			ArrayList<Polygon> sun = new ArrayList<Polygon>();
			double FOV =75;
		//75
			
			
			public void paint(Graphics g) {
				
				
	
				Graphics2D g2 = (Graphics2D)g;
				Graphics3D g3= new Graphics3D(g2);
				g3.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
				g3.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
				g3.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,RenderingHints.VALUE_COLOR_RENDER_SPEED);
			
				g3.setColor(new Color(0,(int)Math.abs(Color.WHITE.getGreen()*Math.sin(sunAngle)),(int)Math.abs(Color.WHITE.getBlue()*Math.sin(sunAngle))));
				g3.fillRect(0, 0, screenWidth, screenHeight);
				g3.setColor(Color.YELLOW);
				for(Polygon p:sun) {
					g3.fill(p);	
				}
				g3.setColor(Color.WHITE);
				if(!gridshow) {
				for(PolygonWr p:polys) {
								g3.setColor(p.c);
								g3.fill(p.p);	
					}
				}else {
					for(PolygonWr p:polys) {
					g3.setColor(p.c);
					g3.draw(p.p);
					}
				}
				
		
				
						
				
				
				
				for(Polygon p:selec) {
					g3.setColor(new Color(255,0,0,200));
					g3.draw(p);	
				
				
					
				}
				try {
				int pbs = map.map[(int) ((camera.cam.x)/map.size)][(int) ((camera.cam.y)/map.size)][(int) (camera.cam.z/map.size)];
				switch(pbs) {
				case 11:
					g3.setColor(new Color(200,0,0,200));
					g3.fillRect(0, 0, screenWidth, screenHeight);break;
				case 5:
					g3.setColor(new Color(0,0,255,100));
					g3.fillRect(0, 0, screenWidth, screenHeight);break;
				case 12:
						g3.setColor(new Color(0,200,0,100));
						g3.fillRect(0, 0, screenWidth, screenHeight);break;
					
				}
				}catch(Exception e){
					
				}
				g3.drawString( currentFPS+"", 20, 20);
			
				g3.drawString( Math.round(camera.cam.x/map.size)+" , "+Math.round(camera.cam.y/map.size), 20, 40);
				g3.drawString( (Math.round((camera.cam.x+prevX)/map.size)-250)+" , "+(Math.round((camera.cam.y+prevY)/map.size)-250)+" , "+(500-Math.round((camera.cam.z)/map.size)), 250, 40);
				g3.dispose();
		
		
			
			}
		
		
			int sizeB = 500;
			Camera camera;
		
			TCSIndex allShading = new TCSIndex();
			double sunAngle = Math.toRadians(90);
			public BufferedImage b;
			public BufferedImage bt;
			public BufferedImage bb;
			public BufferedImage bl;
			public BufferedImage ble;
			public BufferedImage bp;
		
			@Override
			public void initialize() {
				
				try {
										b=ImageIO.read(new File("src/Images/testImage.jpg"));
									b=Graphics3D.fit(b,rez);
										bt = ImageIO.read(new File("src/Images/grass_top.png")); 
										bt=Graphics3D.fit(bt,rez);
										bb=ImageIO.read(new File("src/Images/bobross.jpg")); 
										bb=Graphics3D.fit(bb,rez2);
										bl=ImageIO.read(new File("src/Images/log.jpg")); 
										bl=Graphics3D.fit(bl,rez);
										bp=ImageIO.read(new File("src/Images/big-pig-face.png"));   
										bp=Graphics3D.fit(bp,rez);
										ble=ImageIO.read(new File("src/Images/leaves2.jpg"));   
										ble=Graphics3D.fit(ble,rez);
										ble = Graphics3D.removeColor(ble,Color.BLACK);
										ble = Graphics3D.removeLight(ble,30);
										
				} catch (IOException e) {
				
					e.printStackTrace();
				}
				allShading = new TCSIndex();
					
				 map = new BlockMap(sizeB,sizeB,125,100);
				 map.tperlin(20,15,2,25,5,50);
			
			
				camera = new Camera(FOV, screenWidth, screenHeight, new Point3D((sizeB*map.size)/2,(sizeB*map.size)/2,((map.getHeight(sizeB/2,sizeB/2)-2)*map.size)), 0, 0);
	
				
			
				sunAngle = Math.toRadians(90);

				doShading(dosun);
					
				
				
			
				
				
				
			}
			


			private void interactions(BlockMap map,int chunksize) {
				
				Point3D cam = camera.cam;
				int camX=(int)Math.round(cam.x/map.size);
				int camY=(int)Math.round(cam.y/map.size);
				
				int halfchunk =(int)Math.round(chunksize/2);
				
				for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
					for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
						
						for(int z=map.map[x][y].length-3;z>0;z--) {
						boolean encased=false;
						if(map.map[x][y][z]!=0)	{
							encased=map.encased(x, y, z, allShading);
						
						if(map.map[x][y][z]==18&&!encased) {
							allShading.addLight(new PointVector(new Point3D(x*map.size,y*map.size,z*map.size),2550));
						}	else if(map.map[x][y][z]==7&&!encased) {
						
							boolean[] touching = map.touching(x,y,z);
							if(!touching[3]) {
								if(map.map[x][y][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x][y][z+1]=7;
								}
							}else if(map.map[x][y][z+1]==5) {
								map.map[x][y][z]=5;
								map.map[x][y][z+1]=7;
							}else {
								switch((int)(Math.random()*4)) {
								case 0:if(map.map[x][y+1][z]==0&&map.map[x][y+1][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x][y+1][z+1]=7;
								};break;
								case 1:if(map.map[x][y-1][z]==0&&map.map[x][y-1][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x][y-1][z+1]=7;
								};break;
								case 2:if(map.map[x+1][y][z]==0&&map.map[x+1][y][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x+1][y][z+1]=7;
								};break;
								case 3:if(map.map[x-1][y][z]==0&&map.map[x-1][y][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x-1][y][z+1]=7;
								};
									
								
								}
							}
							
							
							}else if(map.map[x][y][z]==5&&!encased) {
						
								if(map.map[x][y][z+1]==0) {
										map.map[x][y][z]=0;
										map.map[x][y][z+1]=5;
									
								}else if(map.map[x][y+1][z]==0||map.map[x+1][y][z]==0||map.map[x-1][y][z]==0||map.map[x][y-1][z]==0) {
									switch((int)(Math.random()*4)) {
									
									case 0 :if(map.map[x][y+1][z]==0) {
									map.map[x][y][z]=0;
									map.map[x][y+1][z]=5;
									};break;
									case 1 :if(map.map[x+1][y][z]==0) {
								
									map.map[x][y][z]=0;
									map.map[x+1][y][z]=5;
								};break;
									case 2 :if(map.map[x-1][y][z]==0) {
									
									map.map[x][y][z]=0;
									map.map[x-1][y][z]=5;
								};break;
									case 3 :if(map.map[x][y-1][z]==0) {
									
									map.map[x][y][z]=0;
									map.map[x][y-1][z]=5;
								};
									}
								}else if(map.map[x][y][z+1]==8) {
									map.map[x][y][z]=0;
									map.map[x][y][z+1]=5;
								
							}else if(map.map[x][y+1][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x][y+1][z]=5;
								
							}else if(map.map[x+1][y][z]==8&&(int)(Math.random()*10)==1) {
							
								map.map[x][y][z]=0;
								map.map[x+1][y][z]=5;
								
							}else if(map.map[x-1][y][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x-1][y][z]=5;
								
							}else if(map.map[x][y-1][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x][y-1][z]=5;
								
							}
								
								
								
								
							}else if(map.map[x][y][z]==10) {
							
								if(map.map[x+1][y][z] != 0) {//right
									map.map[x+1][y][z]=0;
								}
								
								if(map.map[x][y+1][z] != 0) {//forward
									map.map[x][y+1][z]=0;	
								}
								if(map.map[x][y][z+1] != 0) {//up
									map.map[x][y][z+1] =0;	
								}
								if(map.map[x-1][y][z] != 0) {//left
									map.map[x-1][y][z]=0;					
								}
								if(map.map[x][y-1][z] != 0) {//back
									map.map[x][y-1][z]	=0;					
								}
								if(map.map[x][y][z-1] != 0) {//down
									map.map[x][y][z-1]=0;							
								}
							}else if(map.map[x][y][z]==11) {
									if(lacount==0||map.map[x][y][z+1]==0) {
									if(map.map[x][y][z+1]==0) {
											map.map[x][y][z]=0;
											map.map[x][y][z+1]=11;
										
									}else if(map.map[x][y+1][z]==0||map.map[x+1][y][z]==0||map.map[x-1][y][z]==0||map.map[x][y-1][z]==0) {
										switch((int)(Math.random()*4)) {
										
										case 0 :if(map.map[x][y+1][z]==0) {
										map.map[x][y][z]=0;
										map.map[x][y+1][z]=11;
										};break;
										case 1 :if(map.map[x+1][y][z]==0) {
									
										map.map[x][y][z]=0;
										map.map[x+1][y][z]=11;
									};break;
										case 2 :if(map.map[x-1][y][z]==0) {
										
										map.map[x][y][z]=0;
										map.map[x-1][y][z]=11;
									};break;
										case 3 :if(map.map[x][y-1][z]==0) {
										
										map.map[x][y][z]=0;
										map.map[x][y-1][z]=11;
									};
										}
									}else if(map.map[x][y][z+1]==8) {
										map.map[x][y][z]=0;
										map.map[x][y][z+1]=11;
									
								}
									lacount=2;
									}
									lacount--;
								if(map.map[x+1][y][z] == 5) {//right
									map.map[x+1][y][z]=9;
								}
								
								if(map.map[x][y+1][z] == 5) {//forward
									map.map[x][y+1][z]=9;	
								}
								if(map.map[x][y][z+1] == 5) {//up
									map.map[x][y][z+1] =9;	
								}
								if(map.map[x-1][y][z] == 5) {//left
									map.map[x-1][y][z]=9;					
								}
								if(map.map[x][y-1][z] == 5) {//back
									map.map[x][y-1][z]	=9;					
								}
								if(map.map[x][y][z-1] == 5) {//down
									map.map[x][y][z-1]=9;							
								}
								if(map.map[x+1][y][z] == 5) {//right
									map.map[x+1][y][z]=9;
								}
								
								if(map.map[x][y+1][z] == 3||map.map[x][y+1][z] == 17) {//forward
									map.map[x][y+1][z]=16;	
									
								}
								if(map.map[x][y][z+1] == 3||map.map[x][y][z+1] == 17) {//up
									map.map[x][y][z+1] =16;	
								
								}
								if(map.map[x-1][y][z] == 3||map.map[x-1][y][z] == 17) {//left
									map.map[x-1][y][z]=16;	
								
								}
								if(map.map[x+1][y][z] == 3||map.map[x+1][y][z] == 17) {//right
									map.map[x+1][y][z]=16;	
								
								}
								if(map.map[x][y-1][z] == 3||map.map[x][y-1][z] == 17) {//back
									map.map[x][y-1][z]	=16;
								
								}
								if(map.map[x][y][z-1] == 3||map.map[x][y][z-1] == 17) {//down
									map.map[x][y][z-1]=16;	
									
								}
									
							
							}else if(map.map[x][y][z]==12&&!encased) {
							
								if(map.map[x][y][z+1]==0) {
										map.map[x][y][z]=0;
										map.map[x][y][z+1]=12;
									
								}else if(map.map[x][y+1][z]==0||map.map[x+1][y][z]==0||map.map[x-1][y][z]==0||map.map[x][y-1][z]==0) {
									switch((int)(Math.random()*4)) {
									
									case 0 :if(map.map[x][y+1][z]==0) {
									map.map[x][y][z]=0;
									map.map[x][y+1][z]=12;
									};break;
									case 1 :if(map.map[x+1][y][z]==0) {
								
									map.map[x][y][z]=0;
									map.map[x+1][y][z]=12;
								};break;
									case 2 :if(map.map[x-1][y][z]==0) {
									
									map.map[x][y][z]=0;
									map.map[x-1][y][z]=12;
								};break;
									case 3 :if(map.map[x][y-1][z]==0) {
									
									map.map[x][y][z]=0;
									map.map[x][y-1][z]=12;
								};
									}
								
							}else {
								boolean state1=map.map[x][y][z+1]!=12&&map.map[x][y][z+1]!=0&&map.map[x][y][z+1]!=6&&map.map[x][y][z+1]!=14;
								boolean state2=map.map[x][y+1][z]!=12&&map.map[x][y+1][z]!=0&&map.map[x][y+1][z]!=6;
								boolean state3=map.map[x+1][y][z]!=12&&map.map[x+1][y][z]!=0&&map.map[x+1][y][z]!=6;
								boolean state4=map.map[x-1][y][z]!=12&&map.map[x-1][y][z]!=0&&map.map[x-1][y][z]!=6;
								boolean state5=map.map[x][y-1][z]!=12&&map.map[x][y-1][z]!=0&&map.map[x][y-1][z]!=6;
								if(state1||state2||state3||state4||state5) {
							
								switch((int)(Math.random()*5)){
								case 0:if(state1) {
									map.map[x][y][z]=0;
									if((int)(Math.random()*5)==1){
										map.map[x][y][z+1]=0;
									}
									map.map[x][y][z+1]=12;
								
							};break;
								case 1 :if(state2) {
								
								map.map[x][y][z]=0;
								if((int)(Math.random()*5)==1){
									map.map[x][y+1][z]=0;	
								}
								map.map[x][y+1][z]=12;
								
							};break;
								case 2: if(state3) {
							
								map.map[x][y][z]=0;
								if((int)(Math.random()*5)==1){
								map.map[x+1][y][z]=0;	
								}
								map.map[x+1][y][z]=12;
								
							};break;
								case 3 :if(state4) {
								
								map.map[x][y][z]=0;
								if((int)(Math.random()*5)==1){
								map.map[x-1][y][z]=0;
								}else {
								map.map[x-1][y][z]=12;
								}
								
							};break;
								case 4:if(state5) {
								
								map.map[x][y][z]=0;
								if((int)(Math.random()*5)==1){
									map.map[x][y-1][z]=0;
								}else {
								map.map[x][y-1][z]=12;
								}
								};
								
							
								}
							}
							}
							}else if(map.map[x][y][z]==13) {
								if(map.map[x][y][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x][y][z+1]=13;
								
							}else if(pigcount ==0) {
								
							if(map.map[x][y][z-1]==0&&map.map[x+1][y][z]!=0&&map.map[x+1][y][z-1]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x+1][y][z-1]=13;
								}else if(map.map[x][y][z-1]==0&&map.map[x-1][y][z]!=0&&map.map[x-1][y][z-1]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x-1][y][z-1]=13;
								}
								else if(map.map[x][y][z-1]==0&&map.map[x][y+1][z]!=0&&map.map[x][y+1][z-1]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x][y+1][z-1]=13;
								}
								else if(map.map[x][y][z-1]==0&&map.map[x][y-1][z]!=0&&map.map[x][y-1][z-1]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x][y][z-1]=13;
								}
								else if(map.map[x+1][y][z]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x+1][y][z]=13;
								}
								else if(map.map[x-1][y][z]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x-1][y][z]=13;
								}
								else if(map.map[x][y+1][z]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x][y+1][z]=13;
								}
								else if(map.map[x][y-1][z]==0&&(int)(Math.random()*10)==1) {
									map.map[x][y][z]=0;
									map.map[x][y-1][z]=13;
								}
							pigcount=10;
							}
								if(pigcount > 0) {
									pigcount--;
								}
							}else if(map.map[x][y][z]==14) {
								if(map.map[x][y][z-1]!=0) {
									if(map.map[x][y+1][z]==0) {
										map.map[x][y+1][z]=map.map[x][y][z-1];
									}
									if(map.map[x][y-1][z]==0) {
										map.map[x][y-1][z]=map.map[x][y][z-1];
									}
									if(map.map[x+1][y][z]==0) {
										map.map[x+1][y][z]=map.map[x][y][z-1];
									}
									if(map.map[x-1][y][z]==0) {
										map.map[x-1][y][z]=map.map[x][y][z-1];
									}
								}
							}else if(map.map[x][y][z]==15) {
								switch((int)(Math.random()*12)) {
								case 0:if(map.map[x+1][y][z]==0&&(int)(Math.random()*75)==1) {map.map[x+1][y][z]=15;};break;
								case 1:if(map.map[x-1][y][z]==0&&(int)(Math.random()*75)==1) {map.map[x-1][y][z]=15;};break;
								case 2:if(map.map[x][y+1][z]==0&&(int)(Math.random()*75)==1) {map.map[x][y+1][z]=15;};break;
								case 3:if(map.map[x][y-1][z]==0&&(int)(Math.random()*75)==1) {map.map[x][y-1][z]=15;};break;
								case 4:if(map.map[x][y][z+1]==0&&(int)(Math.random()*75)==1) {map.map[x][y][z+1]=15;};break;
								case 5:if(map.map[x][y][z-1]==0&&(int)(Math.random()*75)==1) {map.map[x][y][z-1]=15;};break;
								case 6:if(map.map[x+1][y][z]!=0&&(int)(Math.random()*10)==1) {map.map[x+1][y][z]=15;};break;
								case 7:if(map.map[x-1][y][z]!=0&&(int)(Math.random()*10)==1) {map.map[x-1][y][z]=15;};break;
								case 8:if(map.map[x][y+1][z]!=0&&(int)(Math.random()*10)==1) {map.map[x][y+1][z]=15;};break;
								case 9:if(map.map[x][y-1][z]!=0&&(int)(Math.random()*10)==1) {map.map[x][y-1][z]=15;};break;
								case 10:if(map.map[x][y][z+1]!=0&&(int)(Math.random()*10)==1) {map.map[x][y][z+1]=15;};break;
								case 11:if(map.map[x][y][z-1]!=0&&(int)(Math.random()*10)==1) {map.map[x][y][z-1]=15;};
								}
							}else if(map.map[x][y][z]==16) {
								boolean die=true;
								if(map.map[x][y+1][z] == 3||map.map[x][y+1][z] == 17) {//forward
									map.map[x][y+1][z]=16;	
									die=false;
								}
								if(map.map[x][y][z+1] == 3||map.map[x][y][z+1] == 17) {//up
									map.map[x][y][z+1] =16;	
									die=false;
								}
								if(map.map[x-1][y][z] == 3||map.map[x-1][y][z] == 17) {//left
									map.map[x-1][y][z]=16;	
									die=false;
								}
								if(map.map[x+1][y][z] == 3||map.map[x+1][y][z] == 17) {//right
									map.map[x+1][y][z]=16;	
									die=false;
								}
								if(map.map[x][y-1][z] == 3||map.map[x][y-1][z] == 17) {//back
									map.map[x][y-1][z]	=16;
									die=false;
								}
								if(map.map[x][y][z-1] == 3||map.map[x][y][z-1] == 17) {//down
									map.map[x][y][z-1]=16;	
									die=false;
								}
								if(die&&(int)(10*Math.random())==1) {
									map.map[x][y][z]=0;
								}
								
							}else if(map.map[x][y][z]==17) {
								boolean die=true;
								if((int)(10*Math.random())==1&&map.map[x][y+1][z] != 0&&map.map[x][y+1][z] != 17&&map.map[x][y+1][z] != 16) {//forward
									map.map[x][y+1][z]=17;	
									die=false;
								}
								if((int)(10*Math.random())==1&&map.map[x][y][z+1]  != 0&&map.map[x][y][z+1]  != 17&&map.map[x][y][z+1]  != 16) {//up
									map.map[x][y][z+1] =17;	
									die=false;
								}
								if((int)(10*Math.random())==1&&map.map[x-1][y][z]  != 0&&map.map[x-1][y][z]  != 17&&map.map[x-1][y][z]  != 16) {//left
									map.map[x-1][y][z]=17;	
									die=false;
								}
								if((int)(10*Math.random())==1&&map.map[x+1][y][z]  != 0&&map.map[x+1][y][z]  != 17&&map.map[x+1][y][z]  != 16) {//right
									map.map[x+1][y][z]=17;	
									die=false;
								}
								if((int)(10*Math.random())==1&&map.map[x][y-1][z]  != 0&&map.map[x][y-1][z]  != 17&&map.map[x][y-1][z]  != 16) {//back
									map.map[x][y-1][z]	=17;
									die=false;
								}
								if((int)(10*Math.random())==1&&map.map[x][y][z-1]  != 0&&map.map[x][y][z-1]  != 17&&map.map[x][y][z-1]  != 16) {//down
									map.map[x][y][z-1]=17;	
									die=false;
								}
								if(die&&(int)(20*Math.random())==1) {
									map.map[x][y][z]=0;
								}
							}
						}
						}
					
					}
						
					
				}
					
				
			}
			
		};
		}


			
}
			