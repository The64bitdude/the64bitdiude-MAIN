package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Screens.RefreshScreen;

import dataServer2.ClientHandler;



public class ConnectionTester {

	public static void main(String[] args) {
		
	
int myPort2 = Integer.parseInt(JOptionPane.showInputDialog("What port are you using"));
		try {
			new ClientHandler(myPort2,500,500,Color.BLACK,60,3) {

				
				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			
				public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
		
					try {
						frame.setTitle(InetAddress.getLocalHost().getHostAddress()+ " "+myPort2);
					} catch (UnknownHostException e) {
						
						e.printStackTrace();
					}
				
				}
			String nextS="";
			int i=0;

			int switchframes=10;
				ArrayList<String> messages;
				ArrayList<BufferedImage> Images;
				int typeindex=0;
				boolean typing = false;
				boolean typing2 = false;
				boolean typing3=false;
				boolean typing4=false;
				boolean typing5=false;
				boolean typing6=false;
				public void update() {
					
					try {
						i++;
						if(isKeyPressed(KeyEvent.VK_CONTROL)&&isKeyPressed(KeyEvent.VK_V)&&!typing3) {
							typing3=true;
						  Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
						    DataFlavor flavor = DataFlavor.stringFlavor;
						    if (clipboard.isDataFlavorAvailable(flavor)) {
						      try {
						        String text = (String) clipboard.getData(flavor);
						        this.typedString+=text;
						    	this.typedstart=typedString.length();
						      } catch (UnsupportedFlavorException e) {
						        System.out.println(e);
						      } catch (IOException e) {
						        System.out.println(e);
						      }
						    }
						    
						}else if(!isKeyPressed(KeyEvent.VK_CONTROL)||!isKeyPressed(KeyEvent.VK_V)) {
							typing3=false;
						}
						if(isKeyPressed(KeyEvent.VK_CONTROL)&&isKeyPressed(KeyEvent.VK_C)&&!typing4) {
							typing4=true;
						  Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
						StringSelection s=new StringSelection(this.typedString);
						   clipboard.setContents(s, s);
						    
						}else if(!isKeyPressed(KeyEvent.VK_CONTROL)||!isKeyPressed(KeyEvent.VK_C)) {
							typing4=false;
						}
						if(isKeyPressed(KeyEvent.VK_LEFT)&&typing5) {
							typing5=false;
							movetype(-1);
						}else if(!isKeyPressed(KeyEvent.VK_LEFT)){
							typing5 = true;
						}
						if(isKeyPressed(KeyEvent.VK_RIGHT)&&typing6) {
							typing6=false;
							movetype(1);
						}else if(!isKeyPressed(KeyEvent.VK_RIGHT)){
							typing6 = true;
						}
						if(isKeyPressed(KeyEvent.VK_UP)&&typing) {
							typing = false;
							boolean found=true;
							int i =typeindex;
							if(!typedString.equals(messages.get(i).substring(0,messages.get(i).length()-1))){
								i=0;
							}
						while(found&&i<messages.size()) {
							if(!typedString.equals(messages.get(i).substring(0,messages.get(i).length()-1))) {
								typedString=messages.get(i).substring(0,messages.get(i).length()-1);
								found=false;
								typeindex=i;
								this.typedstart=typedString.length();
							}
							i++;
						}
						}else if(!isKeyPressed(KeyEvent.VK_UP)){
							typing = true;
						}
						if(isKeyPressed(KeyEvent.VK_DOWN)&&typing2) {
							typing2 = false;
							boolean found=true;
							int i =typeindex;
							if(!typedString.equals(messages.get(i).substring(0,messages.get(i).length()-1))){
								i=0;
							}
						while(found&&i>=0) {
							if(!typedString.equals(messages.get(i).substring(0,messages.get(i).length()-1))) {
								typedString=messages.get(i).substring(0,messages.get(i).length()-1);
								found=false;
								typeindex=i;
								this.typedstart=typedString.length();
							}
							i--;
						}
						}else if(!isKeyPressed(KeyEvent.VK_DOWN)){
							typing2 = true;
						}
						
						if(this.typedString.indexOf((char)127)!=-1) {
					
							if(this.typedString.length()>"/".length()&&this.typedString.substring(0,1).equals("/"))	{
								String msg=this.typedString.substring(1,this.typedString.length()-1);
								String[] commands = msg.split(" ");
								switch(commands[0]) {
								case "setName":
									try{
										setName(commands[1],Integer.parseInt(commands[2]),compress(commands,3));
										}	catch(Exception e) {
									try {
										setName(commands[1],compress(commands,3));
									} catch (Exception e1) {
									
										e1.printStackTrace();
									}	
								}break;
								case "removeName":
									try{
										removeName(commands[1],Integer.parseInt(commands[2]),compress(commands,3));
										}	catch(Exception e) {
									try {
										removeName(commands[1],compress(commands,3));
									} catch (Exception e1) {
										
										e1.printStackTrace();
									}	
								}break;
								
								case "send":try{
									write(commands[1],Integer.parseInt(commands[2]),compress(commands,3));
									}	catch(Exception e) {
										try {
											write(commands[1],compress(commands,2));
										} catch (Exception e1) {
										
											e1.printStackTrace();
										}
									}break;
								case "sendImage":try{
									writeImage(commands[1],Integer.parseInt(commands[2]),new File(commands[3]));
									}	catch(Exception e) {
										try {
											writeImage(commands[1],new File(commands[2]));
										} catch (Exception e1) {
											
											e1.printStackTrace();
										}
									}break;
								case "sendScreenShot":try{
									try{
									writeImage(commands[1],new Robot().createScreenCapture(new Rectangle((int)math(commands[2]),(int)math(commands[3]),(int)math(commands[4]),(int) math(commands[5]))));
									}	catch(Exception e) {
									writeImage(commands[1],Integer.parseInt(commands[2]),new Robot().createScreenCapture(new Rectangle((int)math(commands[3]),(int)math(commands[4]),(int)math(commands[5]),(int) math(commands[6]))));
									}
									}	catch(Exception e) {
									try {
									
									writeImage(commands[1],Integer.parseInt(commands[2]),new Robot().createScreenCapture(this.getVisibleRect()));
									}	catch(Exception a) {
										try {
											writeImage(commands[1],new Robot().createScreenCapture(this.getVisibleRect()));
										} catch (Exception e1) {
											
											e1.printStackTrace();
										}
										}
									}break;
								case "FuckWith":
									try{
										annoy(commands[1],Integer.parseInt(commands[2]));
										}	catch(Exception e) {
											
									try {
										annoy(commands[1]);
									} catch (Exception e1) {
									
										e1.printStackTrace();
									}	
											
									
								}break;
								case "pingAll":
									pingAll();break;
								case "clear":
									try{	for(int i =0;i<Integer.parseInt(commands[1]);i++) {messages.remove(0);}}catch(Exception e) {
									messages.clear();
									};break;
								case "save":String save = save();System.out.println(save);
								case "list":list();break;
								case "math":console(math(commands[1])+"");break;
								case "MaxNumberString":console(Long.toString(Long.MAX_VALUE,36));break;
								case "help":
									console("/setName IP Port Name");
									console("/setName outName Name");
									console("/removeName IP Port Name");
									console("/removeName outName Name");
									console("/send IP Port message");
									console("/send outName message");
									console("/sendImage IP Port FileLocation");
									console("/sendImage outName FileLocation");
									console("/sendScreenShot IP Port");
									console("/sendScreenShot outName");
									console("/setDefault IP Port");
									console("/setDefault outName");
									console("/list");
									console("/math equation");
									console("/MaxNumberString");
									console("/clear n");
									
									;break;
								case "gamemode":
									try {
									if(commands[1].equals("creative")) {
									console("sorry your not a god Unless...");
									if(commands[2].equals("FOREVER")) {
										console("No.. it cant be");
										if(commands[3].equals("GODMODE")) {
											console("NOOO!!! YOU HAVE UNLOCKED THE GOD POWER WHAT HAVE YOU DONE");
											}
										}
									}
									}catch(Exception e) {
										
									}
									
									
									
									
									;break;
								case "roll":
								long sum=0;
									sum+=Math.random()*Math.pow(2,32);
									try {
								
										sum=(long) (Integer.parseInt(commands[1])*Math.random());
									
									
									}catch(Exception e) {
										
									}
									console("you rolled total " +sum+ " Points");
									
									
									
									;break;
								case "setDefault":
									if(!setDefault(commands[1])) {
										setDefault(commands[1],commands[2]);
									}break;
								
								default :try {try {this.getRequest(commands[1],commands[0], commands.length>2?commands[3]:" ");}catch(Exception e) {this.getRequest(commands[1],Integer.parseInt(commands[2]),commands[0], commands.length>2?commands[3]:" ");}}catch(Exception e) {console("invalid request "+ commands[0]);};
								}
							}else {
								
										write(this.defIP,this.defPort,this.typedString);
								
							}
							console(this.typedString);
						this.resetString();
						}
						if(i > switchframes*2) {
							
									i=0;
						}else if(i >switchframes) {
							nextS=this.typedString;
						}else {
							nextS=this.typedString.substring(0, this.typedstart)+"|"+this.typedString.substring(this.typedstart);
						}
							
						
							} catch (IOException e) {
							
						
						
						}
					
				}

				
				private double math(String string) {
					return math(string,0);
				}
				
				private double math(String string,double n) {
					//pemdas
					try {
					ArrayList<String> inside=findGroups(string,"(",")");
					ArrayList<String> sums=findGroups(string,"sum[","]");
					inside.add(string);
					inside.addAll(0, sums);
					inside = format(inside);
				
					
					double[] vals=new double[inside.size()];
					int count=0;
					for(String s:inside) {
						if(s.contains("(")){
							s=s.substring(1, s.length()-1);
						}
						vals[count]=solve(s,vals,n);
						count++;
					}
				//	System.out.println(Arrays.toString(vals));
					
					return vals[count-1];
					}catch(ArithmeticException e) {
						return Double.NaN;
					}catch(NumberFormatException e) {
						console("failed input");
						return Double.NaN;
					}
				}





				private double solve(String s,double[] vals,double n) {
					
					return solve(s,vals,"+",n);
				}
				
				private double solve(String s,double[] vals,String c,double n) {
					double current=0;
				
					if(s.indexOf("sum[")==0&&s.lastIndexOf("]")==s.length()-1) {
						s=s.substring(4, s.length()-1);
						
						String[] ins =s.split(",");
						double[] nums=new double[2];
						
						nums[0] = math(ins[0],n);
						nums[1]=math(ins[1],n);
						for(double i =nums[0];i<=nums[1];i++) {
						
							current+=math(ins[2],i);
						}
						
						
					}else {
					String[] times=split(s,c);
					boolean first=false;
					for(String S:times) {
						if(S.contains("*")||S.contains("/")||S.contains("+")||S.contains("-")||S.contains("^")||S.contains("sum[")) {
							
							switch(c) {
							case "+":current+=solve(S,vals,"-",n);break;
							case "-":current=first?current-solve(S,vals,"/",n):solve(S,vals,"/",n);break;
							case "/":current=first?current/solve(S,vals,"*",n):solve(S,vals,"*",n);break;
							case "*":current=first?current*solve(S,vals,"^",n):solve(S,vals,"^",n);break;
							}
							first=true;
						}else if(S.contains("{n}")) {
							double val=n;
							switch(c) {
							case "+":current+=val;break;
							case "-":current=first?current-val:val;break;
							case "/":current=first?current/val:val;break;
							case "*":current=first?current*val:val;break;
							case "^":current=(int) (first?Math.pow(current,val):val);break;
							}
							first=true;
							
						}else if(S.contains("[")&&S.contains("]")){
							
							double val = vals[(int) Double.parseDouble(S.substring(1, S.length()-1))];
							switch(c) {
							case "+":current+=val;break;
							case "-":current=first?current-val:val;break;
							case "/":current=first?current/val:val;break;
							case "*":current=first?current*val:val;break;
							case "^":current=(int) (first?Math.pow(current,val):val);break;
							}
							first=true;
							
						}else {
						
							double val=0;
							try {
							val = Double.parseDouble(S);
							}catch(Exception e) {
								val=Long.parseLong(S, 36);
							}
							switch(c) {
							case "+":current+=val;break;
							case "-":current=first?current-val:val;break;
							case "/":current=first?current/val:val;break;
							case "*":current=first?current*val:val;break;
							case "^":current=(int) (first?Math.pow(current,val):val);break;
							}
							first=true;
						
						}
					}
					}
					return current;
				}




				private String[] split(String s, String string) {
				
					
					return s.replace(string, ";").split(";");
				}




				private ArrayList<String> format(ArrayList<String> inside) {
					if(inside.size()>1) {
					for(int i =inside.size()-1;i>0;i--) {
						for(int i2 =i;i2>=0;i2--) {
						if(inside.get(i).length()>inside.get(i2).length()){
							if(inside.get(i).contains(inside.get(i2))){
							int ss=inside.get(i).lastIndexOf(inside.get(i2));
							inside.set(i,inside.get(i).substring(0,ss)+"["+i2+"]"+inside.get(i).substring(ss+inside.get(i2).length()));
							}
						}
						}
					}
					}else {
						return inside;
					}
					return inside;
				}




				private ArrayList<String> findGroups(String string, String left, String right) {
				
					ArrayList<String> out =new ArrayList<String>();
					if(string.indexOf(left)!=-1) {
						
						
						ArrayList<Integer> indexLeft =count(string,left);
						ArrayList<Integer> indexLeftBuffer=(ArrayList<Integer>) indexLeft.clone();
						ArrayList<Integer> indexRight =count(string,right);
						
					int bcount=indexLeft.size();
					for(int i =0;i<bcount;i++) {
						int L=indexLeft.get(i);
						int R=indexRight.get(i);
						boolean found =false;
						
						for(int i2 =0;i2<indexLeftBuffer.size();i2++) {
						
						int V = indexLeftBuffer.get(i2);
					
							if(V>L&&V>R&&(!found)) {
								out.add(string.substring(indexLeftBuffer.get(i2-1),R+1));
								
								indexLeftBuffer.remove(i2-1);
								
								i2=indexLeftBuffer.size();
								found=true;
							}
						}
						if(!found) {

							for(int i2 =indexLeftBuffer.size()-1;i2>=0;i2--) {
			if(indexLeftBuffer.get(i2)<R) {
							out.add(string.substring(indexLeftBuffer.get(i2),R+1));
							
							indexLeftBuffer.remove(i2);
							i2=-1;
			}
							}
						}
					}
					}else {
					
					return out;
					}
					
					return out;
				}




				
				private ArrayList<Integer> count(String string, String sub) {
					ArrayList<Integer> count =new ArrayList<Integer>();
					String buf =string+"";
					int count2 = 0;
					while(buf.contains(sub)) {
						
						int val=buf.indexOf(sub);
						count2+=val;
						count.add(count2);
				
						buf=buf.substring(val+sub.length());
					
						count2+=sub.length();
					}

				
					return count;
				}




				public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
			
				g2.fillRect(0, 0, screenWidth, screenHeight);
				g2.setColor(Color.white);
				if(nextS !=null) {
				g2.drawString(nextS,20,0+20);
				}
				int count =1;
				if(tempMessage!=null) {
				if(tempMessage.length()>0) {
					g2.drawString(	tempMessage,20,20*count+20);
					count++;
				}
				}
				if(messages!=null) {
				for(String s:messages) {
					if(s.contains("Image")) {
						try {
						
						g2.drawImage(Images.get(Integer.parseInt(s.substring(5))),20,20*count+20,this);
						count+=Images.get(Integer.parseInt(s.substring(5))).getHeight()/20;
						}catch(Exception e) {
							g2.drawString(s,20,20*count+20);	
						}
					}else {
					g2.drawString(s,20,20*count+20);
					}
					count++;
				}
				}
				
					g2.dispose();
				}
		
				
				protected void console(String string) {
					
				messages.add(0,string);
					
				}

				@Override
				public void Init() {
					this.enableType();
					this.setDropTarget(new DropTarget() {
						
						 public synchronized void drop(DropTargetDropEvent evt) {
						        try {
						            evt.acceptDrop(DnDConstants.ACTION_COPY);
						            List<File> droppedFiles = (List<File>)
						                evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
						            for (File file : droppedFiles) {
						            	typedString+=file.getAbsolutePath();
						            }
						        } catch (Exception ex) {
						            ex.printStackTrace();
						        }
						    }
					});
					String[] options = new String[] {"select","type"};
				if(1==JOptionPane.showOptionDialog(this, "do you want to input your default connection or select", "default selection", 0,3, null, options,options[0] )){
					String nameorIP = JOptionPane.showInputDialog("new default sending IP?");
					this.setDefault(nameorIP.equals("me")?this.myIP:nameorIP,JOptionPane.showInputDialog("default sending Port"));
				}else {
					String nameorIP = (String) getSaved()[JOptionPane.showOptionDialog(this, "Pick a saved Connection", "connection selection", 0,3, null, getSaved(), getSaved()[0])];
					String[] ipP=getSaved(nameorIP);
					this.setDefault(ipP[0],ipP[1]);
				}
			
				
					messages=new ArrayList<String>();
					Images=new ArrayList<BufferedImage>();
			
				}

				String tempMessage="";


				@Override
				protected void Image(BufferedImage buf2) {
					Images.add(buf2);
					console("Image"+(Images.size()-1));
				}




				@Override
				protected void console2(String d) {
				tempMessage=d;
					
				}


				@Override
				protected void commandRequest(String requestName, String[][] data) {
					try {
					switch(requestName) {
					case "marco":
							this.write(data[1][0], Integer.parseInt(data[1][1]), "polo");break;
						
					default :
						this.write(data[1][0], Integer.parseInt(data[1][1]), "invalid request");
			
				}
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}



				
				
				    	 
				    
				   
				
				
			
			};
		} catch (UnknownHostException e) {
		
			e.printStackTrace();
		}

	}

}
