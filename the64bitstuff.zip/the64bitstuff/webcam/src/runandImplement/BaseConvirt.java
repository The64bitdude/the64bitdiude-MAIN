package runandImplement;

import java.util.Arrays;

public class BaseConvirt {
public static void main(String[] args) {

	String in ="46";
	String in2 ="-72";
	int inBase=10;
	int outBase=2;
	System.out.println(Integer.toUnsignedString(Integer.parseInt(in,inBase),outBase));
	System.out.println(Integer.toUnsignedString(Integer.parseInt(in2,inBase),outBase));
	System.out.println(Integer.toUnsignedString(Integer.parseInt(in,inBase)+Integer.parseInt(in2,inBase),outBase));
	System.out.println(Integer.parseInt(in,inBase)+Integer.parseInt(in2,inBase));
	}

}
