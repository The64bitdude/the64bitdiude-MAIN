package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.JFrame;

import Screens.RefreshScreen;

public class refreshtest {
	static char color;
public static void main(String[] args) {
	new RefreshScreen(750,750,Color.BLACK,-1,3) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}
		ArrayList<Integer> vals;
		int[] vals2;
		int i =0;
		@Override
		public void update() {
		
			if(i>=vals2.length) {
				i=0;
				
				for(int x =0;x<screenWidth;x++) {
					vals.add(x);
				}
				vals2=new int[vals.size()];
				Collections.shuffle(vals);
			}
		
vals2[vals.get(0)]= vals.get(0);
vals.remove(0);
			
			i++;
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.black);
			g.fillRect(0, 0, screenWidth,screenHeight);
			g.setColor(Color.WHITE);
			for(int x =0;x<vals2.length;x++) {
				
				g.drawLine(x, 0, x, vals2[x]);
				
			
				}
			for(int x =0;x<vals.size();x++) {
				
					g.drawLine(x, 0, x, vals.get(x));
					
				
			}
			
			g.dispose();
		}

		@Override
		public void initialize() {
			vals=new ArrayList<Integer>();
			
			for(int x =0;x<screenWidth;x++) {
				vals.add(x);
			}
		
		Collections.shuffle(vals);
		vals2=new int[vals.size()];
			
		}
		
	};
}
}
