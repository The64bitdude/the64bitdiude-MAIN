package Systems;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

public class TCSIndex {
	public HashMap<Integer,Shader> type;
	public ArrayList<PointVector> lights;
	/**
	 * type color shader
	 * uses the number to define what block it represents and the color of each side
	 */
	public TCSIndex() {
		type = new HashMap<Integer,Shader>();
		lights= new ArrayList<PointVector>();
	}
	public void put(int index,Shader c) {
		c.setLights(lights);
		type.put(index,c);
	}
	public Shader get(int index) {
		return type.get(index);
	}
	public void setLights() {
		for(int k:type.keySet()) {
		type.get(k).setLights(lights);
		
		}
	}
	public void addLight(PointVector p) {
		lights.add(p);
	}
	public void changeLight(int index,PointVector p) {
		lights.set(index,p);
	}
	public void clear() {
		lights.clear();
		
	}

}
