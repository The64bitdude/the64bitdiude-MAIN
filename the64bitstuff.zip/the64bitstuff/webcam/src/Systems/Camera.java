package Systems;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;

import Physics.Vector3D;

public class Camera {

	private double paneSize;
	public double FOV;
	public double panel;
	public Point3D cam;
	public double angle1 = 0;
	public double angle2 = 0;
	public double screenHeight;
	public double screenWidth;
	public Vector3D SX;
	public Vector3D camV;
	public Vector3D SY;
	

	public Camera(double fov,double screenWidth,double screenHeight,Point3D p,double a1,double a2) {
		this.screenWidth=screenWidth;
		this.screenHeight = screenHeight;
		FOV = fov;
		paneSize = this.screenWidth;
		if(this.screenWidth>this.screenHeight) {
		paneSize = this.screenHeight;
		}
		panel = (paneSize*(Math.tan(Math.toRadians((90-FOV)))));
		cam = p;
		angle1=a1;
		angle2=a2;
		
	}

	public Camera(Point3D p, double panel, double a1, double a2, double screenWidth, double screenHeight) {
		this.screenWidth=screenWidth;
		this.screenHeight=screenHeight;
		this.panel=panel;
		paneSize = this.screenWidth;
		if(this.screenWidth>this.screenHeight) {
		paneSize = this.screenHeight;
		}
		FOV = (-Math.toDegrees(Math.atan(this.panel/paneSize))+90);
		cam = p;
		
	}

	public double getPanel() {
		return panel;
	}

	public void setPanel(double panel) {
		this.panel = panel;
	}
		public boolean CanSee(ArrayList<PointD> ps) {
		// TODO Auto-generated method stub
	
		
		for(PointD p :ps) {
			if(p.getDist()>0&&p.x>0&&p.y>0&&p.x<screenWidth&&p.y<screenHeight) {
				return true;
			}
		}
		
	return false;
		
	

		
	}

	public void updateV() {
		camV=new Vector3D(Math.sin(angle1)*Math.cos(-angle2),Math.cos(angle1)*Math.cos(-angle2),Math.sin(-angle2));
		SX=new Vector3D(Math.cos(angle1),-Math.sin(angle1),0);
		SY=camV.cross(SX);
	camV.setmag();
		
	}

	public Vector3D getcamV() {
		// TODO Auto-generated method stub
		return camV;
	}

	public Vector3D getSX() {
		// TODO Auto-generated method stub
		return SX;
	}

	public Vector3D getSY() {
		// TODO Auto-generated method stub
		return SY;
	}

	public boolean CanSee(int x, int y, int z,int size) {

		return new Point3D(x*size,y*size,z*size).project(this).getDist()+size>0;
	}

	
}
