package Systems;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import Physics.Vector3D;

public class Shader {
	Color[] sideColors;
	public BufferedImage[] sideImages;
	boolean transparent;
	boolean lightSource=false;
	public boolean Image=false;
	public int rez = 1;
	double sunangle=0;
	double[] sideShade;
	Vector3D[] sideVectors;
	public Shader() {
		this.transparent=false;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		setAll(new Color(0,0,0));
		vectors();
		
	}
	public Shader(Color c) {
		this.transparent=false;
		sideImages = new BufferedImage[8];
		sideColors = new Color[8];
		setAll(c);
		vectors();
	}
	public Shader(Color c,BufferedImage b, int rez) {
		this.transparent=false;
		sideImages = new BufferedImage[8];
		setALL(b);
		this.rez = rez;
		sideColors = new Color[8];
		setAll(c);
		Image = true;
		vectors();
	}
	public Shader(Color c,BufferedImage b, int rez,boolean transparent) {
		this.transparent=transparent;
		sideImages = new BufferedImage[8];
		setALL(b);
		this.rez = rez;
		sideColors = new Color[8];
		setAll(c);
		Image = true;
		vectors();
	}
	
	public Shader(Color c,BufferedImage[] b,int rez) {
		this.transparent=false;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		sideImages=b;
		this.rez = rez;
		Image = true;
		setAll(c);
		vectors();
	}
	public Shader(Color c,boolean transparent) {
		this.transparent=transparent;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		setAll(c);
		vectors();
	}
	public Shader(Color[] Sides) {
		
		this.transparent=false;
		sideImages = new BufferedImage[8];
		sideColors = Sides;
		vectors();
	}
		//west 0
		//south1
		//up   2
		//down 3
		//north4
		//east 5
	private void vectors() {
		lights=new ArrayList<PointVector>();
	sideVectors=new Vector3D[6];
	sideVectors[0]=new Vector3D(1,0,0);
	
	sideVectors[1]=new Vector3D(0,1,0);

	sideVectors[2]=new Vector3D(0,0,1);

	sideVectors[3]=new Vector3D(0,0,-1);
	
	sideVectors[4]=new Vector3D(0,-1,0);
	
	sideVectors[5]=new Vector3D(-1,0,0);
	
	
	}
	public void setAll(Color c) {
	for(int i = 0;i<8;i++) {
		sideColors[i]=c;
	}
	}
	public void setALL(BufferedImage b) {
		for(int i = 0;i<8;i++) {
			sideImages[i]=b;
		}
		
	}
	public void setWest(Color c) {
		sideColors[0]=c;
	}
	public void setSouth(Color c) {
		sideColors[1]=c;
	}
	public void setUp(Color c) {
		sideColors[2]=c;
	}
	public void setDown(Color c) {
		sideColors[3]=c;
	}
	public void setNorth(Color c) {
		sideColors[4]=c;
	}
	public void setEast(Color c) {
		sideColors[5]=c;
	}
	public void shade(double sunAngle) {
		sunangle=sunAngle;
		sideShade=new double[6];
		
		sideShade[0]=(sunAngle > Math.toRadians(90)?0.60:(0.60+Math.abs(0.40*Math.cos(sunAngle))));
		shade(0);
		sideShade[1]=Math.abs(0.60+0.30*Math.sin(sunAngle));
		shade(1);
		sideShade[2]=Math.abs(0.50+0.50*Math.sin(sunAngle));
		shade(2);
		sideShade[3]=Math.abs(0.60-0.50*Math.sin(sunAngle));
		shade(3);
		sideShade[4]=Math.abs(0.60+0.30*Math.sin(sunAngle));
		shade(4);
		sideShade[5]=(sunAngle < Math.toRadians(90)?0.60:(0.60+Math.abs(0.40*Math.cos(sunAngle))));
		shade(5);
	}
	

	public void shade(int side) {
	
		sideColors[side] =new Color((short) (sideColors[side].getRed()*sideShade[side]),(short)(sideColors[side].getGreen()*sideShade[side]),(short)(sideColors[side].getBlue()*sideShade[side]),sideColors[side].getAlpha());
	}
	public void addLight(PointVector p) {
		lights.add(p);
	}
	public void setLights(ArrayList<PointVector> newlights) {
		lights=newlights;
	}
	public ArrayList<PointVector> lights;
	public double getLight(int side,Point3D point) {
		
		double out=1;
		
		for(PointVector light: lights) {
			double dist = point.distance(light.p);
			
			if(dist!=0) {
				if(light.v.mag!=0) {
			out*=Math.max(1,sideVectors[side].dot(light.v)/(dist));
		
				}else {
					out*=Math.max(1,((light.v.x/50.0)*sideVectors[side].dot(new Vector3D(point.sub(light.p))))/(dist*Math.sqrt(dist)));
				}
				}
		
		}
		out=Math.min(2.5, out);
		return out;
	}

	public Color shade(int rgb,int side,Point3D point) {
	
		Color c=new Color(rgb,true);
		double shade=getLight(side,point);
		c =new Color((short) (Math.min(255,c.getRed()*sideShade[side]*shade)),(short)(Math.min(255,c.getGreen()*sideShade[side]*shade)),(short)(Math.min(255,c.getBlue()*sideShade[side]*shade)),c.getAlpha());
		
		return c;
	}
	//west 0
	//south1
	//up   2
	//down 3
	//north4
	//east 5
	public Color shade(int side, Point3D point) {
		Color c=sideColors[side];
		double shade=getLight(side,point);
		c =new Color((short) (Math.min(255,c.getRed()*sideShade[side]*shade)),(short)(Math.min(255,c.getGreen()*sideShade[side]*shade)),(short)(Math.min(255,c.getBlue()*sideShade[side]*shade)),c.getAlpha());
		
		return c;
	}
	public void shadeA(double d) {
		sunangle=d;
		sideShade=new double[] {d-0.1,d-0.05,d,d-0.125,d-0.075,d-0.025};
		
		shade(0);
		shade(1);
		shade(2);
		shade(3);
		shade(4);
		shade(5);
		
	}
	public Color shade(int rgb, int side, double shade) {
	
			
			Color c=new Color(rgb,true);
			
			c =new Color((short) (Math.min(255,c.getRed()*sideShade[side]*shade)),(short)(Math.min(255,c.getGreen()*sideShade[side]*shade)),(short)(Math.min(255,c.getBlue()*sideShade[side]*shade)),c.getAlpha());
			
			return c;
		
	}

	
		
		
	

}
