package Systems;

import java.awt.Point;
import java.awt.Polygon;
import java.util.ArrayList;

public class Polygon3D {
	public ArrayList<Point3D> points;
	public Polygon3D() {
		points = new ArrayList<Point3D>();
	}
	public Point3D calcAveragePoint() {
		Point3D out = new Point3D(0,0,0);
		for(Point3D p:points) {
			out.x += p.x;
			out.y += p.y;
			out.z += p.z;
		}
		out.x/=points.size();
		out.y/=points.size();
		out.z/=points.size();
		return out;
		
	}
	public void addPoint(Point3D p) {
		points.add(p);
	}
public void addPoint(double x, double y, double z) {
	points.add(new Point3D().setLocation(x, y, z));
	}
	public boolean contains(Polygon3D buf,Camera camera) {
		Polygon x = new Polygon();
		Polygon z = new Polygon();
	for(Point3D p:points) {
		x.addPoint((int)p.x, (int)p.y);
		x.addPoint((int)p.z, (int)p.y);
	}
	Polygon x2 = new Polygon();
	Polygon z2 = new Polygon();
for(Point3D p:buf.points) {
	x2.addPoint((int)p.x, (int)p.y);
	x2.addPoint((int)p.z, (int)p.y);
}
if(x.getBounds2D().contains(x2.getBounds2D())&&z.getBounds2D().contains(z2.getBounds2D())) {
	return true;
}
	
			return false;
	
	}
	public double distance(Camera camera) {
		return calcAveragePoint().distance(camera);
	}
	public void add(Rect3D rect3d) {
		for(Point3D p :rect3d.getPoints()) {
			if(!contains(p)) {
			addPoint(p);
			}
		}
		
	}
	public boolean contains(Point3D p2) {
		Polygon x = new Polygon();
		Polygon z = new Polygon();
	for(Point3D p:points) {
		x.addPoint((int)p.x, (int)p.y);
		x.addPoint((int)p.z, (int)p.y);
	}
	Polygon x2 = new Polygon();
	Polygon z2 = new Polygon();

	x2.addPoint((int)p2.x, (int)p2.y);
	x2.addPoint((int)p2.z, (int)p2.y);
if(x.getBounds2D().contains(x2.getBounds2D())&&z.getBounds2D().contains(z2.getBounds2D())) {
	return true;
}
	
			return false;
	
	}

}
