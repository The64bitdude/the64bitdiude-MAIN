package Systems;

import java.util.Random;

public class WorldMap {
	BlockMap[][] map;
	public double seed;
	public int size;
	public double Xsize;
	public double Ysize;
	public WorldMap(int x,int y,int size){
	map = new BlockMap[x][y];
	this.Xsize=x*size;
	this.Ysize=y*size;
	this.seed = new Random().nextGaussian() * 255;
	this.size = size;
	}
	public void generate(int size,int waterHeight,int sandHeight,int stoneHeight,int snowHeight,int startheight,int blocksize,double seed) {
		
	}
	public void generate(int size,int waterHeight,int sandHeight,int stoneHeight,int snowHeight,int startheight,int blocksize) {
		for(int x = 0;x<map.length;x++) {
			for(int y = 0;y<map[x].length;y++) {
				map[x][y]=new BlockMap(this.size,this.size,this.size,blocksize);
				map[x][y].tperlin(blocksize, waterHeight, sandHeight, stoneHeight, snowHeight, startheight, x*this.size, y*this.size);
			}
		}
	}
	public int getBlock(int x,int y,int z) {
		return map[Math.round(x/size)][Math.round(y/size)].map[x][y][z];
	}
	public void setBlock(int x,int y,int z,int block) {
		map[Math.round(x/size)+250][Math.round(y/size)+250] = new BlockMap(size,size,size,100);
		map[Math.round(x/size)+250][Math.round(y/size)+250].map[x][y][z]=block;
	}
	public void setMap(int X,int Y,BlockMap blocks) {
		for(int x = 0;x<blocks.map.length;x++) {
			for(int y = 0;y<blocks.map.length;y++) {
				for(int z = 0;z<blocks.map.length;z++) {
					setBlock(x+X,y+Y,z,blocks.map[x][y][z]);
				}
			}
		}
	}
	public int[][][] getMapChunk(int X,int Y,int size) {
		return getMap(X*this.size, Y*this.size, size);
	}
	public int[][][] getMap(int X,int Y,int size) {
		int[][][] out = new int[size][size][size];
		for(int x = 0;x<size;x++) {
			for(int y = 0;y<size;y++) {
				for(int z = 0;z<size;z++) {
					out[x][y][z]=getBlock(x+X,y+Y,z);
				}
			}
		}
		return out;
	}
}
