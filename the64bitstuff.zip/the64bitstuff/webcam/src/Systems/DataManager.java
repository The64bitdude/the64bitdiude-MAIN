package Systems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class DataManager {
	HashMap<String,HashMap<Integer,Integer>> dataSets;
	
	public DataManager() {
		dataSets =new HashMap<String,HashMap<Integer,Integer>>();
	
	}
	public void addData(String type,int data) {
		if(dataSets.containsKey(type)) {
			if(dataSets.get(type).containsKey(data)) {
				dataSets.get(type).put(data,dataSets.get(type).get(data)+1 );
			}else {
				dataSets.get(type).put(data,1 );
			}
		}else {
			dataSets.put(type,new HashMap<Integer,Integer>());
		}
	}
	public String toString(String type) {
		return dataSets.get(type).toString();
	}
	public boolean contains(String type, int data) {
		return dataSets.get(type).get(data)!=null;
		
	}
	public int get(String type, int data) {
		return dataSets.get(type).get(data);
		
	}

	public boolean duplicates(String type) {
		Set<Integer> vals = dataSets.get(type).keySet();
		
		for(int i:vals) {
		if(dataSets.get(type).get(i)!=1) {
			return true;
		}
		}
		return false;
		
		
	}
	public void clear(String type) {
	dataSets.get(type).clear();
		
	}
}
