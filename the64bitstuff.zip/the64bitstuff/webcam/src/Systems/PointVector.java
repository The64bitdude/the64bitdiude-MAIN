package Systems;

import Physics.Vector3D;

public class PointVector {
public Point3D p;
public Vector3D v;

public PointVector(Point3D p,Vector3D v) {
	this.p=p;
	this.v=v;
}
public PointVector(Point3D p,double mag) {
	this.p=p;
	this.v=new Vector3D(mag,mag,mag);
	this.v.unsetmag();
}
}
