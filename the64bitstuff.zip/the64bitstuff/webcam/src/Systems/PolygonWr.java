package Systems;

import java.awt.Color;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class PolygonWr{
	public BufferedImage texture;
	public Color c;
	public Point3D r;
	public Polygon p;
	public Point rcam;
	public double rdist;
	public int type;
	public int side;
	

	public PolygonWr(Polygon p) {
		this.p=p;
		this.c=Color.WHITE;
	}
	
	public PolygonWr(Polygon p,Color c) {
		this.p=p;
		this.c=c;
	}
	public PolygonWr(Polygon p,Point3D r,Color c,int type) {
		this.type=type;
this.p = p;
this.r=r;
this.c = c;
	}
	public PolygonWr(Polygon p,Point3D r,Color c,int type,double rdist) {
		this.type=type;
this.p = p;
this.r=r;
this.c = c;
this.rdist=rdist;
	}
	public PolygonWr(Point3D point3d,Color c, int type,int side) {
		this.side=side;
		this.type = type;
		this.p = new Polygon();
		this.r = point3d;
		this.c = c;
	}
	public boolean contains(PolygonWr p) {
		// TODO Auto-generated method stub
	
		if(this.rdist<p.rdist) {
			for(int i=0;i<p.p.npoints;i++) {
				if(!this.p.contains(p.p.xpoints[i],p.p.ypoints[i])) {
				
					return false;
				}
			}
			
			return true;
		}
		return false;
	
		
	

		
	}

	

}
