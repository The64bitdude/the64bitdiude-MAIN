package Systems;



import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import AI2.Brain;
import AI2.ReEnforcedAI;
import runandImplement.primeFinder;

public class Encript {

 


private static long[] hexToLong(String[] primes) {
	long[] out = new long[primes.length];
	int count =0;
	for(String s :primes) {
		out[count]=(long) (Double.parseDouble(s)*1000);
		count++;
	}
	return out;
}
private static long[] unHashString(String hashString) {


	
	long[] out = new long[numberOf(hashString,"z")];
	
	
	int count =0;
	while(hashString.contains("z")) {
		int zindex=hashString.indexOf("z");
		out[count]=parseLong(hashString.substring(0,zindex),35);
		hashString=hashString.substring(zindex+1);
		count++;
	}
	return out;
}

private static long parseLong(String in, int index) {
	long out =0;
	for(int i =0;i<in.length();i++) {
	out+=pow(index, i)*((in.charAt(i)-48)<=9?(in.charAt(i)-48):(in.charAt(i)-87));
	}
		return out;
}
private static int numberOf(String hashString, String string) {
	// TODO Auto-generated method stub
	int index = hashString.indexOf(string);
	if(index!=-1) {
	return 1+numberOf(hashString.substring(index+1), string);
	}else {
		return 0;
	}
}
private static String HashString(long[] encript,int Startindex) {
	if(Startindex<encript.length) {
	return ToString(encript[Startindex],35)+"z"+HashString(encript,Startindex +1 );
	}else {
		return "";
	}
}
private static String ToString(long in, int i) {
	String out = "";
	if(in <0) {
		in*=-1;
		while(in>0) {
			out+=(in%i)<=9?(char)(48-(in%i)):(char)(87-(in%i));
			in/=i;
			}
	}else {
	while(in>0) {
	out+=(in%i)<=9?(char)((in%i)+48):(char)((in%i)+87);
	in/=i;
	}
	}
		return out;
}
private static long[] XOR(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=a[i]^b[i%b.length];
	}
	return out;
}
private static long[] div(long[] ls, long[] primes) {
	long[] out = new long[ls.length];
	for(int i =0;i<ls.length;i++) {
		out[i]=ls[i]/primes[i%primes.length];
	}
	return out;
}
private static int[] matrixMul(int[] a, int[] b) {
	int[] out = new int[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=0;
		for(int i2 =0;i2<b.length;i2++) {
		out[i]+=a[i]*b[i2];
		}
	}
	return out;
}
public static String[] encript(String in,String pass) {

pass=encode(pass+in+"FIXTHING");

	if(in.length()%9==0) {

		return new String[] {pass,HashString(XOR(ArrayLongVal(in),ArrayLongVal(encode(pass,((in.length()/9))*9))),0)};	
	}

	return  new String[] {pass,HashString(XOR(ArrayLongVal(in),ArrayLongVal(encode(pass,((in.length()/9)+1)*9))),0)};
	
}









private static char[] XOR(char[] a, char[] b) {
	char[] out = new char[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=(char) (a[i]^b[i%b.length]);
	}
	return out;
}



public static String encode(String pass,int length) {
	
	long[] passVal =ArrayLongVal(pass);

	String[] primes = primeFinder.roundHexPrimes(length, 1/2.0);
for(int i =0;i<primes.length;i+=3) {
	String hold = primes[i];
	primes[i]=primes[primes.length-1-i];
	primes[primes.length-1-i]=hold;
}


	passVal=COS(XOR(COS(hexToLong(primes),XOR(passVal,hexToLong(primes))),hexToLong(primes)),passVal);

	
	pass=val(passVal);
	return pass;
	
}
public static String encode(String pass) {

	long[] passVal =ArrayLongVal(pass);

	String[] primes = primeFinder.roundHexPrimes(pass.length(), 1/2.0);
for(int i =0;i<primes.length;i+=3) {
	String hold = primes[i];
	primes[i]=primes[primes.length-1-i];
	primes[primes.length-1-i]=hold;
}

	passVal=COS(XOR(COS(hexToLong(primes),XOR(passVal,hexToLong(primes))),hexToLong(primes)),passVal);

	
	pass=val(passVal);
	return pass;
	
}
public static String dencode(String pass,int length) {
	
	long[] passVal =ArrayLongVal(pass);

	String[] primes = primeFinder.roundHexPrimes(length, 1/2.0);
for(int i =0;i<primes.length;i+=3) {
	String hold = primes[i];
	primes[i]=primes[primes.length-1-i];
	primes[primes.length-1-i]=hold;
}
	passVal=COS(XOR(hexToLong(primes),SIN(hexToLong(primes),NOR(passVal,hexToLong(primes)))),passVal);

	
	pass=val(passVal);
	return pass;
	
}



private static long[] aSIN(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=(long) (Math.abs(a[i]/Math.sin(b[i%b.length])));
	}
	return out;
}
private static long[] aCOS(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=(long) (Math.abs(a[i]/Math.cos(b[i%b.length])));
	}
	return out;
}
private static long[] SIN(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=(long) (Math.abs(a[i]*Math.sin(b[i%b.length])));
	}
	return out;
}
private static long[] COS(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=(long) (Math.abs(a[i]*Math.cos(b[i%b.length])));
	}
	return out;
}
private static long[] NOR(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=~((a[i])|(b[i%b.length]));
	}
	return out;
}
private static long[] OR(long[] a, long[] b) {
	long[] out = new long[a.length];
	for(int i =0;i<a.length;i++) {
		out[i]=a[i]|b[i%b.length];
	}
	return out;
}
private static long[] NOT(long[] ls) {
	long[] out = new long[ls.length];
	for(int i =0;i<ls.length;i++) {
		out[i]=~ls[i];
	}
	return out;
}
private static long[] add(long[] ls, long[] primes) {
	long[] out = new long[ls.length];
	for(int i =0;i<ls.length;i++) {
		out[i]=ls[i]+primes[i%primes.length];
	}
	return out;
}
private static long[] val(String[] in) {
	long[] out = new long[in.length];
	int i=0;
	for(String i2:in) {
		out[i]=longVal(i2.substring(9));
		i++;
	}
	return out;
}
private static long[] mul(long[] ls, long[] primes) {
	long[] out = new long[ls.length];
	for(int i =0;i<ls.length;i++) {
		out[i]=ls[i]*primes[i%primes.length];
	}
	return out;
}
public static String decript(String dat,String pass) {
//	System.out.println((numberOf(dat,"z"))*9);

	return val(XOR(unHashString(dat),ArrayLongVal(encode(pass,(numberOf(dat,"z"))*9))));
	
}
public static String val(int in) {
	String out = "";
while(in>0) {
out+=(char)((in%95)+31);
in/=95;
}
	return out;
	
	
}
public static String val(int in,int radix) {
	String out = "";
while(in>0) {
out+=(char)((in%radix)+31);
in/=radix;
}
	return out;
	
	
}
public static String val(long in) {
	String out = "";
while(in>0) {
out+=(char)((in%96)+31);
in/=96;
}
	return out;
	
	
}
public static String val(byte in) {
	String out = "";
while(in>0) {
out+=(char)((in%96)+31);
in/=96;
}
	return out;
	
	
}
public static String val(long[] in) {
	String out = "";
for(long i:in) {
	out+=val(i);
}
	return out;
	
	
}
public static String val(byte[] in) {
	String out = "";
for(byte i:in) {
	out+=val(i);
}
	return out;
	
	
}
public static String val(int[] in) {
	String out = "";
for(int i:in) {
	out+=val(i);
}
	return out;
	
	
}
public static int val(String in) {
	int out =0;
for(int i =0;i<in.length();i++) {
out+=Math.pow(96, i)*(in.charAt(i)-31);
}
	return out;

	
}
public static byte byteVal(String in) {

	return (byte)(in.charAt(0)-31);

	
}
public static byte[] ArrayByteVal(String in2) {
	
	byte[] out2=new byte[(in2.length())];
	for(int i =0;i<(in2.length());i++) {
		
			String in=in2.substring(i,i+1);
		
	
	
	
out2[i]=byteVal(in);
	}
	return out2;


	
}
public static int[] ArrayIntVal(String in2) {
	if((in2.length()%4)!=0) {
		String add ="";
		for(int i =0;i<(4-(in2.length()%4));i++) {
			add+=(char)31;
		}
		in2+=add;
	}
	int[] out2=new int[(in2.length()/4)];
	for(int i =0;i<(in2.length()/4);i++) {
		
			String in=in2.substring(i*4,(i+1)*4);
		
	
	
	
out2[i]=val(in);
	}
	return out2;


	
}
public static long[] ArrayLongVal(String in2) {

	if((in2.length()%9)!=0) {
		String add ="";
		for(int i =0;i<(9-(in2.length()%9));i++) {
			add+=(char)31;
		
		}
		in2+=add;
	}
	long[] out2=new long[(in2.length()/9)];
	for(int i =0;i<(in2.length()/9);i++) {
		
			String in=in2.substring(i*9,(i+1)*9);
		
	
	
	
out2[i]=longVal(in);
	}
	return out2;

	
}
public static long longVal(String in) {
	long out =0;
for(int i =0;i<in.length();i++) {
out+=pow(96, i)*(in.charAt(i)-31);
}
	return out;

	
}
public static long pow(int a,int b) {
	long out = 1;
	for(int i =0;i<b;i++) {
		out*=a;
	}
	return out;
	
}

 
}
