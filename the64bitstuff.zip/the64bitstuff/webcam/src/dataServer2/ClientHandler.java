package dataServer2;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import Screens.RefreshScreen;

public abstract class ClientHandler extends RefreshScreen{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ConnectionManager manager;
	public int myPort;
	public String DefaultSystemIP;
	public String myIP;
	public int defPort;
	public String defIP;
	HashMap<String,String> savedNames;
	/**
	 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
	 * 
	 * @author  The64BitDude
	 * @param sw is screenWidth
	 * @param sh is screenHeight
	 * @param c is the backround color
	 * @param fps screen frames per second
	 * @throws UnknownHostException 
	 * @see #RefreshScreen(int, int, Color, int, int)
	 */
	public ClientHandler(int port,int sw, int sh, Color c, int fps) throws UnknownHostException {
		super(sw, sh, c, fps);
		myPort=port;
		myIP=InetAddress.getLocalHost().getHostAddress();
		defIP = myIP;
		defPort=myPort+1;
		manager=new ConnectionManager(myPort) {

			@Override
			public void Message(String s) {
			message(s);
				
			}

			@Override
			public void Data(byte[] data) {
				// TODO Auto-generated method stub
				
			}
			
		};
		
	
	
	}

	protected synchronized void message(String s) {
		try {
			
			
				String m = s;
			
				try {
				String[] dataGroups=m.split(";");
				String[] restSave= new String[dataGroups.length-2];
				if(dataGroups.length>3) {
					
					String n3="";
					for(int i =2;i<dataGroups.length;i++) {
						n3+=dataGroups[i];
						if(i-2<restSave.length) {
						restSave[i-2]=dataGroups[i];
						}
					}
					dataGroups=new String[] {dataGroups[0],dataGroups[1],n3};
				}
			String[][] data = new String[][] {dataGroups[0].split(" "),dataGroups[1].split(" "),new String[] {dataGroups[2]}};
				if(!(((data[0][0].equals(myIP)||data[0][0].equals(DefaultSystemIP))&&data[0][1].equals(myPort+""))||((data[1][0].equals(myIP)||data[1][0].equals(DefaultSystemIP))&&data[1][1].equals(myPort+"")))) {
			
				if(savedNames.containsKey(data[0][0])) {
				
					String portandIP=savedNames.get(data[0][0]);
					write(portandIP.substring(0,portandIP.indexOf(" ")), Integer.parseInt(portandIP.substring(portandIP.indexOf(" ")+1)),data[2][0]);
					console(data[1][0]+" "+data[1][1]+" sent "+data[0][0]+" ; "+ data[2][0]);
				}else if(data[0].length>1){
				
					manager.write(data[0][0], Integer.parseInt(data[0][1]),data[2][0].getBytes());
					console(data[1][0]+data[1][1]+" sent "+data[0][0]+" "+data[0][1]+" ; "+ data[2][0]);
				}else if(data[0][0].equals("MYNAME")) {
				//	System.out.println(data[2][0]);
				savedNames.put(data[2][0], data[1][0]+" "+data[1][1]);
				String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
				System.out.println(backup);
				write(data[1][0], Integer.parseInt(data[1][1]),"your new name is "+data[2][0]);
				console(data[1][0]+" "+data[1][1]+" changed their name to "+ data[2][0]);
			
			
				
				}else if(data[0][0].equals("NOTMYNAME")) {
					//	System.out.println(data[2][0]);
					savedNames.remove(data[2][0], data[1][0]+" "+data[1][1]);
					String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
					System.out.println(backup);
					write(data[1][0], Integer.parseInt(data[1][1]),"removed "+data[2][0]+" as your name");
					console(data[1][0]+" "+data[1][1]+" removed "+ data[2][0] + " as their name");
				
				
					
				}else if(data[0][0].equals("ANNOY")) {
						//	System.out.println(data[2][0]);
					
						for(int i = 0;i<20;i++) {
							String out ="";
							for(int i2 = 0;i2<60;i2++) {
								out+=(char)((int)(Math.random()*(1024-32))+32);
							}
						console(data[1][0]+" "+data[1][1]+" SAYS "+out);
						}
					
						
					}else if(data[0][0].equals("IMAGE")) {
						//	System.out.println(data[2][0]);
						data[2]=restSave;
						int height= 0;
						int x=0;
						int y=0;
						String index="";
						for(int i = 0;i<data[2].length;i++) {
							String[] dat =data[2][i].split(" ");
							int dat1=Integer.parseInt(dat[0]);
							
							
							if(dat.length>1) {
								int dat2=Integer.parseInt(dat[1]);
								index=dat1+","+dat2;
								if(!buf.containsKey(index)) {
								buf.put(index,new BufferedImage(dat1,dat2,2));
								}
								 height= dat2;
							}else if(y<height){
		
								buf.get(index).setRGB(x, y, dat1);
								y++;
							}else {
								x++;
								y=0;
								buf.get(index).setRGB(x, y, dat1);
								y++;
								
							}
						
						}
						Image(buf.get(index));
					//	System.out.println("Image Receaved");	
					}else if(data[0][0].equals("IMAGEP")) {
						
						data[2]=restSave;
						
						int x=0;
						int y=0;
						String index = "";
						String[] dat =data[2][0].split(" ");
							int dat1=Integer.parseInt(dat[0],36);
							int dat2=Integer.parseInt(dat[1]);
							int dat3=Integer.parseInt(dat[2]);
							int dat4=Integer.parseInt(dat[3]);
						
							index=dat1+","+dat2+","+dat3;
							
							if(linen.containsKey(index)) {
						
							console2((linen.get(index)/(double)(dat2-1))*100+"%");
							
							 
							}
							if(!buf.containsKey(index)) {
								//console("image incomeing");
						
							buf.put(index,new BufferedImage(dat2,dat3,2));
						
						
							}
							x=dat4;
					
							buf.get(index).setRGB(x, 0, 1, dat3, toInt(data[2],1), 0, 1);
						
					
						addOne(index);
						if(buf.get(index)!=null&&linen.get(index)!=null&& linen.get(index)>=buf.get(index).getWidth()-1) {
							console2((linen.get(index)/((double)buf.get(index).getWidth()-1))*100+"%");
							Image(buf.get(index));
							console2("");
					
							buf.remove(index);
							linen.remove(index);
						}
					
					}else if(data[0][0].equals("ping")) {
						//	System.out.println(data[2][0]);
						
						write(data[1][0], Integer.parseInt(data[1][1]),data[2][0] + " connected");
					
					}else {
					commandRequest(data[0][0],data);
					}
			}else {
				if(data[1][0].equals(myIP)&&data[1][1].equals(myPort+"")) {
					console(data[1][0]+ " "+data[1][1]+" <-- your ip / your name --> "+ data[2][0]);
				}else {
				console(data[1][0]+ " "+data[1][1]+" sent you : "+ data[2][0]);
				}
			}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
	}
		
	

	protected abstract void commandRequest(String requestName, String[][] data);

	private int[] toInt(String[] strings, int i) {
		String[] s=Arrays.copyOfRange(strings, 1,strings.length);
		int[] out=new int[s.length];
		int count=0;
		for(String st:s) {
			out[count]=Integer.parseInt(st,36);
			count++;
		}
		return out;
	}
	private int[] toInts(String strings) {
		char[] s=strings.toCharArray();
		int[] out=new int[s.length];
		int count=0;
		for(char st:s) {
			out[count]=Integer.parseInt(st+"",36);
			count++;
		}
		return out;
	}

	private synchronized void addOne(String index) {
		if(linen.containsKey(index)) {
		linen.put(index,linen.get(index)+1);
		}else {
			linen.put(index,0);	
		}
		
	}

	/**
	 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
	 * 
	 * @author  The64BitDude
	 * @param sw is screenWidth
	 * @param sh is screenHeight
	 * @param c is the backround color
	 * @param fps screen frames per second
	 * @param type is the type of input you want
	 * <p></p><b>TYPES</b>
	 *<ul><li><b><code>KEYS</code></b> == 0 only the keys are initialized
     * <li><b><code>MOUSE</code></b> == 1    only the mouse is initialized
     * <li><b><code>MOUSEPOS</code></b> == 2   only the mouse position is initialized
     * <li><b><code>ALL</code></b> == 3   the mouse keys and mouse position are initialized
	 * </ul>
	 * @throws UnknownHostException 
	 * @see #RefreshScreen(int, int, Color, int)
	 */
	public ClientHandler(int port,int sw, int sh, Color c, int fps,int type) throws UnknownHostException {
		super(sw, sh, c, fps,type);
		myPort=port;
		myIP=InetAddress.getLocalHost().getHostAddress();
		defIP = myIP;
		defPort=myPort+1;
		manager=new ConnectionManager(myPort) {

			@Override
			public void Message(String s) {
			message(s);
				
			}

			@Override
			public void Data(byte[] data) {
				// TODO Auto-generated method stub
				
			}
			
		};
	
	
	}
	public HashMap<String,BufferedImage> buf;
	public HashMap<String,Integer> linen;
	public Object[] getSaved() {
		ArrayList<String> vals =new ArrayList<String>();
		vals.addAll(savedNames.keySet());
		vals.removeIf(new Predicate<String>(){

		
			@Override
			public boolean test(String t) {
				if(savedNames.get(t).equals(myIP+" "+myPort)) {
					
				return true;
				}else {
					return false;
				}
			}
			
		});
		return vals.toArray();
	}

	public String[] getSaved(String nameorIP) {

		return savedNames.get(nameorIP).split(" ");
	}


	protected abstract void console2(String d);
	protected abstract void Image(BufferedImage buf2);
	public void annoy(String IP, int port) throws Exception {
		
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
		 manager.write(IP, port,("ANNOY;"+myIP+" "+myPort+";"+"get good").getBytes() );
				} catch (IOException e) {
					console(IP +" "+port+" disconnected");
				}
				
				
			}
			}).start();
	}
	public void annoy(String Name) throws Exception {
		if(!savedNames.containsKey(Name)) {
			console("invalid name "+Name);
		}
		
		writeI(Name,("ANNOY;"+myIP+" "+myPort+";"+"get good") );
		
	}
	
	
	public void write(String IP, int port, String out) throws IOException {
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
		manager.write(IP, port,(IP + " "+port+";"+myIP+" "+myPort+";"+out).getBytes() );
				} catch (IOException e) {
					console(IP +" "+port+" disconnected");
				}
				
				
			}
			}).start();
	}
	
	public void list() {
		for(String key:savedNames.keySet()) {
			console(key +" "+savedNames.get(key));
		}
	}
	public void writeI(String IP, int port, String out) throws IOException {
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
		manager.write(IP, port,out.getBytes() );
				} catch (IOException e) {
					console(IP +" "+port+" disconnected");
				}
				
				
			}
			}).start();
		
	}
	public void writeI(String name, String out) throws Exception {
		if(!savedNames.containsKey(name)) {
			console("invalid name "+name);
		}
		String[] pI=savedNames.get(name).split(" ");
		writeI(pI[0], Integer.parseInt(pI[1]),out);
		
		
	}
	public void write(String name, String out) throws Exception {
		if(!savedNames.containsKey(name)) {
			console("invalid name "+name);
		}
		String[] pI=savedNames.get(name).split(" ");
		write(pI[0], Integer.parseInt(pI[1]),out);
		
		
	}
	
	public void setDefault(String ip,String port) {
		
				
				defIP=ip;
				defPort=Integer.parseInt(port);
			
	}
	public boolean setDefault(String name) {
		if(!savedNames.containsKey(name)) {
		return false;
		}else {
			String[] pI=savedNames.get(name).split(" ");
			defIP=pI[0];
			defPort=Integer.parseInt(pI[1]);
			return true;
		}
	}
	public String compress(String[] commands, int j) {
		String out = "";
		for(int i =j;i<commands.length-1;i++) {
			out += commands[i]+" ";
		}
		out += commands[commands.length-1];
		return out;
	}
	public void setName(String IP, int port, String Name) throws IOException {
		
		savedNames.put(Name,myIP+" "+myPort);
		String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
		System.out.println(backup);
		
		getRequest(IP, port,"MYNAME",Name );
		
	}
	public void getRequest(String IP, int port,String requestName, String otherData) throws IOException {
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					manager.write(IP, port,(requestName+";"+myIP+" "+myPort+";"+otherData).getBytes() );
				} catch (IOException e) {
					console(IP +" "+port+" disconnected");
				}
				
				
			}
			}).start();
		
	}
	public void getRequest(String name,String requestName,String otherData) throws NumberFormatException, IOException {
		if(!savedNames.containsKey(name)) {
			console("invalid name "+name);
		}
		String[] pI=savedNames.get(name).split(" ");
		getRequest(pI[0], Integer.parseInt(pI[1]),requestName,otherData);
	}
	public synchronized void writeMS2(String IP, int port,String sign, String out, int failLimit,int failTimeLimit) throws IOException {
	
		try {
			manager.write(IP, port,(sign+";"+myIP+" "+myPort+";"+out).getBytes() );
		} catch (ConnectException e) {
		if(failLimit>0) {
		long ti = System.currentTimeMillis();
		while(System.currentTimeMillis()-ti<failTimeLimit/10+failTimeLimit*Math.random()) {
			
		}
		writeMS2(IP,port,sign,out,failLimit-1,failTimeLimit );	
		}else {
			throw new ConnectException();
		}
	}		
				
				
		
	}
	public void writeMS(String name,String sign, String out) throws IOException {
		
		if(!savedNames.containsKey(name)) {
			console("invalid name "+name);
	
		}else {
			
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					 String[] pI=savedNames.get(name).split(" ");
					
					manager.write(pI[0], Integer.parseInt(pI[1]),(sign+";"+myIP+" "+myPort+";"+out).getBytes() );
				} catch (IOException e) {
					console(name+" disconnected");
				}
				
				
			}
			}).start();
		}
	}
	public void setName(String Name,String myNewName) throws Exception {
		savedNames.put(myNewName,myIP+" "+myPort);
		String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
		System.out.println(backup);
		writeI(Name,("MYNAME;"+myIP+" "+myPort+";"+myNewName) );
		
	}
	public void writeImage(String Name,File file) throws Exception {
		if(!savedNames.containsKey(Name)) {
			console("invalid name "+Name);
		}
		String[] pI=savedNames.get(Name).split(" ");
		writeImage(pI[0],Integer.parseInt(pI[1]),file );
	}
	
	public void writeImage(String Name,BufferedImage img) throws Exception {
		if(!savedNames.containsKey(Name)) {
			console("invalid name "+Name);
		}
		String[] pI=savedNames.get(Name).split(" ");
		writeImage(pI[0],Integer.parseInt(pI[1]),img );
	}
	public void pingAll() {
		for(String key:savedNames.keySet()) {
			
		
				try {
					writeMS(key,"ping",key);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
	public void writeImage(String ip,int port,BufferedImage img) throws Exception {
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
				int time = (int) (System.nanoTime()%Integer.MAX_VALUE);
				BufferedImage out =img;
	int width = out.getWidth();
	int height = out.getHeight();
	
			for(int x=0;x<width;x++) {
				String outS = "";
				int[] rgb=out.getRGB(x, 0, 1,height, null, 0, 1);
				for(int d:rgb) {
					
		
					outS+=";"+Integer.toString(d,36);
				}
			
				String outF=outS;
				int xf=x;
		
				new Thread(new Runnable() {

					@Override
					public void run() {
				try {
				
			writeMS2(ip,port,"IMAGEP",Integer.toString(time,36)+" "+width+" "+height+" "+xf+outF ,100,100);	
						
			
				} catch (IOException e) {
				
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					}
					}).start();
				
					
			
						
		}
				}catch(Exception e) {
					
				}
			}
			
		}).start();
	}
	public void writeImage(String ip,int port,File file) throws Exception {
		writeImage(ip,port,ImageIO.read(file));
		
	}
	
	public void removeName(String IP, int port, String Name) throws IOException {
		savedNames.put(Name,myIP+" "+myPort);
		String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
		System.out.println(backup);
		 manager.write(IP, port,("NOTMYNAME;"+myIP+" "+myPort+";"+Name).getBytes() );
		
	}
	public void removeName(String Name,String myNewName) throws Exception {
		savedNames.put(myNewName,myIP+" "+myPort);
		String backup =save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
		System.out.println(backup);
		writeI(Name,("NOTMYNAME;"+myIP+" "+myPort+";"+myNewName) );
		
	}
	
	protected abstract void console(String string);
	public void initialize() {
		DefaultSystemIP="127.0.0.1";
		try {
			manager=new ConnectionManager(myPort) {

				@Override
				public void Message(String s) {
				message(s);
					
				}

				@Override
				public void Data(byte[] data) {
					// TODO Auto-generated method stub
					
				}
				
			};
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		savedNames=new HashMap<String,String>();
		try {
			load(savedNames,new File("src/dataServer2/SavedIPs.dat"));
		} catch (FileNotFoundException e) {
			manager.reset(new File("src/dataServer2/SavedIPs.dat"));
		}
		linen=new HashMap<String,Integer>();
		buf=new HashMap<String,BufferedImage>();
		manager.start();
		Init();
	}
	private void load(HashMap<String, String> map, File file) throws FileNotFoundException {
	Scanner s = new Scanner(file);
	while(s.hasNextLine()) {
		String line = s.nextLine();
		map.put(line.substring(0,line.indexOf(" ")),line.substring(line.indexOf(" ")+1));
	}
	
	s.close();
		
	}
	public String save() throws IOException {
	
	
		return save(savedNames,new File("src/dataServer2/SavedIPs.dat"));
	}

	private String save(HashMap<String, String> map, File file) throws IOException {
		Scanner s = new Scanner(file);
		String backup="";
		while(s.hasNextLine()) {
			backup+=s.nextLine()+"\n";
		}
		s.close();
	FileWriter w=new FileWriter(file);
	String rest="";
	for(String key:map.keySet()) {
		rest+=key +" "+map.get(key)+"\n";
	}
	w.write(rest);
	w.close();
		return backup+ ":\n"+rest;
		
	}
	public abstract void Init();

	

}
