package dataServer2;


import java.io.File;
import java.io.FileNotFoundException;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Scanner;





public abstract class ConnectionManager {
	File readFile;
	int port;
	Thread T;
	boolean active =false;
	 String ip;
	public ConnectionManager(int port) throws UnknownHostException {
		this.ip=InetAddress.getLocalHost().getHostAddress();
		this.port = port;
		readFile=new File("src/dataServer2/read"+port+".dat");
		reset(readFile);
	}
	
	

	void reset(File file) {
		FileWriter e;
		try {
			e = new FileWriter(file);
			e.write("");
			e.close();
		} catch (IOException e2) {
		System.out.println("failed to reset or doesnt exsist");
		}

	}
	public void start() {
		
	T=new Thread(new Runnable() {

		public void run() {
			try {
				ServerSocket thisServerSocket = new ServerSocket(port);
				int count=0;
				
				
				
				while(!thisServerSocket.isClosed()) {
					
					//System.out.println("Connections Ready");
			
					Socket thisSocket =thisServerSocket.accept();
					int socketIndex = count;
					new Thread(new Runnable() {

						public void run() {
							try {

								InputStream in = thisSocket.getInputStream();
							
							
								boolean done=true;
								while(done) {
								if(in.available()!=0) {
								byte[] data=in.readAllBytes();
								Message(string(data));
								Data(data);
								
								done=false;
								}
								}
									
								
								in.close();
								
							} catch (IOException e) {
								System.out.println(socketIndex+" IN FAILED");
							}
							//System.out.println(socketIndex+" IN Disconnected");
							
							
						}
					

						private String string(byte[] bytes) {
							String out ="";
							for(byte b :bytes) {
								out+=(char)b;
							}
									
							return out;
						}
						
					}).start();
					
					//System.out.println(count + " Connected");
					count++;
				}
				thisServerSocket.close();
			} catch (IOException e) {
				System.out.println("SERVER FAILED");
			}
			
			
		}
		
	});
	T.start();
	active=true;
	}
	public void pause() {
		
		active=false;
		}
	
	public String getRest(File file)  {
		Scanner read;
		String rest = "";
		try {
			read = new Scanner(file);
			
			while(read.hasNextLine()) {
				rest+=read.nextLine()+"\n";
			}
			read.close();
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		
		return rest;
	}
	public boolean HasNextread()throws IOException {
		Scanner read =new Scanner(readFile);
		boolean out =read.hasNextLine();
		read.close();
		return out;
		
		
	
		
	}
	
	
	public HashMap<Integer,String> getConnected() throws FileNotFoundException{
		HashMap<Integer,String> out=new HashMap<Integer,String>();
		File LogFile=new File("src/dataServer2/ConnectionLogs.dat");
		try {
			Scanner read = new Scanner(LogFile);
			while(read.hasNextLine()) {
				String line =read.nextLine();
				out.put(Integer.parseInt(line.substring(0,line.indexOf(" "))),line.substring(line.indexOf(" ")+1));
			
			}
			
			
			read.close();
			return out;
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		throw new FileNotFoundException();
		
	}
	public byte[] readDat()throws IOException {
		Scanner read =new Scanner(readFile);
		String dat =read.nextLine();
		String rest = "";
		while(read.hasNextLine()) {
			rest+=read.nextLine()+"\n";
		}
		read.close();
		
		FileWriter r = new FileWriter(readFile);
		r.write(rest);
		r.close();
		try {
		return dat.substring(dat.indexOf(" "+1)).getBytes();
		}catch(Exception e){
			return "".getBytes();
		}
		
	
		
	}
	public abstract void Message(String s);
	
	public abstract void Data(byte[] data);
	
	public static String string(byte[] bytes) {
		String out ="";
		for(int i =0;i<bytes.length;i++) {
			if(bytes[i]==-60&&bytes[i+1]==-128) {
				out+=(char)256;
				i++;
			}else {
			out+=(char)bytes[i];
			}
		}
				
		return out;
	}
	public static byte[] unString(String s) {
		 byte[] out =new byte[s.getBytes().length];
		 char[] chars=s.toCharArray();
		for(int i =0;i<chars.length;i++) {
			if(chars[i]==256) {
				out[i]=-60;
				out[i+1]=-128;
				i++;
			}else {
			out[i]=(byte)chars[i];
			}
		}
				
		return out;
	}
	
	public boolean active() {
		
		return this.active;
	}
		public void write(String ip , int port, byte[] buf) throws IOException,ConnectException {
			
			Socket s=new Socket(ip,port);
			OutputStream o = s.getOutputStream();
				o.write(buf);
				s.close();
			
		
		
	
		
	}






	


		
	

	

}
