package AI2;

public class Layer {
	//[nodes][weights]
	double[][] weights;
	double[][] weightDIR;
	double[][] weightADJ;
	double[] activationDIR;
	public double ider=0;
	//[nodes]
	double[] bias;
	double[] biasDIR;
	double[] biasADJ;
	/**
	 * (Z/2|Z|  +  0.5)  dir 0 
	 */
	public final int BS=0;
	/**
	 *  (Z) dir 1
	 */
	public final int L=1;
	/**
	 *  (1/1+e^-z)   dir(a(1-a))
	 */
	public final int SIG= 2;
	/**
	 *  ((e^z-e^-z)/(e^z+e^-z))  dir -(a^2)+1
	 */
	public final int TANH=  3;
	/**
	 *  (Math.MAX(0,z)) dir 0.5 > 0 else 0
	 */
	public final int ReLU=4;
	/**
	 *  (Math.MAX(0.1*z,z)) dir 1 > 0 else 0
	 */
	public final int LReLU=5;
	/**
	 * (Z if Z>=0 else e^x-1) dir 1 > 0 else a+1
	 */
	public final int ELU=6;
	/**
	 * (E-O)+(E-O) "minus" dir(-1)
	 */
	public final int E=0;
	/**
	 * 0.5(E-O)^2+0.5(E-O)^2 "sqrd" dir(O-E)
	 */
	public final int SE=1;
	/**
	 *  |E-0|+|E-O| "abs" dir((O-E)/|(E-O)|
	 */
	public final int AE=2;
	/**
	 * -E*log(O)-E*log(O)) "cross" dir -E/xln(10)
	 */
	public final int MCF=3;
	
	
	private int CType=1;
	private int AType=2;
	
	public Layer(int nodes,int inputs, double randomSize, int activationType, int costType) {
		weights=new double[nodes][inputs];
		weightDIR=new double[nodes][inputs];
		weightADJ=new double[nodes][inputs];
		bias=new double[nodes];
		biasDIR=new double[nodes];
		biasADJ=new double[nodes];
		AType=activationType;
		CType=costType;
		Randomize(randomSize);
		
	}
	public void Randomize(double randomSize) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				weights[nodeN][weightN]=2*randomSize*Math.random()-randomSize;
				weightADJ[nodeN][weightN]=0;
			}
			bias[nodeN]=2*randomSize*Math.random()-randomSize;
			biasADJ[nodeN]=0;
		}
		
		
	}
	public void addRandomize(double randomSize) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				weights[nodeN][weightN]+=2*(weights[nodeN][weightN]+2*Math.random()-1)*randomSize*Math.random()-weights[nodeN][weightN]*randomSize;
				weightADJ[nodeN][weightN]=0;
			}
			bias[nodeN]+=2*(bias[nodeN]+2*Math.random()-1)*randomSize*Math.random()-bias[nodeN]*randomSize;
			biasADJ[nodeN]=0;
		}
		
		
	}
	public void setActivationDIRL(double[] lastVal,double[] EXPout) {
		double[] out = new double[lastVal.length];
		for(int i =0;i<lastVal.length;i++) {
			
			out[i]=CostDir(lastVal[i],EXPout[i]);
		}
		this.activationDIR=out;
		
	}
	public double CostDir(double O,double Ex) {
	switch(CType) {
	case E:return -1;
	case SE:return (O-Ex);
	case AE:return (O-Ex)/Math.abs(Ex-O);
	case MCF:return -Ex/(O*Math.log(10));
	}
	return 0;
	}
	public double ActiveDir(double A) {
		switch(AType) {
		case BS:return 0;
		case L:return 1.0;
		case SIG:return A*(1-A);
		case TANH:return 1.0-(A*A);
		case ReLU:return A>=0?0.5:0;
		case LReLU:return A>=0?1:0;
		case ELU:return A>=0?1:A+1;
		}
		return 0;
		}
	public double Active(double Z) {
		switch(AType) {
		case BS:return (Z/(2*Math.abs(Z)))+0.5;
		case L:return Z;
		case SIG:return (1.0/(1.0+Math.exp(-Z)));
		case TANH:double out =(2.0/(1.0+Math.exp(-2*Z)))-1.0;
		if(Double.isFinite(out)) {
			return out;
			
		}else{
			return(Z/Math.abs(Z));
		}
		case ReLU:return Math.max(0,Z);
		case LReLU:return  Math.max(0.1*Z,Z);
		case ELU:return (Z>=0)?Z:Math.exp(-Z);
		}
		return 0;
		}
	public void addADJ(double learnRate) {
		ider+=1.0;
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				

					weightADJ[nodeN][weightN]-=learnRate*weightDIR[nodeN][weightN];
				
				
			}
		
				biasADJ[nodeN]-=learnRate*biasDIR[nodeN];
			
			
			
		}
	}
	public void applyADJ() {
		if(ider!=0) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				weights[nodeN][weightN]+=weightADJ[nodeN][weightN]/(double)ider;
				weightADJ[nodeN][weightN]=0;
			}
			bias[nodeN]+=biasADJ[nodeN]/(double)ider;
			biasADJ[nodeN]=0;
		}
		}
		ider=0;
	}
	public void unapplyADJ() {
		if(ider!=0) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				weights[nodeN][weightN]-=weightADJ[nodeN][weightN]/(double)ider;
				weightADJ[nodeN][weightN]=0;
			}
			bias[nodeN]-=biasADJ[nodeN]/(double)ider;
			biasADJ[nodeN]=0;
		}
		}
		ider=0;
	}
	public void clearADJ() {
		if(ider!=0) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
			
				weightADJ[nodeN][weightN]=0;
			}
		
			biasADJ[nodeN]=0;
		}
		}
		ider=0;
	}
	public void applyADJT() {
		if(ider!=0) {
		for(int nodeN =0;nodeN<weights.length;nodeN++) {
			for(int weightN =0;weightN<weights[nodeN].length;weightN++) {
				weights[nodeN][weightN]+=weightADJ[nodeN][weightN]/(double)ider;
			
			}
			bias[nodeN]+=biasADJ[nodeN]/(double)ider;
		
		}
		}
		
	}
   public void setWBDir(double[] lastAvals,double[] A) {
		for(int nodeN=0;nodeN<weights.length;nodeN++) {
			for(int wN=0;wN<weights[nodeN].length;wN++) {
			
				weightDIR[nodeN][wN]=lastAvals[wN]*(ActiveDir(A[nodeN]))*activationDIR[nodeN];
				}
			
			 biasDIR[nodeN]=(ActiveDir(A[nodeN]))*activationDIR[nodeN];
		}
	 
	}
	public double[] getLayerValues(double[] inputs,int type) {

		switch(type) {
		case 0:return Sigmoid(MatrixAdd((MatrixMult(weights,inputs)),bias));
		case 1:return MatrixAdd((MatrixMult(weights,inputs)),bias);
		}
		return null;
		
	}
	public void setActivationDIR(Layer last,double[] nextADIR,double[] A){
		double[] out = new double[weights.length];
		for(int nodeN =0;nodeN<weights.length;nodeN++){
			out[nodeN]=0;
			for(int nodeNL =0;nodeNL<last.weights.length;nodeNL++) {
			out[nodeN]+=last.weights[nodeNL][nodeN]*(ActiveDir(A[nodeN]))*nextADIR[nodeNL];
			}
		}
	    this.activationDIR=out;
		
	}

	



	private double[] Sigmoid(double[] matrixAdd) {
		double[] out = new double[matrixAdd.length];
		for(int i =0;i<matrixAdd.length;i++) {
			
			out[i]=Active(matrixAdd[i]);;
		}
		return out;
	}


	private double[] MatrixAdd(double[] ds, double[] bias2) {
		double[] out = new double[ds.length];
		for(int i =0;i<ds.length;i++) {
			out[i]=ds[i]+bias2[i];
		}
		return out;
	}

	private double[] MatrixMult(double[][] weights2, double[] inputs) {
		double[] out = new double[weights2.length];
	for(int nodeN =0;nodeN<weights2.length;nodeN++) {
	out[nodeN]=MatrixDot(weights2[nodeN],inputs);
	}
		return out;
	}

	private double MatrixDot(double[] ds, double inputs[]) {
		double sum = 0;
		for(int WeightN =0; WeightN<ds.length; WeightN++) {
		
			sum+=ds[WeightN]*inputs[WeightN];
			
		}
			
		return sum;
	}
	public String toString() {
		String out ="";

	for(int nodeN =0;nodeN<weights.length;nodeN++){
	out+=("[ ");
		for(int wN=0;wN<weights[nodeN].length;wN++) {	
			out+=(weights[nodeN][wN]+" + ");
		}
		out+=" + "+bias[nodeN];
		out+=(" ]");
		}
		
		return out;
	}
	public String toString2() {
		String out ="";

		for(int nodeN =0;nodeN<weights.length;nodeN++){
			out+=("[ ");
			for(int wN=0;wN<weights[nodeN].length;wN++) {	
				out+=(weights[nodeN][wN]+" + ");
			}
			out+=" + "+bias[nodeN];
			out+=(" ]");
			}
			
			return out;
	}
	
}
