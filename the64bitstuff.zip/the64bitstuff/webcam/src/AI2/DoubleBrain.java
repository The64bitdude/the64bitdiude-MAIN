package AI2;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import customlists.MultiHashMap;


public class DoubleBrain {
	ReEnforcedAI B;
	UnsupervisedAI A;
	int size;
	public double maxVal;
	public double minVal;
 public DoubleBrain(int inputs,int outputs,int[] ALLLayers,int devideIndex,double maxVal,double minVal,int atype,int ctype,int setSize) {
	 this.maxVal=maxVal;
	 this.minVal=minVal;
 size = 0;
int[] allLayers2 = new int[ALLLayers.length + 2];
System.arraycopy(ALLLayers, 0, allLayers2, 1, ALLLayers.length);
allLayers2[0] = inputs;
allLayers2[ALLLayers.length] = outputs;
ALLLayers=allLayers2;

A=new UnsupervisedAI(Arrays.copyOfRange(ALLLayers, 0, devideIndex+1),setSize,maxVal,minVal,atype,ctype);
B=new ReEnforcedAI(Arrays.copyOfRange(ALLLayers, devideIndex+1,ALLLayers.length-1),setSize,atype,ctype,1,-1);
 }
 public double[] getOut(double[] input) {
double[] val=input;
	val=A.getOUT2(input, 0);
	val=B.getOUT2(val, 0);
	 return val;
 }
 public void RunAI(double[] input,double learnRate) {
	 double[] val = getOut(input);
		
 }
 
 public double[] normalize(double[] input) {
		double[] out = new double[input.length];
		for(int i =0;i<input.length;i++) {
			out[i]=((2.0*(input[i]-minVal))/(maxVal-minVal))-1.0;
		}
		return out;
	}
	public double scaleUp(double y) {
		
		return 0.5*(y+1)*(maxVal-minVal)+minVal;
	}
public double[] scaleUp(double[] y) {
		double[] out = new double[y.length];
		for(int i =0;i<out.length;i++) {
			out[i]=scaleUp(y[i]);
		}
		return out;
	}
 
}
