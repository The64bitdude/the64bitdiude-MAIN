package AI2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ReEnforcedAI extends Brain{
	 ArrayList<double[]> TrainDATOUT;
	 public ArrayList<double[]> TrainDATIN;
	
	public ReEnforcedAI(int[] nodes, int setSize, double maxVal, double minVal) {
		super(nodes,setSize,maxVal,minVal);
	
		TrainDATOUT = new ArrayList<double[]>();
		TrainDATIN = new ArrayList<double[]>();
	}
	public ReEnforcedAI(int[] nodes, int setSize, int atype, int ctype, double maxVal, double minVal) {
		super(nodes,setSize,atype,ctype,maxVal,minVal);
		
		TrainDATOUT = new ArrayList<double[]>();
		TrainDATIN = new ArrayList<double[]>();
	}
	
	
	public void RunAI(double[] input,double[] EXPout,double learnRate) {
		TrainDATOUT.add(EXPout);
		TrainDATIN.add(normalize(input));
		Train(input,EXPout, learnRate);
		int count = 0;
		for(int i =0;i<TrainDATOUT.size();i++) {
			Train(TrainDATIN.get(i),TrainDATOUT.get(i), learnRate);
			if(count >setSize&&setSize!=-1) {
				applyTrainedVals();
				count=0;
			}
			count++;
			}
		applyTrainedVals();
		
			
	}
	public double normalize(double in ,double max,double min) {
		return ((2.0*(in-min))/(max-min))-1.0;
}
	public double denormailize(double in, int max, int min) {
		// TODO Auto-generated method stub
	
		return 	(((in+1.0)*(max-min))/2.0)+min;
	}
	public double getAverageCost() {
	double sum = 0;
	for(int i =0;i<TrainDATIN.size();i++) {
		sum+=getCost2(TrainDATIN.get(i), TrainDATOUT.get(i));
	}
	sum/=TrainDATIN.size();
		return sum;
	}
	public void ExportSets(File file, boolean erase) throws IOException {
		FileWriter in = new FileWriter(file);
		if(erase) {
		in.write("");
		}
		for(int i =0;i<TrainDATOUT.size();i++) {
			for(double val:TrainDATOUT.get(i)) {
				in.append(val + " ");
			}
			in.append("\n");
			for(double val:TrainDATIN.get(i)) {
				in.append(val + " ");
			}
			in.append("\n");
		}
	}
	public void ImportSets(File file) throws IOException {
		Scanner in = new Scanner(file);
		TrainDATOUT = new ArrayList<double[]>();
		TrainDATIN = new ArrayList<double[]>();
		while(in.hasNextLine()){
		 String dataLine=in.nextLine();
		 int count=0;
		double[] out = new double[this.outputSize];
		 while(dataLine.contains(" ")) {
			out[count]=Double.parseDouble(dataLine.substring(0,dataLine.indexOf(" ")));
			 
			 dataLine=dataLine.substring(dataLine.indexOf(" ")+1);
			 count++;
		 }
		 TrainDATOUT.add(out);
		 dataLine=in.nextLine();
		out = new double[this.inputSize];
		count=0;
		 while(dataLine.contains(" ")) {
			out[count]=Double.parseDouble(dataLine.substring(0,dataLine.indexOf(" ")));
			 
			 dataLine=dataLine.substring(dataLine.indexOf(" ")+1);
			 count++;
		 }
		 TrainDATIN.add(out);
		 
		}
	}

}
