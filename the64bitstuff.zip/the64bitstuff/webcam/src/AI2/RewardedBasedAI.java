package AI2;

import java.util.ArrayList;
import java.util.Arrays;

public abstract class RewardedBasedAI{
	ReEnforcedAI action;
	int outN;
	int inN;
	public RewardedBasedAI(int inputs,int outputs,int[] nodes, int setSize) {
		outN=outputs;
		inN=inputs;
		int[] nodes2 = new int[nodes.length + 2];
		System.arraycopy(nodes, 0, nodes2, 1, nodes.length);
		nodes2[0] = inputs;
		nodes2[nodes.length+1] = outputs;
	
	action = new ReEnforcedAI(nodes2,setSize,3,1,1,-1);
	
		// TODO Auto-generated constructor stub
	}
	
	public double normalize(double in ,double max,double min) {
			return ((2.0*(in-min))/(max-min))-1.0;
	}
	public double[] getOut(double[] inputs) {
		return action.getOUT2(inputs, 0);
		
	}
	
	
	
	/**
	 * MUST NORMALIZE
	 * @param output
	 * @param inputs
	 * @param rew
	 * @param learnRate
	 */
	public void addAllStates(double[] inputs,double learnRate) {
		double maxreward=0;
		double[] maxout=null;
		for(int i =0;i<outN*outN;i++) {
		double[] out=new double[outN];
		char[] b=Integer.toBinaryString(i).toCharArray();
		for(int n=b.length-1;n>=0;n--) {
			out[out.length-b.length+n]=(((int)(b[n]))-48);
		}
		double rew = reward(out,inputs);
		if(rew>maxreward) {
			maxout=out;
			maxreward =rew;
		}
		}
		action.RunAI(inputs,maxout,learnRate);
		
	
	}	
	/**
	 * MUST NORMALIZE
	 * @param output
	 * @param inputs
	 * @param rew
	 * @param learnRate
	 */
	public void addSingularStates(double[] inputs,double learnRate) {
		double maxreward=0;
		double[] maxout=new double[outN];
		
		for(int i =0;i<outN;i++) {
		double[] out=new double[outN];
		out[i]=1;
		
		double rew = reward(out,inputs);
		if(rew>maxreward) {
			maxreward =rew;
			maxout=out;
			
		}else if(rew>=maxreward){
			maxreward =rew;
			maxout[i]=1;
		}
		}
		
		
		action.RunAI(inputs,maxout,learnRate);
		
	
	}
	/**
	 * how changing these states will affect the reward NORMALIZE 
	 * @param in 
	 * @param output
	 * @param inputs
	 * @param rew
	 * @param learnRate
	 */
	public abstract double reward(double[] out, double[] in);

	public double denormailize(double in, int max, int min) {
		// TODO Auto-generated method stub
	
		return 	(((in+1.0)*(max-min))/2.0)+min;
	}
	

	

}
