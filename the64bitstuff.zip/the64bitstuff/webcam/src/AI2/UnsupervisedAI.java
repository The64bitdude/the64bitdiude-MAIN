package AI2;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Comparator;

public class UnsupervisedAI extends ReEnforcedAI{
  public double[][] CM;
  public ArrayList<Integer>[] CT;

	public UnsupervisedAI(int[] nodes, int setSize) {
		super(nodes, setSize,1.0,0.0);
		CM=new double[outputSize][inputSize];
		CT=new ArrayList[outputSize];
		for(int i=0;i<outputSize;i++) {
			CT[i]=new ArrayList<Integer>();
		}
		ResetClusters();
	}
	public UnsupervisedAI(int[] nodes, int setSize,double maxVal,double minVal) {
		super(nodes, setSize,maxVal,minVal);
		CM=new double[outputSize][inputSize];
		CT=new ArrayList[outputSize];
		for(int i=0;i<outputSize;i++) {
			CT[i]=new ArrayList<Integer>();
		}
		ResetClusters();
	}
	public UnsupervisedAI(int[] nodes, int setSize,double maxVal,double minVal,int Atype,int Ctype) {
		super(nodes, setSize,Atype,Ctype,maxVal,minVal);
		CM=new double[outputSize][inputSize];
		CT=new ArrayList[outputSize];
		for(int i=0;i<outputSize;i++) {
			CT[i]=new ArrayList<Integer>();
		}
	
		ResetClusters();
	}
	public void ResetClusters() {
	
		for(int I=0;I<inputSize;I++) {
			
			
		
			
			for(int i = 0;i<outputSize;i++) {
			CM[i][I]=Math.random()*(2)-1;
			}
		}
		
		
	}
	public void ResetInputs() {
		TrainDATIN.clear();
	}
public void RemoveInput() {
	TrainDATIN.remove(TrainDATIN.size()-1);
	}
	public void IdorateClusters() {
		
		
		TrainDATOUT.clear();
		for(int i=0;i<CT.length;i++) {
			CT[i].clear();
		}
		for(int i =0;i<TrainDATIN.size();i++) {
			double[] Dists = new double[CM.length];
			for(int I=0;I<CM.length;I++) {
				Dists[I]=dist(TrainDATIN.get(i),CM[I]);
				//System.out.println(Dists[I]==0?I:Dists[I]);
			}
		
			//System.out.println(TrainDATIN.get(i)[0]+ " , "+TrainDATIN.get(i)[1]);
		
			int MIN = MINI(Dists);
			CT[MIN].add(i);
			Dists=new double[CM.length];
			for(int I=0;I<CM.length;I++) {
				Dists[I]=0;
				
			}
			Dists[MIN]=1;
			TrainDATOUT.add(Dists);
			
			
		}
		for(int N=0;N<CT.length;N++) {
		
			for(int V=0;V<inputSize;V++) {
				double sum =0;
				if(CT[N].size() >0) {
				for(int D=0;D<CT[N].size();D++) {
				
					sum+=TrainDATIN.get(CT[N].get(D))[V];
					
					
				}
			
				CM[N][V]=sum/(double)(CT[N].size());
				}
				
			}
			
		}
	}
	public double dist(double[] A, double[] B) {
		double sum = 0;
		for(int i =0;i<A.length;i++) {
			sum+= Math.pow(A[i]-B[i],2);
		}
		
		sum=Math.pow(sum, 1.0/2.0);
		return sum;
		
	}
	
	private double MAX(double[] in) {
		int out = 0;
		for(int i = 0;i<in.length;i++) {
			if(in[i]>in[out]) {
				out=i;
			}
		}
		return in[out];
	}
	private double MIN(double[] in) {
		int out = 0;
		for(int i = 0;i<in.length;i++) {
			if(in[i]<in[out]) {
				out=i;
			}
		}
		return in[out];
	}
	private int MAXI(double[] in) {
		int out = 0;
		for(int i = 0;i<in.length;i++) {
			if(in[i]>in[out]) {
				out=i;
			}
		}
		return out;
	}
	private int MINI(double[] in) {
		int out = 0;
		for(int i = 0;i<in.length;i++) {
			if(in[i]<in[out]) {
				out=i;
			}
		}
		return out;
	}
	
	public void RunAI(double learnRate) {

	

		int count = 0;
		
			for(int i =0;i<TrainDATIN.size();i++) {
			Train(TrainDATIN.get(i),TrainDATOUT.get(i), learnRate);
			if(count >setSize&&setSize>0) {
				applyTrainedVals();
				count=0;
			}
			count++;
			}
			
				applyTrainedVals();
				
			
		
	
	}
	public void RunAIT(double learnRate) {

		

		int count = 0;
		
			for(int i =0;i<TrainDATIN.size();i++) {
			Train(TrainDATIN.get(i),TrainDATOUT.get(i), learnRate);
			if(count >setSize&&setSize>0) {
				applyTrainedVals();
				count=0;
			}
			count++;
			}
			
				applyTrainedValsT();
				
			
		
	
	}
	public void RunAI(double[] input,double learnRate,int idorations) {

		
		TrainDATIN.add(normalize(input));
		for(int i =0;i<idorations;i++) {
		IdorateClusters();
		}
		int count = 0;
	
	for(int i =0;i<TrainDATIN.size();i++) {
			Train(TrainDATIN.get(i),TrainDATOUT.get(i), learnRate);
			if((count >setSize)&&setSize>0) {
				applyTrainedVals();
				count=0;
			}
			count++;
			}
			
				applyTrainedVals();
				
			
		
	
	}
		
	public void addData(double[] input,int idorations) {
	

			TrainDATIN.add(normalize(input));
			for(int i =0;i<idorations;i++) {
			IdorateClusters();
			}
			
		
		
	}
	public double scaleUp(double y) {
		
		return 0.5*(y+1)*(maxVal-minVal)+minVal;
	}
	
	
	
	

}
