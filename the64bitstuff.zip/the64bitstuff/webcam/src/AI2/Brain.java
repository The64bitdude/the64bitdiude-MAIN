package AI2;



import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Brain {
	public Layer[] layers;
	protected int setSize;
	public int inputSize;
	public int outputSize;
	public double maxVal;
	public double minVal;
	/**
	 * Use this by first add at least one iteration using additeration(inputs,Expected outputs) and 
	 * then to apply what you trained use applyTrainedVals()
	 * or you can use Train to train one input and output a amount of times
	 * @param minVal 
	 * @param maxVal 
	 * @see #additeration(double[], double[])
	 * @see #applyTrainedVals()
	 * @see #Train(double[], double[], int)
	**/
	public Brain(int[] nodes,int setSize, double maxVal, double minVal) {
		this.setSize=setSize;
		inputSize=nodes[0];
		outputSize=nodes[nodes.length-1];
		layers=new Layer[nodes.length-1];
		for(int i =1;i<nodes.length;i++) {
			layers[i-1]=new Layer(nodes[i],nodes[i-1],1,2,1);
			
		}
		this.maxVal=maxVal;
		this.minVal=minVal;
	}
	
	/**
	 * (Z/2|Z|  +  0.5)  dir 0 
	 */
	public static final int A_BS=0;
	/**
	 *  (Z) dir 1
	 */
	public static final int A_L=1;
	/**
	 *  (1/1+e^-z)   dir(a(1-a))
	 */
	public static final int A_SIG= 2;
	/**
	 *  ((e^z-e^-z)/(e^z+e^-z))  dir -(a^2)+1
	 */
	public static final int A_TANH=  3;
	/**
	 *  (Math.MAX(0,z)) dir 0.5 > 0 else 0
	 */
	public static final int A_ReLU=4;
	/**
	 *  (Math.MAX(0.1*z,z)) dir 1 > 0 else 0
	 */
	public static final int A_LReLU=5;
	/**
	 * (Z if Z>=0 else e^x-1) dir 1 > 0 else a+1
	 */
	public static final int A_ELU=6;
	/**
	 * (E-O)+(E-O) "minus" dir(-1)
	 */
	public static final int C_E=0;
	/**
	 * 0.5(E-O)^2+0.5(E-O)^2 "sqrd" dir(O-E)
	 */
	public static final int C_SE=1;
	/**
	 *  |E-0|+|E-O| "abs" dir((O-E)/|(E-O)|
	 */
	public static final int C_AE=2;
	/**
	 * -E*log(O)-E*log(O)) "cross" dir -E/xln(10)
	 */
	public static final int C_MCF=3;

	private int CType=1;
	private int AType=2;
	
	/**
	 * Use this by first add at least one iteration using additeration(inputs,Expected outputs) and 
	 * then to apply what you trained use applyTrainedVals()
	 * or you can use Train to train one input and output a amount of times
	 * @param minVal2 
	 * @param maxVal2 
	 * @see #additeration(double[], double[])
	 * @see #applyTrainedVals()
	 * @see #Train(double[], double[], int)
	 * @apiNote
	 * <p></p><b>ActivationTYPES</b>
	 *<ul><li><b><code>BS</code></b> == <b>0</b> (Z/|Z|  +  1)  dir 0 
     * <li><b><code>L</code></b> == <b>1</b>    (Z) dir 1
     * <li><b><code>SIG</code></b> == <b>2</b>   (1/1+e^-z)   dir(a(1-a))
     * <li><b><code>TANH</code></b> ==  <b>3</b>  ((e^z-e^-z)/(e^z+e^-z))  dir -(a^2)+1
     * <li><b><code>ReLU</code></b> == <b>4</b> (Math.MAX(0,z)) dir 0.5 > 0 else 0
     * <li><b><code>LReLU</code></b> ==<b>5</b>  (Math.MAX(0.1*z,z)) dir 1 > 0 else 0
     * <li><b><code>PReLU</code></b> == <b>6</b> (Math.MAX(a*z,z)) dir a > 0 else 0
     * <li><b><code>ELU</code></b> == <b>7</b>  (Z if Z>=0 else e^x-1) dir 1 > 0 else a+1
     * </ul>
	 * <p></p><b>costTYPES</b>
	 *<ul><li><b><code>E</code></b> == <b>0</b> (E-O)+(E-O) "minus"
     * <li><b><code>SE</code></b> == <b>1</b>   (E-O)^2+(E-O)^2 "sqrd"
     * <li><b><code>AE</code></b> == <b>2</b>   |E-0|+|E-O| "abs"
     * <li><b><code>MCF</code></b> == <b>3</b> -(E*log(O)+E*log(O)) "cross"
   * </ul>
	**/
	public Brain(int[] nodes,int setSize,int activationType,int costType, double maxVal, double minVal) {
		this.setSize=setSize;
		inputSize=nodes[0];
		AType=activationType;
		CType=costType;
		outputSize=nodes[nodes.length-1];
		layers=new Layer[nodes.length-1];
		for(int i =1;i<nodes.length;i++) {
			layers[i-1]=new Layer(nodes[i],nodes[i-1],1,activationType,costType);
			
		}
		this.maxVal=maxVal;
		this.minVal=minVal;
	}
	public Brain(int[] nodes,int atype,int ctype) {
		AType=atype;
		CType=ctype;
		this.setSize=0;
		layers=new Layer[nodes.length-1];
		for(int i =1;i<nodes.length;i++) {
			layers[i-1]=new Layer(nodes[i],nodes[i-1],1,atype,ctype);
			
	}
		this.maxVal=1.0;
		this.minVal=0;
	}
	public Brain(int[] nodes) {
		this.setSize=0;
		layers=new Layer[nodes.length-1];
		for(int i =1;i<nodes.length;i++) {
			layers[i-1]=new Layer(nodes[i],nodes[i-1],1,A_TANH,C_SE);
			
	}
		this.maxVal=1.0;
		this.minVal=0;
	}
	public double[] normalize(double[] input) {
		double[] out = new double[input.length];
		for(int i =0;i<input.length;i++) {
			out[i]=((2.0*(input[i]-minVal))/(maxVal-minVal))-1.0;
		}
		return out;
	}
	public double scaleUp(double y) {
		
		return 0.5*(y+1)*(maxVal-minVal)+minVal;
	}
public double[] scaleUp(double[] y) {
		double[] out = new double[y.length];
		for(int i =0;i<out.length;i++) {
			out[i]=scaleUp(y[i]);
		}
		return out;
	}
	public void Train(double[] inputs,double[] EXPouts,double learnRate) {
	
			ArrayList<double[]> LV=getAllLayerOut(inputs,0);
	     	ArrayList<double[]> LVA=getAllLayerOut(inputs,1);
		


			/*for(int i =0;i<cost2.length;i++) {
				//System.out.println(cost2[i]);
			}*/
				layers[layers.length-1].setActivationDIRL(LV.get(LV.size()-1),EXPouts);
				layers[layers.length-1].setWBDir(LV.get(LV.size()-2), LV.get(LVA.size()-1));
				layers[layers.length-1].addADJ(learnRate);
				for(int i =layers.length-2;i>=1;i--) {
				layers[i].setActivationDIR(layers[i+1], layers[i+1].activationDIR, LV.get(i));
				layers[i].setWBDir(LV.get(i-1), LV.get(i));
				layers[i].addADJ(learnRate);
			 }
				layers[0].setActivationDIR(layers[1], layers[1].activationDIR, LV.get(0));
				layers[0].setWBDir(inputs, LV.get(0));
				layers[0].addADJ(learnRate);
			
				
	}
	
	public void applyTrainedVals() {
		for(int i =0;i<layers.length;i++) {
			/*for(int k=0;k<layers[i].weightADJ.length;k++) {
				for(int l=0;l<layers[i].weightADJ[k].length;l++) {
				System.out.println("?"+layers[i].weightADJ[k][l]);
				System.out.println(layers[i].weightDIR[k][l]);
				System.out.println(1.0/layers[i].weightDIR[k][l]);
					}
				}*/
			layers[i].applyADJ();
			
		}
	}
	public void applyTrainedValsT() {
		for(int i =0;i<layers.length;i++) {
			/*for(int k=0;k<layers[i].weightADJ.length;k++) {
				for(int l=0;l<layers[i].weightADJ[k].length;l++) {
				System.out.println("?"+layers[i].weightADJ[k][l]);
				System.out.println(layers[i].weightDIR[k][l]);
				System.out.println(1.0/layers[i].weightDIR[k][l]);
					}
				}*/
			layers[i].applyADJT();
			
		}
	}
	public void unapplyTrainedVals() {
		for(int i =0;i<layers.length;i++) {
			/*for(int k=0;k<layers[i].weightADJ.length;k++) {
				for(int l=0;l<layers[i].weightADJ[k].length;l++) {
				System.out.println("?"+layers[i].weightADJ[k][l]);
				System.out.println(layers[i].weightDIR[k][l]);
				System.out.println(1.0/layers[i].weightDIR[k][l]);
					}
				}*/
			layers[i].unapplyADJ();
			
		}
	}
	public void clearTrainedVals() {
		for(int i =0;i<layers.length;i++) {
			/*for(int k=0;k<layers[i].weightADJ.length;k++) {
				for(int l=0;l<layers[i].weightADJ[k].length;l++) {
				System.out.println("?"+layers[i].weightADJ[k][l]);
				System.out.println(layers[i].weightDIR[k][l]);
				System.out.println(1.0/layers[i].weightDIR[k][l]);
					}
				}*/
			layers[i].clearADJ();
			
		}
	}
	public ArrayList<double[]> getAllLayerOut(double[] input,int type) {
		ArrayList<double[]> out =new ArrayList<double[]>();
		double[] values = input;
		for(int i =0;i<layers.length;i++) {
			double[] outp=layers[i].getLayerValues(values, type);
			values=(type==0)?outp:layers[i].getLayerValues(values, 0);
			out.add(outp);
		}
		return out;
	}

public double[] getOUT2(double[] input,int type) {
	ArrayList<double[]> out=getAllLayerOut(normalize(input),type);
		return out.get(out.size()-1);
		}
public double[] getOUT(double[] input,int type) {
	ArrayList<double[]> out=getAllLayerOut(input,type);
		return out.get(out.size()-1);
		}
public double[] getScaledOUT(double[] input,int type) {
	ArrayList<double[]> out=getAllLayerOut(normalize(input),type);
		return scaleUp(out.get(out.size()-1));
		}
	
	
	public double getCost2(double[] lastVals,double[] EXPout) {

		double sum = 0;
		for(int i =0;i<lastVals.length;i++) {
			sum+=Cost(EXPout[i],lastVals[i]);
		}
		sum/=lastVals.length;
		return sum;
	}
	public double Cost(double E,double O) {
		switch(CType) {
		case C_E:return (E-O);
		case C_SE:return 0.5*Math.pow((E-O),2);
		case C_AE:return Math.abs(E-O);
		case C_MCF:return (O-E)*Math.log10(O);
		}
		return 0;
		}
	
	public double[] getCost3(double[] lastVals,double[] EXPout) {
double[] out = new double[EXPout.length];
		
		for(int i =0;i<lastVals.length;i++) {
			out[i]=Cost(EXPout[i],lastVals[i]);
		}
		return out;
	}
	public void Export(File file) throws IOException {
		FileWriter in = new FileWriter(file);
		in.write("");
		for(Layer l:layers) {
			for(int n=0;n<l.weights.length;n++) {
				in.append("[");
				for(double w:l.weights[n]) {
				in.append(w+" ");
				}
				in.append(l.bias[n]+"]");
			}
			in.append("\n");
		}
		in.close();
	}
	public void Import(File file) throws IOException {
		Scanner in = new Scanner(file);
		int countL=0;
		while(in.hasNextLine()) {
			String dat = in.nextLine();
		//	System.out.println(dat +" e");
			int countN=0;
			while(dat.contains("]")) {
				String part = dat.substring(0,dat.indexOf("]"));
				Scanner lin = new Scanner(part);
				//System.out.println(part);
				int countW=0;
				while(part.contains(" ")) {
				String val = part.substring(0,part.indexOf(" "));
	if(val.contains("[")) {
		val=val.substring(val.indexOf("[")+1);
	}
				//System.out.println(val);
					if(layers[countL].weights[countN].length>countW) {

			layers[countL].weights[countN][countW]=Double.parseDouble(val);
					}else {
						layers[countL].bias[countN]=Double.parseDouble(val);
					}
				countW++;
				part=part.substring(part.indexOf(" ")+1);

				}
				
				countN++;
				dat=dat.substring(dat.indexOf("]")+1);
			}
			countL++;
		}
		in.close();
	}
	public String toString(double[] input) {
		String out = "";
		for(double val:input) {
			out+=val+" , ";
			}
		out+="\n";
		ArrayList<double[]>vals =getAllLayerOut(input,1);
		int count =0;
		for(Layer L:layers) {
			out+=L.toString()+"\n";
			for(double val:vals.get(count)) {
			out+=val+" , ";
			}
			out+="\n\n";
			count++;
		}
		return out;
		
	}
public void addRandomize(double randomSize) {
	for(int i =0;i<layers.length;i++) {
		/*for(int k=0;k<layers[i].weightADJ.length;k++) {
			for(int l=0;l<layers[i].weightADJ[k].length;l++) {
			System.out.println("?"+layers[i].weightADJ[k][l]);
			System.out.println(layers[i].weightDIR[k][l]);
			System.out.println(1.0/layers[i].weightDIR[k][l]);
				}
			}*/
		layers[i].addRandomize(randomSize);
		
	}
		
	}
	public void Randomize(double randomSize) {
		for(int i =0;i<layers.length;i++) {
			/*for(int k=0;k<layers[i].weightADJ.length;k++) {
				for(int l=0;l<layers[i].weightADJ[k].length;l++) {
				System.out.println("?"+layers[i].weightADJ[k][l]);
				System.out.println(layers[i].weightDIR[k][l]);
				System.out.println(1.0/layers[i].weightDIR[k][l]);
					}
				}*/
			layers[i].Randomize(randomSize);
			
		}
	}
	
	
}
