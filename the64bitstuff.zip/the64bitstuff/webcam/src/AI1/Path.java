package AI1;

import java.awt.Point;
import java.util.ArrayList;

public class Path {
	public ArrayList<Point> path;
	public Path(ArrayList<Point> path) {
		this.path=path;
	}
	public String toString()
	{
		String out = "";
		for(Point p:path) {
			out+=" "+p.toString();
		}
		return out;
		
	}
}
