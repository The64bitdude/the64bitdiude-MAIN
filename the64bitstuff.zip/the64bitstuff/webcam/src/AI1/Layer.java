package AI1;

public class Layer {
	Node[] nodes;
	public Layer(int numNodes) {
		nodes = new Node[numNodes];
		
	}
	public double[] getVals() {
		double[]out=new double[nodes.length];
		for(int i =0;i<nodes.length;i++) {
			out[i]=nodes[i].val;
		}
		return out;
	}
	public void setVals(double[] vals) {
		for(int i =0;i<nodes.length;i++) {
			try {
			nodes[i].val=vals[i];
			}catch(Exception e) {
			nodes[i]=new Node(0);
				nodes[i].val=vals[i];
			}
		}
	}


}
