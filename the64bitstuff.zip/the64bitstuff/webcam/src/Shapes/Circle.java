package Shapes;

import java.awt.Polygon;
import java.util.Random;

public class Circle extends Polygon{
	
		public Circle(int x,int y,int radius,int verticies) {
			super();
			for(double a = 0;a<=360;a+=360.0/verticies) {
				addPoint((int) (radius*Math.cos(Math.toRadians(a))),(int) (radius*Math.sin(Math.toRadians(a))));
			}
		
		}
}
