package DataServer;

public class SBD {

	public int sign;
	private int[] data;
	public SBD(int sign,int[] data) {
		this.sign = sign;
		this.data = data;
	}
	public int[] getData() {
		int[] out = new int[data.length+1];
		out[0]=sign;
		int count = 1;
		for(int b :data) {
			out[count] = b;
			count++;
		}
		return out;
		
	}

}
