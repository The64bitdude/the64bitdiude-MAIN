package DataServer;

import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import Screens.Refresh;

public abstract class DataServer extends DataSystem {
	int failCount = 0;
	ServerSocket MOM;
	ArrayList<Socket> CNTS;
	public DataServer(int port) {
		super(port);
		
	}
	public DataServer(int fps,int port) {
		super(fps,port);
	}

	@Override
	public void update() {
		itorate();
		try {
			Socket joiner = MOM.accept();
			joiner.setSoTimeout(10);
			CNTS.add(joiner);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
		if(CNTS.size()!=0) {
			for(Socket s:CNTS) {
				try {
					input(new ObjectInputStream(s.getInputStream()));
				} catch (IOException e) {
					// TODO Auto-generated catch block
			
				}
				try {
					Output(new ObjectOutputStream(s.getOutputStream()));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					
				}
			}
		}
		
	}




	@Override
	public void initialize() {
		try {
			MOM = new ServerSocket(port);
			MOM.setSoTimeout(10);
			CNTS = new ArrayList<Socket>();
			define();
		} catch (Exception e) {
			if(failCount <10) {
			failCount++;
			initialize();
			}else {
				System.exit(0);
			}
			e.printStackTrace();
		}
		
	}
	

}
