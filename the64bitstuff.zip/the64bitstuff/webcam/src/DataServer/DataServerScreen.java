package DataServer;

import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public abstract class DataServerScreen extends DataSystemScreen {
	int failCount = 0;
	ServerSocket MOM;
	ArrayList<Socket> CNTS;
	public DataServerScreen(int sw,int sh,Color c,int fps,int port) {
		super(sw, sh, c, fps,port);

	}
	
	public DataServerScreen(int sw,int sh,Color c,int fps,int type,int port) {
		super(sw, sh, c, fps, type,port);

	}

	@Override
	public void update() {
		itorate();
		try {
			Socket joiner = MOM.accept();
			joiner.setSoTimeout(10);
			CNTS.add(joiner);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
		}
		if(CNTS.size()!=0) {
			for(Socket s:CNTS) {
				try {
					input(new ObjectInputStream(s.getInputStream()));
				} catch (IOException e) {
					// TODO Auto-generated catch block
			
				}
				try {
					Output(new ObjectOutputStream(s.getOutputStream()));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					
				}
			}
		}
		
	}




	@Override
	public void initialize() {
		try {
			MOM = new ServerSocket(port);
			MOM.setSoTimeout(10);
			CNTS = new ArrayList<Socket>();
			define();
		} catch (IOException e) {
			if(failCount <10) {
			failCount++;
			initialize();
			}else {
				System.exit(0);
			}
			e.printStackTrace();
		}
		
	}
	

}
