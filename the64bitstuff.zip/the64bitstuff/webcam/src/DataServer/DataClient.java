package DataServer;

import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import Screens.Refresh;

public abstract class DataClient extends DataSystem {
	int failCount = 0;
	Socket CNTS;
	private InetAddress ip;
	
	public DataClient(InetAddress ip,int port) {
		super(port);
		this.ip = ip;
	}
	public DataClient(int fps,int port,InetAddress ip) {
		super(fps,port);
		this.ip = ip;
	}

	@Override
	public void update() {
		itorate();

		try {
			input(new ObjectInputStream(CNTS.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
	
		}
		try {
			Output(new ObjectOutputStream(CNTS.getOutputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
		}
			
		
	}


	

	
	@Override
	public void initialize() {
		try {
			CNTS = new Socket(ip,port);
			CNTS.setSoTimeout(10);
			define();
		} catch (IOException e) {
			if(failCount <10) {
			failCount++;
			initialize();
			}else {
				System.exit(0);
			}
			e.printStackTrace();
		}
		
	}
	

}
