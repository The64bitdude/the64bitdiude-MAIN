package DataServer;

import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

public abstract class DataClientScreen extends DataSystemScreen {
	int failCount = 0;
	Socket CNTS;
	private InetAddress ip;
	public DataClientScreen(int sw,int sh,Color c,int fps,int port,InetAddress ip) {
		super(sw, sh, c, fps,port);
		this.ip = ip;
	}
	
	public DataClientScreen(int sw,int sh,Color c,int fps,int type,int port,InetAddress ip) {
		super(sw, sh, c, fps, type,port);
		this.ip = ip;
	}
	
	@Override
	public void update() {
		itorate();

		try {
			input(new ObjectInputStream(CNTS.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
	
		}
		try {
			Output(new ObjectOutputStream(CNTS.getOutputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
		}
			
		
	}


	

	
	@Override
	public void initialize() {
		try {
			CNTS = new Socket(ip,port);
			CNTS.setSoTimeout(10);
			define();
		} catch (Exception e) {
			if(failCount <10) {
			failCount++;
			initialize();
			}else {
				System.exit(0);
			}
			e.printStackTrace();
		}
		
	}
	

}

