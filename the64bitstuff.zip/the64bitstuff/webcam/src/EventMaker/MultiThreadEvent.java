package EventMaker;

import java.util.ArrayList;

public abstract class MultiThreadEvent<a> implements Runnable{
	public ArrayList<a> data = new ArrayList<a>();
	@Override
	public abstract void run();
}
