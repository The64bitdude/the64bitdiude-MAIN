/**
 * 
 */
/**
 * @author Acer
 *
 */
module the64bitdudetempliabrary {
	requires java.desktop;
}