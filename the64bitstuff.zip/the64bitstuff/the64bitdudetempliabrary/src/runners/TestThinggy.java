package runners;

public class TestThinggy {

	public static void main(String[] args) {
		for(int i=0;i<64;i++) {
			for(int j=0;j<64;j++) {
				try {
				System.out.println(Integer.toBinaryString(i) + " / "+Integer.toBinaryString(j)+" = "+Integer.toBinaryString(i/j)+" r "+Integer.toBinaryString(i%j));
				}catch(Exception e) {
				System.out.println(Integer.toBinaryString(i) + " / "+Integer.toBinaryString(j)+" = "+(double)i/j+" r "+(double)i%j);	
				}
			}
		}

	}

}
