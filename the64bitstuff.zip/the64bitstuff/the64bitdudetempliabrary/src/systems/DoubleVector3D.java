package systems;

public class DoubleVector3D {
	public double i;
	public double j;
	public double k;
	public DoubleVector3D(double x,double y,double z) {
		i=x;
		j=y;
		k=z;

	}
  
	public double dot(double x,double y,double z) {
		return i*x+j*y+k*z;
	}
	public double dot(DoubleVector3D v) {
		return dot(v.i,v.j,v.k); 
	}
	public DoubleVector3D cross(double x,double y,double z) {
		return new DoubleVector3D(j*z-y*k, x*k-i*z, i*y-x*j);
	}
	public DoubleVector3D cross(DoubleVector3D v) {
		return cross(v.i,v.j,v.k);
	}
	public DoubleVector3D reflect(double x,double y,double z) {
		return reflect(new DoubleVector3D(x,y,z));
	}
	public DoubleVector3D reflect(DoubleVector3D v) {
		return sub(v.normalize().mul(2).mul(dot(v.normalize())));
	}
	public DoubleVector3D add(double x,double y,double z) {
		return new DoubleVector3D(i+x,j+y, k+z);
	}
	public DoubleVector3D sub(double x,double y,double z) {
		return new DoubleVector3D(i-x,j-y, k-z);
	}
	public DoubleVector3D mul(double x,double y,double z) {
		return new DoubleVector3D(i*x,j*y, k*z);
	}
	public DoubleVector3D	div(double x,double y,double z) {
		return new DoubleVector3D(i/x,j/y, k/z);
	}
	public DoubleVector3D	add(double m) {
		return add(m,m,m);
	}
	public DoubleVector3D	sub(double m) {
		return sub(m,m,m);
	}
	public DoubleVector3D	mul(double m) {
		return mul(m,m,m);
	}
	public DoubleVector3D	div(double m) {
		return div(m,m,m);
	}
	public DoubleVector3D add(DoubleVector3D v) {
		return add(v.i,v.j,v.k);
	}
	public DoubleVector3D sub(DoubleVector3D v) {
		return sub(v.i,v.j,v.k);
	}
	public DoubleVector3D mul(DoubleVector3D v) {
		return mul(v.i,v.j,v.k);
	}
	public DoubleVector3D	div(DoubleVector3D v) {
		return div(v.i,v.j,v.k);
	}
	public DoubleVector3D normalize() {
		return div(mag());
	}
	public DoubleVector3D normalize(double maxVal) {
		return normalize().mul(maxVal);
	}
	public DoubleVector3D max(double x,double y,double z) {
		return new DoubleVector3D(Math.max(x, i),Math.max(y, j),Math.max(z, k));
	}
	public DoubleVector3D max(DoubleVector3D v) {
		return max(v.i,v.j,v.k);
	}
	public DoubleVector3D max(double m) {
		return max(m,m,m);
	}
	public DoubleVector3D  min(double x,double y,double z) {
		return new DoubleVector3D(Math.min(x, i),Math.min(y, j),Math.min(z, k));
	}
	public DoubleVector3D min(DoubleVector3D v) {
		return min(v.i,v.j,v.k);
	}
	public DoubleVector3D min(double m) {
		return min(m,m,m);
	}
	public DoubleVector3D  abs() {
		return new DoubleVector3D(Math.abs(i),Math.abs(j),Math.abs(k));
	}
	
	public void crossThis(double x,double y,double z) {
	set(j*z-y*k, x*k-i*z, i*y-x*j);
	}
	public void crossThis(DoubleVector3D v) {
		crossThis(v.i,v.j,v.k);
	}
	public void reflectThis(double x,double y,double z) {
		reflectThis(new DoubleVector3D(x,y,z));
	}
	public void reflectThis(DoubleVector3D v) {
		subThis(v.normalize().mul(2).mul(dot(v.normalize())));
	}
	public void addThis(double x,double y,double z) {
		set(i+x,j+y, k+z);
	}
	public void subThis(double x,double y,double z) {
		set(i-x,j-y, k-z);
	}
	public void mulThis(double x,double y,double z) {
		set(i*x,j*y, k*z);
	}
	public void	divThis(double x,double y,double z) {
		set(i/x,j/y, k/z);
	}
	public void	addThis(double m) {
		addThis(m,m,m);
	}
	public void	subThis(double m) {
		subThis(m,m,m);
	}
	public void	mulThis(double m) {
		mulThis(m,m,m);
	}
	public void	divThis(double m) {
		divThis(m,m,m);
	}
	public void addThis(DoubleVector3D v) {
		addThis(v.i,v.j,v.k);
	}
	public void subThis(DoubleVector3D v) {
		subThis(v.i,v.j,v.k);
	}
	public void mulThis(DoubleVector3D v) {
		mulThis(v.i,v.j,v.k);
	}
	public void	divThis(DoubleVector3D v) {
		divThis(v.i,v.j,v.k);
	}
	public void normalizeThis() {
		divThis(mag());
	}
	public void normalizeThis(double maxVal) {
		normalizeThis();
		mulThis(maxVal);
	}
	public void maxThis(double x,double y,double z) {
		i=Math.max(x, i);
		j=Math.max(y, j);
		k=Math.max(z, k);
	}
	public void maxThis(DoubleVector3D v) {
		maxThis(v.i,v.j,v.k);
	}
	public void maxThis(double m) {
		maxThis(m,m,m);
	}
	public void minThis(double x,double y,double z) {
		i=Math.min(x, i);
		j=Math.min(y, j);
		k=Math.min(z, k);
	}
	public void minThis(DoubleVector3D v) {
		minThis(v.i,v.j,v.k);
	}
	public void minThis(double m) {
		minThis(m,m,m);
	}
	public void  absThis() {
	i=Math.abs(i);
	j=Math.abs(j);
	k=Math.abs(k);
	}
	public double mag() {
		return Math.sqrt(magSqrd() );
	}
	public double mag3d2() {
		return Math.pow(magSqrd(),3/2f );
	}
	public double magSqrd() {
		return dot(this);
	}
	public double magCubed() {
		return dot(this.mul(this));
	}
	public String toString() {
		return "[ "+i+"i + "+j+"j + "+ k+"k ]";
	}
	public boolean equals(DoubleVector3D v) {
		// TODO Auto-generated method stub
		return equals(v.i,v.j,v.k);
	}
	public boolean equals(double x,double y,double z) {
		// TODO Auto-generated method stub
		return i==x&&j==y&&k==z;
	}
	public boolean iequals(DoubleVector3D v) {
		// TODO Auto-generated method stub
		return equals(v)||equals(-v.i,-v.j,-v.k);
	}

	public void set(double x, double y, double z) {
		this.i=x;
		this.j=y;
		this.k=z;
		
	}
	

	public double dist(DoubleVector3D midPoint) {
		// TODO Auto-generated method stub
		return sub(midPoint).mag();
	}

	public DoubleVector3D inv() {
		// TODO Auto-generated method stub
		return mul(-1,-1,-1);
	}

	public double mag(double f) {
		return Math.pow(magSqrd(),f );
	}

	public void set(DoubleVector3D v) {
	set(v.i,v.j,v.k);
		
	}

	public DoubleVector3D matrixMul(double[][] fs) {
	
		return new DoubleVector3D(i*fs[0][0]+j*fs[0][1]+k*fs[0][2]
		,i*fs[1][0]+j*fs[1][1]+k*fs[1][2],
		i*fs[2][0]+j*fs[2][1]+k*fs[2][2]);
	
	
	}
	public DoubleVector3D matrixMulThis(double[][] fs) {
		
		double i2=i*fs[0][0]+j*fs[0][1]+k*fs[0][2];
		double j2=i*fs[1][0]+j*fs[1][1]+k*fs[1][2];
		k=i*fs[2][0]+j*fs[2][1]+k*fs[2][2];
		i=i2;
		j=j2;
	return this;
	
	}

	public Vector3D toFloat() {
		// TODO Auto-generated method stub
		return new Vector3D((float)i,(float)j,(float)k);
	}



	
}
