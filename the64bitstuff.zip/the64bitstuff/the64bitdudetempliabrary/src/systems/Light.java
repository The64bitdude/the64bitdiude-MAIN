package systems;

import java.awt.Color;

import systems.Shapes.Triangle3D;

public class Light {
	public Vector3D lightVector;
	public Vector3D lightPos;
	public Vector3D lightColor;
	public float intensity;
	public float Ad;
	private double spotFU;
	private double spotFL;
	private boolean isSpotLight;

	public int shadowRez;
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity,float Ac,float Al,float Aq,boolean spotLight,float spotIn,float spotOut,int shadowRez) {
		this.lightVector=lightVector.normalize();
		this.Ad=Ac+Al+Aq;
		this.shadowRez=shadowRez;
		this.lightPos=lightPos;
		this.lightColor=new Vector3D(lightColor.getRed(),lightColor.getGreen(),lightColor.getBlue());
		isSpotLight=spotLight;
		this.spotFU=isSpotLight?-Math.cos(spotOut/2):1;
	this.spotFL=isSpotLight?Math.cos(spotIn/2)+this.spotFU:1;
	
		this.intensity=intensity/(size);
	}
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity) {
	this(lightPos,lightVector,lightColor,size,intensity,0,0,0,false,0,0,0);
	}
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity,float spotIn,float spotOut) {
		this(lightPos,lightVector,lightColor,size,intensity,Math.toRadians(spotIn),Math.toRadians(spotOut));
		}
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity,float spotIn,float spotOut,int shadowrez) {
		this(lightPos,lightVector,lightColor,size,intensity,Math.toRadians(spotIn),Math.toRadians(spotOut),shadowrez);
		}
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity,double spotIn,double spotOut) {
		this(lightPos,lightVector,lightColor,size,intensity,0,0,0,true,(float)spotIn,(float)spotOut,0);
		}
	public Light(Vector3D lightPos,Vector3D lightVector,Color lightColor,float size,float intensity,double spotIn,double spotOut,int shadowrez) {
		this(lightPos,lightVector,lightColor,size,intensity,0,0,0,true,(float)spotIn,(float)spotOut,shadowrez);
		}
	public void update(Vector3D lightPos, Vector3D	lightVector) {
		this.lightVector=lightVector.normalize();
		this.lightPos=lightPos;
		
	}

	public Vector3D LightChange(Triangle3D t) {
		Vector3D Ldir=lightPos.sub(t.midPoint);
		
		
		float S=(float) (isSpotLight?(((Ldir.normalize().dot(lightVector))-spotFU)/spotFL):1);
		return lightColor.mul((intensity*Math.max(0,-S)*Math.max(0,t.shapeVector.dot(Ldir)))/(Ldir.magSqrd()));
		
	}
	
}
