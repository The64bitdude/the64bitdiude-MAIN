package systems;

public class Node<A> {
	public A dat;
	public Node(A a) {
		dat=a;
	}
	
}
