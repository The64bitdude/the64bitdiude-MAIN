package systems;

public class PointVector {
	public Vector3D pos;
	public Vector3D vector;
	public PointVector(Vector3D pos,Vector3D v) {
		this.pos=pos;
		vector=v;
	}
	public String toString() {
		return pos.toString()+ " "+vector.toString();
		
	}
}
