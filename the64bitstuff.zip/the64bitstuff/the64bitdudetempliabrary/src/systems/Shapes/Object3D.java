package systems.Shapes;

import systems.Collider;

public class Object3D {
	public Shape3D shape;
	public Collider collider;
	public Object3D(Shape3D shape,Collider collider) {
		this.shape=shape;
		this.collider=collider;
	}
	
}
