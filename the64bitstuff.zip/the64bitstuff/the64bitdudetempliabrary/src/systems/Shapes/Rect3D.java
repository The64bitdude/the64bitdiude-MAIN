package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Rect3D extends Shape3D{

	public Rect3D(Vector3D pos,Vector3D pos2,Vector3D pos3,Vector3D pos4,Color c) {
Triangle3D t=new Triangle3D(c);
t.addPoint(pos);
t.addPoint(pos2);
t.addPoint(pos3);
add(t);
t=new Triangle3D(c);
t.addPoint(pos3);
t.addPoint(pos4);
t.addPoint(pos);
add(t);
	}

}
