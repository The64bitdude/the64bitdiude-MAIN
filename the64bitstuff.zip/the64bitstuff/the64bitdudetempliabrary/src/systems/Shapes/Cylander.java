package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Cylander extends Shape3D{
	public Cylander(Vector3D pos,Vector3D r,float rez,Color c) {
		this(pos,r,rez,c,true);
	}
	public Cylander(Vector3D pos, Vector3D r, float rez, Color c, boolean caps) {
		this(pos,r,rez,c,caps,0,360);
	}
	public Cylander(Vector3D pos, Vector3D r, float rez, Color c, boolean caps,float startangle,float endangle) {
		super();
		if(caps) {
		add(new Ovel3D(pos.add(0, 0, r.k),r.add(0,0, -r.k),rez,rez,c,0,360,-1,180));
		add(new Ovel3D(pos,r.add(0,0, -r.k),rez,rez,c,0,360,-1,180).flipThis());
		}
	if(rez%2!=0) {
		rez=rez-rez%2;
	}
		float dO =360/rez;
		float dU =r.k/rez;
		for(float i=startangle;i<endangle;i+=dO) {
			
			for(float j=0;j<r.k;j+=dU) {
				float x= (float) Math.sin(Math.toRadians(i));
				float y= (float) Math.cos(Math.toRadians(i));
				float z= (float)j;
				float di=i+dO;
				float dj=j+dU;
				float x2= (float) (Math.sin(Math.toRadians(di)));
				float y2= (float) (Math.cos(Math.toRadians(di)));
				float x3= (float) (Math.sin(Math.toRadians(di)));
				float y3= (float) (Math.cos(Math.toRadians(di)));
				float x4= x;
				float y4= y;
				float z2= dj;
				if(z<z2) {
				add(new Rect3D(pos.add(r.i*x4,r.j*y4,z2),pos.add(r.i*x,r.j*y,z),pos.add(r.i*x2,r.j*y2,z),pos.add(r.i*x3,r.j*y3,z2),c));
				}
			
			}
		}
	}
}
