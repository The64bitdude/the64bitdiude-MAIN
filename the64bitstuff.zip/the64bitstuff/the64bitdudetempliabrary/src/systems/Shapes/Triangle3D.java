package systems.Shapes;

import java.awt.Color;
import java.awt.Point;
import java.awt.Polygon;

import systems.BiNode;
import systems.Camera;
import systems.Light;
import systems.Vector3D;

public class Triangle3D {
	public Vector3D[] points;
	public Vector3D shapeVector;
	public Vector3D midPoint;
	public BiNode<Vector3D,Integer> color;
	public Vector3D bake=new Vector3D(0,0,0);
	public int size;
	private float dist;
	boolean distinit;
	private float distL;
	public Triangle3D() {
		points = new Vector3D[3];
		midPoint=new Vector3D(0,0,0);
		size=0;
		dist=0;
		distinit=false;
	}
public Triangle3D(Color BaseColor) {
	this();
	color=new BiNode<Vector3D,Integer>(new Vector3D(BaseColor.getRed(),BaseColor.getGreen(),BaseColor.getBlue()),BaseColor.getAlpha());

}
public Triangle3D(BiNode<Vector3D, Integer> color2) {
	this();
	color=color2;
}
public Triangle3D(Vector3D lightColor) {
	this();
	color=new BiNode<Vector3D,Integer>(lightColor,255);
}
public Triangle3D flip() {
	Triangle3D out=new Triangle3D(color);
	out.addPoint(points[2]);
	out.addPoint(points[1]);
	out.addPoint(points[0]);
	return out;
}
public Triangle3D flipThis() {
	Vector3D buf= points[0];
	points[0]=points[2];
	points[2]=buf;
	init();
	return this;
}
public Triangle3D clone() {
	Triangle3D out=new Triangle3D(color);
	out.points=points.clone();
	out.size=3;
	out.init();
	return out;
	
}
public void addPoints(Iterable<Vector3D> p){
	for(Vector3D v:p) {
		addPoint(v);
	}
}
public Shape3D rezDiv3() {
	Shape3D s=new Shape3D();
	Triangle3D t=new Triangle3D(color);
	t.addPoint(points[0]);
	t.addPoint(midPoint);
	t.addPoint(points[2]);
	s.add(t);
	t=new Triangle3D(color);
	t.addPoint(points[2]);
	t.addPoint(midPoint);
	t.addPoint(points[1]);
	s.add(t);
	t=new Triangle3D(color);
	t.addPoint(points[1]);
	t.addPoint(midPoint);
	t.addPoint(points[0]);
	s.add(t);
	return s;
}
public Shape3D rezDiv2() {
	Shape3D s=new Shape3D();
	Triangle3D t=new Triangle3D(color);
	Vector3D centercut= new Vector3D(0,0,0);
	centercut.addThis(points[0]);
	centercut.addThis(points[2]);
	centercut.divThis(2);
	t.addPoint(points[1]);
	t.addPoint(centercut);
	t.addPoint(points[0]);

	s.add(t);
	t=new Triangle3D(color);
	t.addPoint(points[2]);
	t.addPoint(centercut);
	t.addPoint(points[1]);

	s.add(t);
	return s;
}
public void addPoint(Vector3D p){
	points[size]=p;
	size++;
	if(size>=3) {
		init();
		if(size>3) {
			size=3;
		}
	}
	
}
private void init() {
	midPoint=points[0].add(points[1].add(points[2])).div(3);
	shapeVector=points[1].sub(points[0]).cross(points[1].sub(points[2])).normalize();
	
}
public void setColor(Color c) {
	color=new BiNode<Vector3D,Integer>(new Vector3D(c.getRed(),c.getGreen(),c.getBlue()),c.getAlpha());

}
public Polygon getPolygon(Camera cam) {
	Polygon out =new Polygon();
	for(int i =0;i<size;i++) {
		Vector3D p = cam.project(points[i]);
		if(p.k>0.1f||p.k<-0.1f) {
		out.addPoint((int)p.i,(int)p.j);
		}
		
	}
	
	return out;
}
public float getDist(Camera cam) {
	if(distinit) {
		return dist;
	}else {
		dist=cam.getDist(midPoint);
		distinit=true;
		return dist;
	}
	
}
public float getDist(Vector3D v) {
	return midPoint.sub(v).mag();
}
public void distInit() {
	distinit=false;
	
}
public void translateThis(float x, float y, float z) {
	for(int i =0;i<size;i++) {
		
		points[i]=points[i].add(x, y, z);
		
	}
	dist=0;
	distinit=false;
	init();
	
}


public Triangle3D rotateThis(Vector3D o, float[][] rollm) {
	for(int i =0;i<size;i++) {

	points[i]=points[i].sub(o).matrixMul(rollm).add(o);
			
}
	dist=0;
	distinit=false;
	init();
	return this;
	
}
public float getDist(Light l) {
	if(distinit) {
		return distL;
	}else {
		distL=getDist(l.lightPos);
		distinit=true;
		return distL;
	}
}





}
