package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Circle extends Shape3D{

	public Circle(Vector3D pos,Vector3D r, float rez,Color c) {
		super();
		
		rez=((int)(rez/2+0.5f))*2;
		float dO =360/rez;
		for(float i=0;i<360;i+=dO) {
			Triangle3D out= new Triangle3D(c);
			float x= (float ) Math.sin(Math.toRadians(i));
			float y= (float ) Math.cos(Math.toRadians(i));
			float x2= (float ) Math.sin(Math.toRadians(i+dO));
			float y2= (float ) Math.cos(Math.toRadians(i+dO));
			out.addPoint(pos.add(x2*r.i, y2*r.j,0));
			out.addPoint(pos);
			out.addPoint(pos.add(x*r.i, y*r.j,0));
			
		add(out);
		}
	}
}
