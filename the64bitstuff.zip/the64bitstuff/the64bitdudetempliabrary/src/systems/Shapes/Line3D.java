package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Line3D extends Shape3D{

	public Line3D(Vector3D pos,Vector3D pos2,Color c) {
		super();
		add(new Triangle3D(c));
		this.triangles.get(0).addPoint(pos);
		this.triangles.get(0).addPoint(pos2);
		this.triangles.get(0).midPoint=pos.add(pos2).div(2);

		}

	public Line3D(Vector3D pos, Vector3D pos2, Vector3D lightColor) {
		super();
		add(new Triangle3D(lightColor));
		this.triangles.get(0).addPoint(pos);
		this.triangles.get(0).addPoint(pos2);
		this.triangles.get(0).midPoint=pos.add(pos2).div(2);

	}

}
