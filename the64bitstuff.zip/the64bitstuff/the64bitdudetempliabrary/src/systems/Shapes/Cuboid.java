package systems.Shapes;

import java.awt.Color;
import java.util.Vector;

import systems.Vector3D;

public class Cuboid extends Shape3D{

	public Cuboid(Vector3D pos,Vector3D whl,Color c) {
	pos.addThis(whl.min(0).mul(2));
	whl.absThis();
	add(new Rect3D(pos,pos.add(whl.i, 0, 0),pos.add(whl.i, whl.j, 0),pos.add(0, whl.j, 0),c));
	add(new Rect3D(pos.add(0, whl.j, whl.k),pos.add(whl.i, whl.j, whl.k),pos.add(whl.i, 0, whl.k),pos.add(0,0,whl.k),c));
	add(new Rect3D(pos,pos.add(0, whl.j, 0),pos.add(0, whl.j, whl.k),pos.add(0, 0, whl.k),c));
	add(new Rect3D(pos.add(whl.i, whl.j, whl.k),pos.add(whl.i, whl.j, 0),pos.add(whl.i, 0, 0),pos.add(whl.i, 0, whl.k),c));
	add(new Rect3D(pos.add(whl.i, 0, whl.k),pos.add(whl.i, 0, 0),pos,pos.add(0, 0, whl.k),c));
	add(new Rect3D(pos.add(0,whl.j,0),pos.add(whl.i, whl.j, 0),pos.add(whl.i, whl.j, whl.k),pos.add(0, whl.j, whl.k),c));
	}
	/**
	 * @author The64BitDude
	 * @param sides [ 0 bottom , 1 Top ,  2 back , 3 front , 4 right , 5 left ]
	 * 			
	 */
	public Cuboid(Vector3D pos,Vector3D whl,Color c,boolean[] sides) {
		pos.addThis(whl.min(0).mul(2));
		whl.absThis();
		if(sides[0]) {
		add(new Rect3D(pos,pos.add(whl.i, 0, 0),pos.add(whl.i, whl.j, 0),pos.add(0, whl.j, 0),c));
		}
		if(sides[1]) {
		add(new Rect3D(pos.add(0, whl.j, whl.k),pos.add(whl.i, whl.j, whl.k),pos.add(whl.i, 0, whl.k),pos.add(0,0,whl.k),c));
		}
		if(sides[2]) {
		add(new Rect3D(pos,pos.add(0, whl.j, 0),pos.add(0, whl.j, whl.k),pos.add(0, 0, whl.k),c));
		}
		if(sides[3]) {
		add(new Rect3D(pos.add(whl.i, whl.j, whl.k),pos.add(whl.i, whl.j, 0),pos.add(whl.i, 0, 0),pos.add(whl.i, 0, whl.k),c));
		}
		if(sides[4]) {
		add(new Rect3D(pos.add(whl.i, 0, whl.k),pos.add(whl.i, 0, 0),pos,pos.add(0, 0, whl.k),c));
		}
		if(sides[5]) {
		add(new Rect3D(pos.add(0,whl.j,0),pos.add(whl.i, whl.j, 0),pos.add(whl.i, whl.j, whl.k),pos.add(0, whl.j, whl.k),c));
		}
		}
	


}
