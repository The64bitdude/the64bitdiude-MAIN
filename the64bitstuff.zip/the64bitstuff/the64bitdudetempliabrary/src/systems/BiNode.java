package systems;

public class BiNode<A,B> {
	public A datA;
	public B datB;
	public BiNode(A a,B b) {
		datA=a;
		datB=b;
	}
	
}
