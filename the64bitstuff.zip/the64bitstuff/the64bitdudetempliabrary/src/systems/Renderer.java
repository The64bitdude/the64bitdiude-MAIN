package systems;




import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderContext;
import java.awt.image.renderable.RenderableImage;
import java.awt.image.renderable.RenderableImageOp;
import java.awt.image.renderable.RenderableImageProducer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.function.Predicate;

import systems.Shapes.Line3D;
import systems.Shapes.Shape3D;
import systems.Shapes.Triangle3D;

public class Renderer {
	public Camera cam;
	private Vector<Triangle3D> allTriangles;
	public Vector<Shape3D> allShapes;
	Vector<Light> lights;
	Vector<BiNode<Polygon,Color>> out;
	public int lightsSize;
	private boolean baked=false;
	float Ad;
	
	
	public Renderer(Camera cam) {
	this.cam=cam;

	allTriangles=new Vector<Triangle3D>();
	allShapes=new Vector<Shape3D>();
	lights=new Vector<Light>();
	out=new Vector<BiNode<Polygon,Color>>();

	}
	
	public void add(Shape3D s) {
		allShapes.add(s);
		allTriangles.addAll(allShapes.lastElement().triangles);
	}

	public void add(Light l,boolean line,float size) {
		add(l);
		if(line) {
		add(new Line3D(l.lightPos,l.lightPos.add(l.lightVector.mul(l.intensity*size)),l.lightColor));
		}
		lightsSize++;
	}
	public void add(Light l) {
		lights.add(l);
		lightsSize++;
		
	}
	
	public void bake() {
		if(lights.size()>0) {
		
		for(Triangle3D t:allTriangles) {
			
			if(t.shapeVector!=null) {
				
				Vector3D c=new Vector3D(0,0,0);
				
				if(lights.size()>0) {
				
					
			for(Light L :lights) {
				c.addThis(L.LightChange(t));

			}
			
		
				}
				
				t.bake=c;
				
				
	
		
				
				
				
			}
			
		
		
		
	
		}
	
		lights.clear();
		baked=true;
		}
		
		
	}
	
	
	//float Lcomp=Math.max(0,-t.shapeVector.dot(LV.normalize())+LV.normalize().dot(L.lightVector));
			//float sD=2*Math.max(1f,LV.cross(L.lightVector).mag()+LV.mag());
			
	
	/*
	 * baked lights do the start breightness for you so if you plan on baking lights set startBrightness to 255
	 */
	public synchronized void update(boolean showShapeVector) {

		
		
		allTriangles.sort(new Comparator<Triangle3D>() {

			@Override
			public int compare(Triangle3D o1, Triangle3D o2) {
				return Float.compare(o2.getDist(cam), o1.getDist(cam));
				
			}
			
		});
		
		Vector<BiNode<Polygon,Color>>	buffer = new Vector<BiNode<Polygon,Color>>();
			for(Triangle3D t:allTriangles) {
				
			if(t.shapeVector!=null) {
				if(t.shapeVector.dot(t.midPoint.sub(cam.pos))<0&&t.getDist(cam)>0.1f) {
				Vector3D c=t.bake.add(0);
				
				if(lights.size()>0) {
		
			for(Light L :lights) {
			
				
				c.addThis(L.LightChange(t));
				
		
			}
			
		
				}
				c.mulThis(t.color.datA);
				c.minThis(255);
				c.maxThis(0);
				
				

				buffer.add(new BiNode<Polygon,Color>(t.getPolygon(cam),new Color((int)(c.i+0.5f),(int)(c.j+0.5f),(int)(c.k+0.5f),t.color.datB)));
			if(showShapeVector) {
		
				buffer.add(new BiNode<Polygon,Color>(new Line3D(t.midPoint,t.midPoint.add(t.shapeVector.mul(100)),Color.BLACK).triangles.get(0).getPolygon(cam),buffer.lastElement().datB));
			}
				}
				
				
			}else {
				t.color.datA.minThis(255);
				t.color.datA.maxThis(0);
			buffer.add(new BiNode<Polygon,Color>(t.getPolygon(cam),new Color((int)(t.color.datA.i+0.5f),(int)(t.color.datA.j+0.5f),(int)(t.color.datA.k+0.5f),t.color.datB)));
		
			
			}
			
		
		
		
		t.distInit();
		
			}
	
		out=buffer;

	}
	public synchronized BufferedImage updateRender(boolean showShapeVector,int width,int height,int offsetx,int offsety,boolean fill) {
		BufferedImage bob=new BufferedImage(width,height,2);
		Graphics2D g=bob.createGraphics();
		g.setClip(0, 0, width, height);
		g.translate(offsetx, offsety);
		
		allTriangles.sort(new Comparator<Triangle3D>() {
			
			@Override
			public int compare(Triangle3D o1, Triangle3D o2) {
				return Float.compare(o2.getDist(cam), o1.getDist(cam));
				
			}
			
		});
		
			for(Triangle3D t: allTriangles) {
			
			if(t.shapeVector!=null) {
				if(t.shapeVector.dot(t.midPoint.sub(cam.pos))<0&&t.getDist(cam)>0.1f) {
				Vector3D c=t.bake.add(0);
				
				if(lights.size()>0) {
			
			for(Light L :lights) {
				c.addThis(L.LightChange(t));
			
			
			}
			
		
				}
				c.mulThis(t.color.datA);
				c.minThis(255);
				c.maxThis(0);
			g.setColor(new Color((int)(c.i+0.5f),(int)(c.j+0.5f),(int)(c.k+0.5f),t.color.datB));
			if(fill) {
			g.fill(t.getPolygon(cam));	
			}else {
			g.draw(t.getPolygon(cam));
			}
			if(showShapeVector) {
				if(fill) {
					g.fill(new Line3D(t.midPoint,t.midPoint.add(t.shapeVector.mul(100)),Color.BLACK).triangles.get(0).getPolygon(cam));
					}else {
						g.draw(new Line3D(t.midPoint,t.midPoint.add(t.shapeVector.mul(100)),Color.BLACK).triangles.get(0).getPolygon(cam));
					}
				
			}
				}
				
				
			}else {
				t.color.datA.minThis(255);
				t.color.datA.maxThis(0);
			g.setColor(new Color((int)(t.color.datA.i+0.5f),(int)(t.color.datA.j+0.5f),(int)(t.color.datA.k+0.5f),t.color.datB));
			if(fill) {
				g.fill(t.getPolygon(cam));	
				}else {
				g.draw(t.getPolygon(cam));
				}
			
			}
			
		
		
		
		t.distInit();
		
			}
		
		return bob;
	}
	public void paintRender(Graphics2D g,int offsetx,int offsety,boolean fill) {
	
	
		g.translate(offsetx, offsety);
		Vector< BiNode<Polygon,Color>> snapshot=out;
		
		if(fill) {
			
			for(BiNode<Polygon,Color> p:snapshot) {
				g.setColor(p.datB);
				g.fill(p.datA);
			}
		}else {
			for(BiNode<Polygon,Color> p:snapshot) {
				g.setColor(p.datB);
				g.draw(p.datA);
			}
		}
		
		g.translate(-offsetx,-offsety);
	}
	public Image ImageRender(int width,int height,int offsetx,int offsety,boolean fill) {
		BufferedImage bob=new BufferedImage(width,height,2);
		Graphics2D g=bob.createGraphics();
		g.setClip(0, 0, width, height);
		g.translate(offsetx, offsety);
		Vector< BiNode<Polygon,Color>> snapshot=out;
		
		if(fill) {
			
			for(BiNode<Polygon,Color> p:snapshot) {
				g.setColor(p.datB);
				g.fill(p.datA);
			}
		}else {
			for(BiNode<Polygon,Color> p:snapshot) {
				g.setColor(p.datB);
				g.draw(p.datA);
			}
		}
		
		g.translate(-offsetx,-offsety);
		return bob;
	}
	public void fillRender(Graphics2D g, int offsetx, int offsety) {
		paintRender(g,offsetx,offsety,true);
		
	}
	public void drawRender(Graphics2D g, int offsetx, int offsety) {
		paintRender(g,offsetx,offsety,false);
		
	}
	public void paintDebug(Graphics g, int offsetx, int offsety,int spacing) {
	g.drawString(toString(0), offsetx, offsety);
	g.drawString(toString(1), offsetx, offsety+spacing);
	g.drawString(toString(2), offsetx, offsety+spacing*2);
	g.drawString(toString(3), offsetx, offsety+spacing*3);
	g.drawString(toString(4), offsetx, offsety+spacing*4);
		
	}
	public String toString() {
		return "cam Pos: "+cam.pos+" cam Look Direction "+cam.SV+" number of polygons : "+out.size()+" number of objects : " +allTriangles.size()+ " number of lights : "+lights.size() ;
		
	}
	public String toString(int part) {
		switch(part) {
		case 0:return "cam Pos: "+cam.pos;
		case 1:return "cam Look Direction "+cam.SV;
		case 2:return"number of polygons : "+out.size();
		case 3:return"number of objects : " +allTriangles.size();
		case 4:return"number of lights : "+lights.size();
		}
		return toString();
	}
	public void setCamera(Camera b) {
		this.cam=b;
		
	}
		

	
}
