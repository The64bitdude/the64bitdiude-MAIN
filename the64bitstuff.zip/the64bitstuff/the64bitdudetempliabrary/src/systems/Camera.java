package systems;

import java.awt.Point;

public class Camera {
public Vector3D pos;
public Vector3D SV;
public Vector3D SVx;
Vector3D SVy;
private float pane;
private float fov;
public float paneArea;
public float lastAngle1;
public float lastAngle2;

public Camera(Vector3D initPos,double initAngle,double initAngle2,float ScreenBoxSize,float fov) {
	pos=initPos;
	this.fov=fov;
	this.pane = ScreenBoxSize;
	init(initAngle,initAngle2);
}
public void init(double angle1,double angle2){
	float panearea=(float) (pane*Math.tan(Math.toRadians(90-fov)));
paneArea=panearea;
this.lastAngle1=(float) Math.toDegrees(angle1);
this.lastAngle2=(float) Math.toDegrees(angle2);
	SV=new Vector3D((float)(Math.sin(angle1)*Math.cos(angle2)),(float)(Math.cos(angle1)*Math.cos(angle2)),(float)(Math.sin(angle2)));
	SVx=new Vector3D((float)(-paneArea*Math.cos(angle1)),(float)(paneArea*Math.sin(angle1)),0);
	SVy=SV.cross(SVx);
}
public void update(double angle1,double angle2){
	SV.set((float)(Math.sin(angle1)*Math.cos(angle2)),(float)(Math.cos(angle1)*Math.cos(angle2)),(float)(Math.sin(angle2)));
	SVx.set((float)(-paneArea*Math.cos(angle1)),(float)(paneArea*Math.sin(angle1)),0);
	SVy.set(SV.cross(SVx));
	this.lastAngle1=(float) Math.toDegrees(angle1);
	this.lastAngle2=(float) Math.toDegrees(angle2);
}
public void move(int parrelel,int perpendicular,int updown) {
	pos.addThis(SV.mul(parrelel));
	pos.addThis(SVx.div(paneArea).mul(perpendicular));
	pos.addThis(0,0,updown);
}
public Vector3D project(Vector3D p) {
	Vector3D v=getScreenCords(p);
	if(v.k>0) {
		v.divThis(v.k,v.k,1);
	}else {
		v.mulThis(-v.k,-v.k,1);
	}
	return v;
	
}
public Vector3D projectWD(Vector3D p) {
	Vector3D v=getScreenCords(p);
if(v.k>0) {
	v.divThis(v.k,v.k,1);
}else {
	v.mulThis(-v.k,-v.k,1);
}
	return v;
	
}
public Point projectScreen(Vector3D p,int xshift,int yshift) {
	Vector3D out=p.sub(pos);
	float z=SV.dot(out);
	float x=SVx.dot(out);
	float y=SVy.dot(out);
	if(z>0) {
	return new Point((int)(x/z)+xshift,(int)(y/z)+yshift);
	}else {
		z*=-1;
	return new Point((int)(x*z)+xshift,(int)(y*z)+yshift);	
	}
	
	
}

public Vector3D getScreenCords(Vector3D p) {
	Vector3D out=p.sub(pos);
	out.set(SVx.dot(out),SVy.dot(out),SV.dot(out));
	return out;
}
public Point flattenZ(float x,float y,float z) {
	return new Point((int)(x/z),(int)(y/z));
}
public Point flattenX(float x,float y,float z) {
	return flattenZ(z,y,x);
}
public Point flattenY(float x,float y,float z) {
	return flattenZ(x,z,y);
}
public Point flattenZ(Vector3D p) {
	return flattenZ(p.i,p.j,p.k);
}
public Point flattenX(Vector3D p) {
	return flattenX(p.i,p.j,p.k);
}
public Point flattenY(Vector3D p) {
	return flattenY(p.i,p.j,p.k);
}
public float getDist(Vector3D p) {
	return SV.dot(p.sub(pos));
}

public String toString() {
	return lastAngle1+" "+lastAngle2+" "+pos.i+" "+pos.j+" "+pos.k;
}
}
