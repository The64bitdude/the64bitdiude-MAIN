package dataServer2;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import EventMaker.MultiThreadEvent;
import customlists.HashMap;

public class ConnectionManager {
private ArrayList<MultiThreadEvent<String>> connections;
private ArrayList<Thread> threads;
public boolean AcceptingConnections=false;
public void setAcceptingConnections(boolean b) {
	// TODO Auto-generated method stub
	if(AcceptingConnections) {
		AcceptConnections();
	}
}
private void AcceptConnections() {
	connections.add(new MultiThreadEvent<String>() {

		@Override
		public void run() {
			try {
				ServerSocket sS = new ServerSocket(100);
				Socket s =sS.accept();
		while(s.isConnected()) {
			byte[] b =new byte[Integer.MAX_VALUE];
			s.getInputStream().read(b);
			String out = "";
			for(byte B:b) {
			out+=Byte.toString(B);
			}
			this.data.add(String.valueOf(b));
			
		}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
	});
	threads.add(new Thread(connections.get(0)));
	threads.get(0).start();
	try {
		threads.get(0).join();
		System.out.println(connections.get(0).data.get(0));
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	

	
}
}
