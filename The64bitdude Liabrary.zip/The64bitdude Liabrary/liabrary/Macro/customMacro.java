package Macro;

import java.awt.AWTException;
import java.awt.Robot;

public class customMacro {
public static void main(String[] args) {
	System.out.println(System.getProperties().toString());
	try {
		Robot r = new Robot();
		r.mouseMove(0, 0);
	} catch (AWTException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
