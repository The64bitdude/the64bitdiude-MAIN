package Screens;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
 * 
 * @author  The64BitDude
 * @param sw is screenWidth
 * @param sh is screenHeight
 * @param c is the backround color
 * @param fps screen frames per second
 * @see #RefreshScreen(int, int, Color, int, int)
 * @see #RefreshScreen(int, int, Color, int)
 */

public abstract class RefreshScreen extends JPanel implements Runnable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2395064685927837674L;
	/**
	 * The thread of this screen
	 * @author  The64BitDude
	 */
	public Thread T;
	/**
	 * set Width of the current screen
	 * @author  The64BitDude
	 */
	public int screenWidth;
	/**
	 * set Height of the current screen
	 * @author  The64BitDude
	 */
	public int screenHeight;
	/**
	 * set frames per second of the current screen
	 * @author  The64BitDude
	 */
	public int FPS;
	/**
	 * current frames per second of the current screen
	 * @author  The64BitDude
	 */
	public float currentFPS = 0;
	
	/**
	 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
	 * 
	 * @author  The64BitDude
	 * @param sw is screenWidth
	 * @param sh is screenHeight
	 * @param c is the backround color
	 * @param fps screen frames per second
	 * @see #RefreshScreen(int, int, Color, int, int)
	 */
	public RefreshScreen(int sw,int sh,Color c,int fps) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(3);
		frame.setSize(sw,sh);
		frame.add(this);
		FPS = fps;
		screenWidth = sw;
		screenHeight = sh;
		this.setPreferredSize(new Dimension(screenWidth,screenHeight));
		this.setDoubleBuffered(true);
		this.setFocusable(true);
		this.setBackground(c);
		setScreen(this,frame);
		frame.pack();
		frame.setVisible(true);
		Start();
	}
	public static final int KEYS = 0;
	public static final int MOUSE = 1;
	public static final int MOUSEPOS = 2;
	public static final int ALL = 3;
	
	/**
	 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second
	 * 
	 * @author  The64BitDude
	 * @param sw is screenWidth
	 * @param sh is screenHeight
	 * @param c is the backround color
	 * @param fps screen frames per second
	 * @param type is the type of input you want
	 * <p></p><b>TYPES</b>
	 *<ul><li><b><code>KEYS</code></b> == 0 only the keys are initialized
     * <li><b><code>MOUSE</code></b> == 1    only the mouse is initialized
     * <li><b><code>MOUSEPOS</code></b> == 2   only the mouse position is initialized
     * <li><b><code>ALL</code></b> == 3   the mouse keys and mouse position are initialized
	 * </ul>
	 * @see #RefreshScreen(int, int, Color, int)
	 */
	public RefreshScreen(int sw,int sh,Color c,int fps,int type) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(3);
		frame.setSize(sw,sh);
		frame.add(this);
		FPS = fps;
		screenWidth = sw;
		screenHeight = sh;
		this.setPreferredSize(new Dimension(screenWidth,screenHeight));
		this.setDoubleBuffered(true);
		this.setFocusable(true);
		this.setBackground(c);
		switch(type) {
		case KEYS: this.addKeyListener(keys);break;
		case MOUSE:this.addMouseListener(mouse); ;break;
		case MOUSEPOS: this.addMouseMotionListener(mousepos);break;
		case ALL: this.addKeyListener(keys);this.addMouseListener(mouse);this.addMouseMotionListener(mousepos);
		}
		setScreen(this,frame);
		frame.pack();
		frame.setVisible(true);
		Start();
	}
	/**
	 * used to add event listeners and other class setting related things that cannot be done after the thread is started
	 * @author  The64BitDude
	 * @param refreshScreen is this {@link RefreshScreen}
	 * @param frame is the {@link JFrame} that holds this {@link RefreshScreen}
	 */
	public abstract void setScreen(RefreshScreen refreshScreen,JFrame frame);
	/**
	 * used to update values in your code every frame
	 * @author  The64BitDude
	 */
	public abstract void update();
	/**
	 * uses {@link Graphics} to update this frame's graphics every frame
	 * 
	 * @author  The64BitDude
	 * @param g is the {@link Graphics} of this frame and is updated every frame
	 */
	public abstract void paint(Graphics g);
	
	public void run() {
		initialize();
	
	long atime = System.nanoTime();
	long btime = atime;
	long dtime=((long) (1000000000f/FPS));
	while(T!=null) {
		btime = System.nanoTime();
		long tdif = (btime-atime);
		if(tdif>=dtime) {
			currentFPS = Math.round((1000000000f/tdif));
			atime = System.nanoTime();
			update();
			repaint();
			
		
		}
	}
		
	}
	/**
	 * used to initalize values that do not update every frame before you start updating
	 * @author  The64BitDude
	 */
	public abstract void initialize();
	/**
	 * easy way to use keypresses
	 * @author  The64BitDude
	 */
	public boolean isKeyPressed(int n) {
		
		return PressedKeys.containsKey(n)?PressedKeys.get(n):false;
		
	}/**
	 * easy way to use W A S D keypresses
	 * @author  The64BitDude
	 */
	public boolean WASD(int dir) {
		
		switch(dir) {
		case 0:return PressedKeys.containsKey(KeyEvent.VK_W)?PressedKeys.get(KeyEvent.VK_W):false;
		case 1:return PressedKeys.containsKey(KeyEvent.VK_A)?PressedKeys.get(KeyEvent.VK_A):false;
		case 2:return PressedKeys.containsKey(KeyEvent.VK_S)?PressedKeys.get(KeyEvent.VK_S):false;
		case 3:return PressedKeys.containsKey(KeyEvent.VK_D)?PressedKeys.get(KeyEvent.VK_D):false;
		}
		return false;
	}
	
	public void Start() {
		T = new Thread(this);
		T.start();
	}
	/**
	 * a {@link HashMap} containing the current pressed keys <code>extended keycode</code> as the key and returning if its pressed or not
	 * @author  The64BitDude
	 */
	public HashMap<Integer,Boolean> PressedExactKeys = new HashMap<Integer,Boolean>();
	/**
	 * a {@link HashMap} containing the current pressed keys <code>keycode</code> as the key and returning if its pressed or not
	 * @author  The64BitDude
	 */
	public HashMap<Integer,Boolean> PressedKeys = new HashMap<Integer,Boolean>();
	/**
	 * Weather or not the mouse is pressed down
	 * @author  The64BitDude
	 */
	public boolean mousePressed = false;
	/**
	 *  the X position of the mouse on the screen
	 * @author  The64BitDude
	 */
	public int mouseX = 0;
	/**
	 *  the Y position of the mouse on the screen
	 * @author  The64BitDude
	 */
	public int mouseY = 0;
	/**
	 *  the last key pressed excluding shift clicked keys
	 * @author  The64BitDude
	 */
	public int LatestKeyCode = 0;
	/**
	 * the last key pressed including shift clicked keys
	 * @author  The64BitDude
	 */
	public int LatestExtendedKeyCode = 0;
	
	public KeyListener keys = new KeyListener() {

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
		}

		@Override
		public void keyPressed(KeyEvent e) {
			PressedKeys.put(e.getKeyCode(), true);
			PressedExactKeys.put(e.getExtendedKeyCode(), true);
			LatestKeyCode = e.getKeyCode();
			LatestExtendedKeyCode = e.getExtendedKeyCode();
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			PressedKeys.put(e.getKeyCode(),false);
			PressedExactKeys.put(e.getExtendedKeyCode(), false);
		}
		
	};
	public int clicks =0;
	public boolean leftMousePressed = false;
	public boolean rightMousePressed = false;
	public MouseListener mouse = new MouseListener() {



		@Override
		public void mouseClicked(MouseEvent e) {
			clicks++;
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			mousePressed=true;
			if(e.getButton()==MouseEvent.BUTTON3) {
				leftMousePressed = true;
			}
			if(e.getButton()==MouseEvent.BUTTON1) {
				rightMousePressed = true;
			}
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			mousePressed=false;
			if(e.getButton()==MouseEvent.BUTTON3) {
				leftMousePressed = false;
			}
			if(e.getButton()==MouseEvent.BUTTON1) {
				rightMousePressed =false;
			}
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		
		
	};
	public MouseMotionListener mousepos = new MouseMotionListener() {

		@Override
		public void mouseDragged(MouseEvent e) {
			mouseX = e.getX();
			mouseY = e.getY();
			
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			mouseX = e.getX();
			mouseY = e.getY();
			
		}
		
	};
	

	
}
