package Screens;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Comparator;

import javax.swing.JFrame;

import Systems.Camera;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.PolygonWr;

public abstract class RefreshScreen3D extends RefreshScreen{
private Color BackRoundColor =Color.black;

public Camera camera;

public ArrayList<PolygonWr> polys;
/**
 * This is a {@link JFrame} that refreshes the screen at {@code fps} amount of frames per second 
 * It also Pre makes a camera and has a method for a simple movement system wasd shift and space
 * 
 * @author  The64BitDude
 * @param sw is screenWidth
 * @param sh is screenHeight
 * @param c is the backround color
 * @param fps screen frames per second
 * @see #RefreshScreen(int, int, Color, int, int)
 * @see #RefreshScreen(int, int, Color, int)
 */

public RefreshScreen3D(int sw,int sh,Color c,int fps,int type,double FOV) {
	super(sw, sh, c, fps,type);
	camera = new Camera(FOV, screenWidth, screenHeight, new Point3D(0,0,0), 0, 0);
	BackRoundColor=c;
	polys=new ArrayList<PolygonWr>();
}
public RefreshScreen3D(int sw, int sh, Color c, int fps,double FOV) {
		super(sw, sh, c, fps);
		camera = new Camera(FOV, screenWidth, screenHeight, new Point3D(0,0,0), 0, 0);
		BackRoundColor=c;
		polys=new ArrayList<PolygonWr>();
		// TODO Auto-generated constructor stub
	}
	



	@Override
	public void paint(Graphics g) {
		Graphics3D g3 = new Graphics3D(g);
		g3.setColor(BackRoundColor);
		g3.fillRect(0, 0,screenWidth, screenHeight);
		if(polys!=null) {
		for(PolygonWr p:polys) {
			g3.setColor(p.c);
			g3.fill(p.p);
		}
		}
		drawFrame(g3);
		g3.dispose();
		
	}
	public void update() {
		System.gc();
		Update();
		Graphics3D g3 = new Graphics3D();
		
		polys = calcPaint(g3);
		if(polys!=null) {
		polys.sort(new Comparator<PolygonWr>(){

				@Override
				public int compare(PolygonWr o1, PolygonWr o2) {
					double dist1 = o1.r.distance(camera);
					double dist2 = o2.r.distance(camera);
					if(dist1<dist2) {
						return 1;
					}else if(dist1>dist2) {
						return -1;
					}else if(dist1==dist2) {
						return 0;
					}
					return 0;
				}

			
				
			});
		}
		
	}
	public abstract void Update();
	public abstract ArrayList<PolygonWr> calcPaint(Graphics3D g3);
public void defaultCameraMovement(double speed,boolean useSpace) {
	camera.angle1 =Math.toRadians( ((mouseX-screenWidth/2.0)/screenWidth)*360.0);
	camera.angle2 =Math.toRadians( ((mouseY-screenHeight/2.0)/screenWidth)*360.0);
	camera.updateV();
	if(isKeyPressed(KeyEvent.VK_W)) {
		
		camera.cam.y+=speed*Math.cos(camera.angle1);
		camera.cam.x+=speed*Math.sin(camera.angle1);
	
}
if(isKeyPressed(KeyEvent.VK_S)) {
	
	camera.cam.y-=4*Math.cos(camera.angle1);
		camera.cam.x-=4*Math.sin(camera.angle1);
			
}
if(isKeyPressed(KeyEvent.VK_A)) {

	camera.cam.x-=4*Math.cos(camera.angle1);
	camera.cam.y+=4*Math.sin(camera.angle1);
	
}
if(isKeyPressed(KeyEvent.VK_D)) {
	
	camera.cam.x+=4*Math.cos(camera.angle1);
	camera.cam.y-=4*Math.sin(camera.angle1);
	
}
if(isKeyPressed(useSpace?KeyEvent.VK_SHIFT:KeyEvent.VK_Q)) {
	
	camera.cam.z+=4;	
	
}
if(isKeyPressed(useSpace?KeyEvent.VK_SPACE:KeyEvent.VK_E)) {
	
	camera.cam.z-=4;	
	
}

}
	public abstract void drawFrame(Graphics3D g3);



}
