package customlists;

import java.util.ArrayList;

public class HashMap<a,b> {
	ArrayList<Value<a,b>> values;
	
	public HashMap(){
		values = new ArrayList<Value<a,b>>();
	}
	public int size() {
		return values.size();
	}
	public void add(a key,b value) {
		values.add(new Value<a,b>(key,value));
	}
	public boolean contains(a key) {
		for(Value<a,b> v :values) {
			if(v.key.equals(key)){
				return true;
			}
		}
		return false;
	}
	public b get(a key) throws IndexOutOfBoundsException {
		for(Value<a,b> v :values) {
			if(v.key.equals(key)){
				return v.value;
			}
		}
		throw new IndexOutOfBoundsException();
	}
}
