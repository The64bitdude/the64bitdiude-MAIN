package customlists;

public class Value<a,b> {
	public a key;
	public b value;
	public Value(a key, b value) {
		this.key = key;
		this.value = value;
	}

}
