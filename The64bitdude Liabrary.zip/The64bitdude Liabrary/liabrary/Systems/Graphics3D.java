package Systems;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.RenderingHints.Key;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.text.AttributedCharacterIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Map;

import Shapes.Sphere;


public class Graphics3D extends Graphics2D{
	public Graphics2D g;
	public Color color;
	public Graphics3D(Graphics2D g) {
		this.g=g;
	}
	public Graphics3D(Graphics g) {
		this.g=(Graphics2D)g;
	}
	public Graphics3D() {
		
	}
	public void drawPoint3d(Point3D p,Camera c) {
		drawPoint(p.project(c));
		
	}
	public void drawCirclePoint3d(Point3D p,int s,Camera c) {
		drawCirclePoint(p.project(c),s);
		
	}
	public void fill3DRect(Point3D p) {
		
	}
	public void drawSphere(double x,double y,double z,double r,double vertices,Camera c) {
	Sphere sp= new Sphere(x,y,z,r,vertices);
	for(Point3D p:sp.points) {
		drawPoint(p.project(c));
	}
	}
	
	//2D
	
	public void drawPoint(Point p) {
		g.drawLine(p.x,p.y,p.x,p.y);
		
	}
	public void drawPoint(Point p,int s) {
		Stroke bef = g.getStroke();
		g.setStroke(new BasicStroke((float)s));
		g.drawLine(p.x,p.y,p.x,p.y);
		g.setStroke(bef);
		
	}
	public void drawCirclePoint(Point p,int s) {
		Stroke bef = g.getStroke();
		g.setStroke(new BasicStroke((float)s,  BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		g.drawLine(p.x,p.y,p.x,p.y);
		g.setStroke(bef);
		
	}
	public void drawPoint(int x,int y) {
		g.drawLine(x,y,x,y);
		
	}
	public void drawPoint(int x, int y, int s) {
		Stroke bef = g.getStroke();
		g.setStroke(new BasicStroke((float)s));
		g.drawLine(x,y,x,y);
		g.setStroke(bef);
		
	}
	public void drawCirclePoint(int x, int y, int s) {
		Stroke bef = g.getStroke();
		g.setStroke(new BasicStroke((float)s,  BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		g.drawLine(x,y,x,y);
		g.setStroke(bef);
		
	}
	@Override
	public void dispose() {
		g.dispose();
	}
	@Override
	public void draw(Shape s) {
		g.draw(s);
		
	}
	@Override
	public boolean drawImage(Image img, AffineTransform xform, ImageObserver obs) {
		// TODO Auto-generated method stub
		return g.drawImage(img,xform,obs);
	}
	@Override
	public void drawImage(BufferedImage img, BufferedImageOp op, int x, int y) {
		g.drawImage(img,op,x,y);
		
	}
	@Override
	public void drawRenderedImage(RenderedImage img, AffineTransform xform) {
	g.drawRenderedImage(img,xform);
		
	}
	@Override
	public void drawRenderableImage(RenderableImage img, AffineTransform xform) {
		g.drawRenderableImage(img, xform);
		
	}
	@Override
	public void drawString(String str, int x, int y) {
		g.drawString(str, x, y);
		
	}
	@Override
	public void drawString(String str, float x, float y) {
		g.drawString(str, x, y);
		
	}
	@Override
	public void drawString(AttributedCharacterIterator iterator, int x, int y) {
		g.drawString(iterator, x, y);
		
	}
	@Override
	public void drawString(AttributedCharacterIterator iterator, float x, float y) {
		g.drawString(iterator, x, y);
		
	}
	@Override
	public void drawGlyphVector(GlyphVector g, float x, float y) {
	this.g.drawGlyphVector(g,x,y);
		
	}
	@Override
	public void fill(Shape s) {
	g.fill(s);
		
	}
	@Override
	public boolean hit(Rectangle rect, Shape s, boolean onStroke) {
		// TODO Auto-generated method stub
		return g.hit(rect, s, onStroke);
	}
	@Override
	public GraphicsConfiguration getDeviceConfiguration() {
		// TODO Auto-generated method stub
		return g.getDeviceConfiguration();
	}
	@Override
	public void setComposite(Composite comp) {
		g.setComposite(comp);
		
	}
	@Override
	public void setPaint(Paint paint) {
		g.setPaint(paint);
		
	}
	@Override
	public void setStroke(Stroke s) {
		g.setStroke(s);
		
	}
	@Override
	public void setRenderingHint(Key hintKey, Object hintValue) {
		g.setRenderingHint(hintKey, hintValue);
		
	}
	@Override
	public Object getRenderingHint(Key hintKey) {
		// TODO Auto-generated method stub
		return g.getRenderingHint(hintKey);
	}
	@Override
	public void setRenderingHints(Map<?, ?> hints) {
	g.setRenderingHints(hints);
		
	}
	@Override
	public void addRenderingHints(Map<?, ?> hints) {
		g.addRenderingHints(hints);
		
	}
	@Override
	public RenderingHints getRenderingHints() {
		// TODO Auto-generated method stub
		return g.getRenderingHints();
	}
	@Override
	public void translate(int x, int y) {
	g.translate(x, y);
		
	}
	@Override
	public void translate(double tx, double ty) {
		g.translate(tx, ty);
		
	}
	@Override
	public void rotate(double theta) {
		g.rotate(theta);
		
	}
	@Override
	public void rotate(double theta, double x, double y) {
		g.rotate(theta, x, y);
		
	}
	@Override
	public void scale(double sx, double sy) {
		g.scale(sx, sy);
		
	}
	@Override
	public void shear(double shx, double shy) {
		g.shear(shx, shy);
		
	}
	@Override
	public void transform(AffineTransform Tx) {
		g.transform(Tx);
		
	}
	@Override
	public void setTransform(AffineTransform Tx) {
		g.setTransform(Tx);
		
	}
	@Override
	public AffineTransform getTransform() {
		// TODO Auto-generated method stub
		return g.getTransform();
	}
	@Override
	public Paint getPaint() {
		// TODO Auto-generated method stub
		return g.getPaint();
	}
	@Override
	public Composite getComposite() {
		// TODO Auto-generated method stub
		return g.getComposite();
	}
	@Override
	public void setBackground(Color color) {
	g.setBackground(color);
		
	}
	@Override
	public Color getBackground() {
		// TODO Auto-generated method stub
		return g.getBackground();
	}
	@Override
	public Stroke getStroke() {
		// TODO Auto-generated method stub
		return g.getStroke();
	}
	@Override
	public void clip(Shape s) {
		g.clip(s);
		
	}
	@Override
	public FontRenderContext getFontRenderContext() {
		// TODO Auto-generated method stub
		return g.getFontRenderContext();
	}
	@Override
	public Graphics create() {
		// TODO Auto-generated method stub
		return g.create();
	}
	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return g!=null?g.getColor():color;
	}
	@Override
	public void setColor(Color c) {
		if(g!=null) {
		g.setColor(c);
		}else {
			color=c;
		}
		
	}
	@Override
	public void setPaintMode() {
		g.setPaintMode();
		
	}
	@Override
	public void setXORMode(Color c1) {
		g.setXORMode(c1);
		
	}
	@Override
	public Font getFont() {
		// TODO Auto-generated method stub
		return g.getFont();
	}
	@Override
	public void setFont(Font font) {
	g.setFont(font);
		
	}
	@Override
	public FontMetrics getFontMetrics(Font f) {
		// TODO Auto-generated method stub
		return g.getFontMetrics(f);
	}
	@Override
	public Rectangle getClipBounds() {
		// TODO Auto-generated method stub
		return g.getClipBounds();
	}
	@Override
	public void clipRect(int x, int y, int width, int height) {
		g.clipRect(x, y, width, height);
		
	}
	@Override
	public void setClip(int x, int y, int width, int height) {
		g.setClip(x, y, width, height);
		
	}
	@Override
	public Shape getClip() {
		// TODO Auto-generated method stub
		return g.getClip();
	}
	@Override
	public void setClip(Shape clip) {
	g.setClip(clip);
		
	}
	@Override
	public void copyArea(int x, int y, int width, int height, int dx, int dy) {
		g.copyArea(x, y, width, height, dx, dy);
		
	}
	@Override
	public void drawLine(int x1, int y1, int x2, int y2) {
		g.drawLine(x1, y1, x2, y2);
		
	}
	@Override
	public void fillRect(int x, int y, int width, int height) {
		g.fillRect(x, y, width, height);
		
	}
	@Override
	public void clearRect(int x, int y, int width, int height) {
		g.clearRect(x, y, width, height);
		
	}
	@Override
	public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
		g.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
		
	}
	@Override
	public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
		g.fillRoundRect(x, y, width, height, arcWidth, arcHeight);
		
	}
	@Override
	public void drawOval(int x, int y, int width, int height) {
		g.drawOval(x, y, width, height);
		
	}
	@Override
	public void fillOval(int x, int y, int width, int height) {
		g.fillOval(x, y, width, height);
		
	}
	@Override
	public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
		g.drawArc(x, y, width, height, startAngle, arcAngle);
		
	}
	@Override
	public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
		g.fillArc(x, y, width, height, startAngle, arcAngle);
		
	}
	@Override
	public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {
		g.drawPolyline(xPoints, yPoints, nPoints);
		
	}
	@Override
	public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {
		g.drawPolygon(xPoints, yPoints, nPoints);
		
	}
	@Override
	public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {
		g.fillPolygon(xPoints, yPoints, nPoints);
		
	}
	@Override
	public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, x, y, observer);
	}
	@Override
	public boolean drawImage(Image img, int x, int y, int width, int height, ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, x, y, width, height, observer);
	}
	@Override
	public boolean drawImage(Image img, int x, int y, Color bgcolor, ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, x, y, bgcolor, observer);
	}
	@Override
	public boolean drawImage(Image img, int x, int y, int width, int height, Color bgcolor, ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, x, y, width, height, bgcolor, observer);
	}
	@Override
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
			ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, observer);
	}
	@Override
	public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
			Color bgcolor, ImageObserver observer) {
		// TODO Auto-generated method stub
		return g.drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, bgcolor, observer);
	}
	public void setGraphics(Graphics2D g2) {
		this.g=g2;
		
	}
	public void drawLine(int x,int y,Point proj) {
		g.drawLine(x,y, proj.x,proj.y);
		
	}
	public void drawLine(Point proj, Point projb) {
		g.drawLine(proj.x,proj.y, projb.x,projb.y);
		
	}
	
	
	public ArrayList<Polygon> shadeRect3D(Camera camera, Rect3D rect3d,boolean paste) {
		return shadeRect3D(camera,rect3d.x,rect3d.y,rect3d.z,rect3d.w,rect3d.l,rect3d.h,paste);
	}
	public ArrayList<Polygon> shadeRect3D(Point3D cam, double dis, double ang1, double ang2,double x, double y, double z, double w, double l,double h,int xd,int yd,boolean paste) {
		Camera camera = new Camera(cam,dis,ang1,ang2,xd*2,yd*2);
		return shadeRect3D(camera, x, y, z, w, l, h,paste);
		
	}
	public ArrayList<PolygonWr> shadeRect3D2(Camera camera, Rect3D rect3d,boolean paste,int[] exempt,Color[] sideC,int type) {
		return shadeRect3D2(camera,rect3d.x,rect3d.y,rect3d.z,rect3d.w,rect3d.l,rect3d.h,paste,exempt,sideC,type);
	}
	public ArrayList<PolygonWr> shadeRect3D2(Point3D cam, double dis, double ang1, double ang2,double x, double y, double z, double w, double l,double h,int xd,int yd,boolean paste,int[] exempt,Color[] sideC,int type) {
		Camera camera = new Camera(cam,dis,ang1,ang2,xd*2,yd*2);
		return shadeRect3D2(camera, x, y, z, w, l, h,paste,exempt,sideC, type);
		
	}
	public ArrayList<PolygonWr> shadeRect3D2(Camera camera, double x, double y, double z, double w, double l,double h,boolean paste,int[] exempt,Color[] sideC,int type) {
		ArrayList<Point3D> points= new ArrayList<Point3D>();
		ArrayList<Point> points2d= new ArrayList<Point>();
		//boolean[] working = new boolean[8];
		//int count3 = 0;
		for(double i = x;i<=x+w;i+=w) {
			for(double k = y;k<=l+y;k+=l) {
				for(double j = z;j<=z+h;j+=h) {
					points.add(new Point3D().setLocation(i, k, j));	
					//PointD pd= new Point3D().setLocation(i, k, j).project(camera);
					/*working[count3] =true;
					if(pd.getDist()<=0) {
						working[count3]=false;
						System.out.println(count3);
					}*/
					points2d.add(new Point3D().setLocation(i, k, j).project(camera));	
			//	count3++;
				
				}
			}
		}
		/*for(int i =0;i<8;i++) {
			if(!working[i]) {
			int outIndex=i;
		switch(i) {
		case 0:outIndex=working[2]?2:working[1]?1:4;break;
		case 1:outIndex=working[0]?0:working[5]?5:3;break;
		case 2:outIndex=working[3]?3:working[0]?0:6;break;
		case 3:outIndex=working[1]?1:working[2]?2:7;break;
		case 4:outIndex=working[5]?5:working[6]?6:0;break;
		case 5:outIndex=working[4]?4:working[7]?7:1;break;
		case 6:outIndex=working[2]?2:working[7]?7:4;break;
		case 7:outIndex=working[6]?6:working[3]?3:5;break;
		
		}
		points2d.set(i,new PointD(points.get(i).fixPoint(camera,points.get(outIndex)),0));
			}
			}*/
	//	0:2,1,4
	//	1:0,5,3
	//	2:3,0,6
	//	3:1,2,7
	//	4:5,6,0
	//	5:4,7,1
	//	6:2,7,4
	//	7:6,3,5
			
		ArrayList<Polygon3D> sides= new ArrayList<Polygon3D>();
		ArrayList<ArrayList<Point>> sides2d= new ArrayList<ArrayList<Point>>();
		for(int i = 0;i<6;i++) {
			sides.add(new Polygon3D());
			sides2d.add(new ArrayList<Point>());
		switch(i) {
		case 0: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(2));
		 sides2d.get(i).add(points2d.get(0));
		 sides2d.get(i).add(points2d.get(1));
		 sides2d.get(i).add(points2d.get(3));
		 sides2d.get(i).add(points2d.get(2));break;
		case 1: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(4));
		 sides2d.get(i).add(points2d.get(0));
		 sides2d.get(i).add(points2d.get(1));
		 sides2d.get(i).add(points2d.get(5));
		 sides2d.get(i).add(points2d.get(4));break;
		case 2: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(6));
		 sides.get(i).addPoint(points.get(4));
		 sides2d.get(i).add(points2d.get(0));
		 sides2d.get(i).add(points2d.get(2));
		 sides2d.get(i).add(points2d.get(6));
		 sides2d.get(i).add(points2d.get(4));break;
		case 3: sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(5));
		 sides2d.get(i).add(points2d.get(1));
		 sides2d.get(i).add(points2d.get(3));
		 sides2d.get(i).add(points2d.get(7));
		 sides2d.get(i).add(points2d.get(5));break;
		case 4: sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));
		 sides2d.get(i).add(points2d.get(2));
		 sides2d.get(i).add(points2d.get(3));
		 sides2d.get(i).add(points2d.get(7));
		 sides2d.get(i).add(points2d.get(6));break;
		case 5: sides.get(i).addPoint(points.get(4));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));
		 sides2d.get(i).add(points2d.get(4));
		 sides2d.get(i).add(points2d.get(5));
		 sides2d.get(i).add(points2d.get(7));
		 sides2d.get(i).add(points2d.get(6));break;
		}
		}
		

		ArrayList<PolygonWr> projcent = new ArrayList<PolygonWr>();
		ArrayList<PolygonWr> out = new ArrayList<PolygonWr>();
	
		
		
		int count =0;
		boolean[] draw = new boolean[8];
		for(Polygon3D p:sides) {
			
			Color c =sideC[count];
			draw[count]=true;
			projcent.add(new PolygonWr(p.calcAveragePoint(),c,type,count));
			for(Point s: sides2d.get(count)) {
			
				projcent.get(count).p.addPoint(s.x, s.y);
				
			}
		count++;
		}
		count =0;
		for(PolygonWr p :projcent) {
			
			int count2 =0;
			if(exempt[count]==0&&draw[count]) {
			for(PolygonWr p2 :projcent) {
				if(count != count2) {
					if(p.r.distance(camera)>p2.r.distance(camera)) {
						if(p2.p.contains(p.r.project(camera))){
							draw[count] = false;
						}
					}
				}
				count2++;
			}
			if(draw[count]) {
				if(paste) {
					draw(p.p);
				
				
				}
				
				out.add(p);
				
			}
			}
			count++;
		}
		return out;

		//left 0 1 3 2
		//back 0 1 5 4
		//top 0 2 6 4
		//bottom 1 3 7 5
		//front 2 3 7 6
		//right 4 5 7 6
		
		
		
		
	}
	public ArrayList<Polygon> shadeRect3D(Camera camera, double x, double y, double z, double w, double l,double h,boolean paste) {
		ArrayList<Point3D> points= new ArrayList<Point3D>();
		for(int i = (int)x;i<=(int)x+w;i+=w) {
			for(int k = (int)y;k<=l+(int)y;k+=l) {
				for(int j =(int) z;j<=z+h;j+=h) {
					points.add(new Point3D(i,k,j));	
				}
			}
		}
		ArrayList<Polygon3D> sides= new ArrayList<Polygon3D>();
		for(int i = 0;i<6;i++) {
			sides.add(new Polygon3D());
		switch(i) {
		case 0: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(2));break;
		case 1: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(4));break;
		case 2: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(6));
		 sides.get(i).addPoint(points.get(4));break;
		case 3: sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(5));break;
		case 4: sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));break;
		case 5: sides.get(i).addPoint(points.get(4));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));break;
		}
		}
		ArrayList<Point> buf = new ArrayList<Point>();
		

		ArrayList<Polygon> projcent = new ArrayList<Polygon>();
		ArrayList<Polygon> out = new ArrayList<Polygon>();
		ArrayList<Point3D> radcent = new ArrayList<Point3D>();
		int count =0;
		for(Polygon3D p:sides) {
			radcent.add(p.calcAveragePoint());
			projcent.add(new Polygon());
			for(Point3D p3: p.points) {
				Point s = p3.project(camera);
				projcent.get(count).addPoint(s.x,s.y);
			}
		count++;
		}
		count =0;
		for(Polygon p :projcent) {
			boolean draw = true;
			int count2 =0;
			for(Polygon p2 :projcent) {
				if(count != count2) {
					if(radcent.get(count).distance(camera)>radcent.get(count2).distance(camera)) {
						if(p2.contains(radcent.get(count).project(camera))){
							draw = false;
						}
					}
				}
				count2++;
			}
			if(draw) {
				if(paste) {
					draw(p);
				}
				out.add(p);
			}
			count++;
		}
		return out;

		//left 0 1 3 2
		//back 0 1 5 4
		//top 0 2 6 4
		//bottom 1 3 7 5
		//front 2 3 7 6
		//right 4 5 7 6
		
		
		
		
	}

	
	public ArrayList<Polygon> shadeR(BlockMap b, Camera camera, int x, int y, int z) {
		return shadeRect3D(camera, new Rect3D(x*b.size,y*b.size,z*b.size,b.size),false);
	}
	
	public ArrayList<Polygon> shadePolygon3D(Camera camera,Polygon3D pd) {
		ArrayList<Point3D> points = pd.points;
		
		ArrayList<Polygon3D> sides= new ArrayList<Polygon3D>();
		for(int i = 0;i<points.size()-3;i+=4) {
			Polygon3D ou = new Polygon3D();
			ou.addPoint(points.get(i));
			ou.addPoint(points.get(i+1));
			ou.addPoint(points.get(i+2));
			ou.addPoint(points.get(i+3));
			sides.add(ou);
	
		}
		
		ArrayList<Point> buf = new ArrayList<Point>();
		

		ArrayList<Polygon> projcent = new ArrayList<Polygon>();
		ArrayList<Polygon> out = new ArrayList<Polygon>();
		ArrayList<Point3D> radcent = new ArrayList<Point3D>();
		int count =0;
		for(Polygon3D p:sides) {
			radcent.add(p.calcAveragePoint());
			projcent.add(new Polygon());
			for(Point3D p3: p.points) {
				Point s = p3.project(camera);
				projcent.get(count).addPoint(s.x,s.y);
			}
		count++;
		}
		count =0;
		for(Polygon p :projcent) {
			boolean draw = true;
			int count2 =0;
			for(Polygon p2 :projcent) {
				if(count != count2) {
					if(radcent.get(count).distance(camera)>radcent.get(count2).distance(camera)) {
						if(p2.contains(radcent.get(count).project(camera))){
							draw = false;
						}
					}
				}
				count2++;
			}
			if(draw) {
				out.add(p);
			}
			count++;
		}
		return out;

		//left 0 1 3 2
		//back 0 1 5 4
		//top 0 2 6 4
		//bottom 1 3 7 5
		//front 2 3 7 6
		//right 4 5 7 6
		
		
		
		
	}
	public void draw(Polygon3D p, Camera camera) {
		Polygon out = new Polygon();
		for(Point3D P :p.points) {
			Point proj =P.project(camera);
			out.addPoint(proj.x, proj.y);
		}
		draw(out);
		Point3D pa = p.calcAveragePoint();
		drawCirclePoint(pa.project(camera),10);
		drawString(Math.round(pa.distance(camera)*100.00)/100.00 + " : " +Math.round(Math.toDegrees(pa.getAngle1(camera.cam))*100.00)/100.00+" : "+Math.round(Math.toDegrees(pa.getAngle2(camera.cam))*100.00)/100.00,p.calcAveragePoint().project(camera));
		
		
	}
	public Polygon fill(Polygon3D p,Camera camera) {
		Polygon out = new Polygon();
		for(Point3D P :p.points) {
			Point proj =P.project(camera);
			out.addPoint(proj.x, proj.y);
		}
		return out;
		
	}
	public ArrayList<Polygon> fillRect3D(Camera camera, Rect3D r) {
		ArrayList<Point3D> points= new ArrayList<Point3D>();
		for(int i = (int)r.x;i<=(int)r.x+r.w;i+=r.w) {
			for(int k = (int)r.y;k<=r.l+(int)r.y;k+=r.l) {
				for(int j =(int) r.z;j<=r.z+r.h;j+=r.h) {
					points.add(new Point3D(i,k,j));	
				}
			}
		}
		ArrayList<Point> projPoints= new ArrayList<Point>();
		for(Point3D p:points) {
			 projPoints.add(p.project(camera));
		}
		ArrayList<Polygon> sides= new ArrayList<Polygon>();
		for(int i = 0;i<6;i++) {
			sides.add(new Polygon());
		switch(i) {
		case 0: sides.get(i).addPoint(projPoints.get(0).x,projPoints.get(0).y);
		 sides.get(i).addPoint(projPoints.get(1).x,projPoints.get(1).y);
		 sides.get(i).addPoint(projPoints.get(3).x,projPoints.get(3).y);
		 sides.get(i).addPoint(projPoints.get(2).x,projPoints.get(2).y);break;
		case 1: sides.get(i).addPoint(projPoints.get(0).x,projPoints.get(0).y);
		 sides.get(i).addPoint(projPoints.get(1).x,projPoints.get(1).y);
		 sides.get(i).addPoint(projPoints.get(5).x,projPoints.get(5).y);
		 sides.get(i).addPoint(projPoints.get(4).x,projPoints.get(4).y);break;
		case 2: sides.get(i).addPoint(projPoints.get(0).x,projPoints.get(0).y);
		 sides.get(i).addPoint(projPoints.get(2).x,projPoints.get(2).y);
		 sides.get(i).addPoint(projPoints.get(6).x,projPoints.get(6).y);
		 sides.get(i).addPoint(projPoints.get(4).x,projPoints.get(4).y);break;
		case 3: sides.get(i).addPoint(projPoints.get(1).x,projPoints.get(1).y);
		 sides.get(i).addPoint(projPoints.get(3).x,projPoints.get(3).y);
		 sides.get(i).addPoint(projPoints.get(7).x,projPoints.get(7).y);
		 sides.get(i).addPoint(projPoints.get(5).x,projPoints.get(5).y);break;
		case 4: sides.get(i).addPoint(projPoints.get(2).x,projPoints.get(2).y);
		 sides.get(i).addPoint(projPoints.get(3).x,projPoints.get(3).y);
		 sides.get(i).addPoint(projPoints.get(7).x,projPoints.get(7).y);
		 sides.get(i).addPoint(projPoints.get(6).x,projPoints.get(6).y);break;
		case 5: sides.get(i).addPoint(projPoints.get(4).x,projPoints.get(4).y);
		 sides.get(i).addPoint(projPoints.get(5).x,projPoints.get(5).y);
		 sides.get(i).addPoint(projPoints.get(7).x,projPoints.get(7).y);
		 sides.get(i).addPoint(projPoints.get(6).x,projPoints.get(6).y);break;
		}
		}
		return sides;
		//left 0 1 3 2
		//back 0 1 5 4
		//top 0 2 6 4
		//bottom 1 3 7 5
		//front 2 3 7 6
		//right 4 5 7 6
		
		
		
		
	}
	public void drawString(String string, Point proj) {
		g.drawString(string, proj.x, proj.y);
		
	}

	

	
	public ArrayList<Polygon3D> shadeRect3D3(Camera camera, Rect3D rect3d,boolean paste,int[] exempt) {
		return shadeRect3D3(camera,rect3d.x,rect3d.y,rect3d.z,rect3d.w,rect3d.l,rect3d.h,paste,exempt);
	}
	public ArrayList<Polygon3D> shadeRect3D3(Point3D cam, double dis, double ang1, double ang2,double x, double y, double z, double w, double l,double h,int xd,int yd,boolean paste,int[] exempt) {
		Camera camera = new Camera(cam,dis,ang1,ang2,xd*2,yd*2);
		return shadeRect3D3(camera, x, y, z, w, l, h,paste,exempt);
		
	}
	public ArrayList<Polygon3D> shadeRect3D3(Camera camera, double x, double y, double z, double w, double l,double h,boolean paste,int[] exempt) {
		ArrayList<Point3D> points= new ArrayList<Point3D>();
		for(int i = (int)x;i<=(int)x+w;i+=w) {
			for(int k = (int)y;k<=l+(int)y;k+=l) {
				for(int j =(int) z;j<=z+h;j+=h) {
					points.add(new Point3D(i,k,j));	
				}
			}
		}
		ArrayList<Polygon3D> sides= new ArrayList<Polygon3D>();
		for(int i = 0;i<6;i++) {
			sides.add(new Polygon3D());
		switch(i) {
		case 0: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(2));break;
		case 1: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(4));break;
		case 2: sides.get(i).addPoint(points.get(0));
		 sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(6));
		 sides.get(i).addPoint(points.get(4));break;
		case 3: sides.get(i).addPoint(points.get(1));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(5));break;
		case 4: sides.get(i).addPoint(points.get(2));
		 sides.get(i).addPoint(points.get(3));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));break;
		case 5: sides.get(i).addPoint(points.get(4));
		 sides.get(i).addPoint(points.get(5));
		 sides.get(i).addPoint(points.get(7));
		 sides.get(i).addPoint(points.get(6));break;
		}
		}
		ArrayList<Polygon3D> out = new ArrayList<Polygon3D>();
		int count =0;
		for(Polygon3D p :sides) {
			if(exempt[count]==0) {
				out.add(p);
			}
		}
		return out;

		//left 0 1 3 2
		//back 0 1 5 4
		//top 0 2 6 4
		//bottom 1 3 7 5
		//front 2 3 7 6
		//right 4 5 7 6
		
		
		
		
	}
		public ArrayList<PolygonWr> shade(BlockMap b, Camera camera,int chunksize,TCSIndex allShading) {
			ArrayList<PolygonWr> out = new ArrayList<PolygonWr>(); 
			Point3D cam = camera.cam;
			int camX=(int)Math.round(cam.x/b.size);
			int camY=(int)Math.round(cam.y/b.size);
			int camZ=(int)Math.round(cam.z/b.size);
			int halfchunk =(int)Math.round(chunksize/2);
			for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
				for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
			
					
				try {
					for(int z=1;z<=b.map[x][y].length-1;z++) {
						try {
						if((b.map[x][y][z]!=0)&&(!b.encased(x,y,z,allShading)||allShading.get(b.map[x][y][z]).transparent)&&(camera.CanSee(x,y,z,b.size))) {
							for(PolygonWr p:shadeRect3D2(camera, new Rect3D(x*b.size,y*b.size,z*b.size,b.size),false,b.touching(x, y, z,allShading),allShading.get(b.map[x][y][z]).sideColors,b.map[x][y][z])) {
							out.add(p);
							}
							}
						}catch(Exception e) {
							
						}
					}
					}catch(Exception e) {
						
					}
					
					
				}
				
			}
			out.sort(new Comparator<PolygonWr>(){

				@Override
				public int compare(PolygonWr o1, PolygonWr o2) {
					double dist1 = o1.r.distance(camera);
					double dist2 = o2.r.distance(camera);
					if(dist1<dist2) {
						return 1;
					}else if(dist1>dist2) {
						return -1;
					}else if(dist1==dist2) {
						return 0;
					}
					return 0;
				}

			
				
			});
			
			ArrayList<PolygonWr> out2 = new ArrayList<PolygonWr>(); 
			
			for(PolygonWr p:out) {
				if(allShading.get(p.type).Image) {
					int rez = allShading.get(p.type).rez;
		
					try {
						rez/=Math.round(1.25*(p.r.distance(camera)/(50*b.size/4.0)));
					}catch(Exception e){
						
					}
					
					subdivide(p,rez>0?rez:1,out2,allShading.get(p.type).sideImages[p.side]);
				
			
			}else {
				out2.add(p);
			}
			}
		
			
			return out2;
			
		
	}
		
	
		
		private void side(int xd, int yd, int zd,PolygonWr p,int size,Camera camera, ArrayList<PolygonWr> out2, PolygonWr p2, double rez, BufferedImage sideImage) {
		
			Point[][] ps =new Point[(int) (rez+1)][(int) (rez+1)];
			
			for(int i =0;i<=rez*yd;i++) {
			for(int i2 =0;i2<=rez*zd;i2++) {
				for(int i3 =0;i3<=rez*xd;i3++) {
				ps[yd>0?i:i3][zd>0?i2:i3]=p.r.getMoved(xd*((i3-rez/2.0)*size/rez),yd*((i-rez/2.0)*size/rez),zd*((i2-rez/2.0)*size/rez)).project(camera);
				}
		
			}
		}
			for(int i =0;i<rez;i++) {
			for(int i2 =0;i2<rez;i2++) {
			
				Point p1=ps[i][i2];
				Point pp=ps[i+1][i2];
				Point p3=ps[i+1][i2+1];
				Point p4=ps[i][i2+1];
				
			
			//System.out.println("L  :"+L.toString());
			//System.out.println("P  :"+p.toString());
			//System.out.println("");
			if(sideImage!=null) {
				out2.add(new PolygonWr(new Polygon(new int[] {p1.x,pp.x,p3.x,p4.x},new int[] {p1.y,pp.y,p3.y,p4.y},4), p.r,new Color( sideImage.getRGB((int)(i*sideImage.getWidth()/rez), (int) (i2*sideImage.getHeight()/rez))), p.type));
			}else {
			
			out2.add(new PolygonWr(new Polygon(new int[] {p1.x,pp.x,p3.x,p4.x},new int[] {p1.y,pp.y,p3.y,p4.y},4), p.r, p.c, p.type));
			}
			
			//g3.drawCirclePoint(proj,10);
			
			//g3.drawString(""+Math.round(p.x)+","+Math.round(p.y)+","+Math.round(p.z)+"",proj.x,proj.y);
			//g3.drawString(""+Math.round(p.x-cam.x)+","+Math.round(p.y-cam.y)+","+Math.round(p.z-cam.z)+"",proj.x,proj.y);
			//System.out.println(""+Math.round(proj.x)+","+Math.round(proj.y));
	
				}
		
		}
			
		}
		public static void fit(BufferedImage b2, double rez3) {
				BufferedImage buf = new BufferedImage((int)rez3,(int)rez3,1);
				for(double i = 0;i<b2.getHeight();i+=b2.getHeight()/rez3) {
					for(double k = 0;k<b2.getWidth();k+=b2.getWidth()/rez3) {
						buf.setRGB((int)Math.round(k/(b2.getHeight()/rez3)), (int)Math.round(i/(b2.getHeight()/rez3)),b2.getRGB((int)Math.round(k),(int)Math.round(i)));
					}
				}
				b2=buf;
				
			}
		public void drawLine(double d, double e, double f, double g2) {
			drawLine((int)d,(int)e,(int)f,(int)g2);
			
		}
		public void subdivide(PolygonWr po,double amount, ArrayList<PolygonWr> out2,BufferedImage sideImage) {
			Point p=new Point(po.p.xpoints[0],po.p.ypoints[0]);
			Point pp=new Point(po.p.xpoints[1],po.p.ypoints[1]);
			Point p3=new Point(po.p.xpoints[2],po.p.ypoints[2]);
			Point p4=new Point(po.p.xpoints[3],po.p.ypoints[3]);
		
			double dx=(pp.x-p.x)/amount;
			//System.out.println(dx);
			double dy=(pp.y-p.y)/amount;
		//	System.out.println(dy);
			double dx2=(p3.x-p4.x)/amount;
		//	System.out.println(dx2);
			double dy2=(p3.y-p4.y)/amount;
		//	System.out.println(dy2);
			double dxdx=(dx2-dx)/amount;
			double dydy=(dy2-dy)/amount;
		
			double dx3=(p4.x-p.x)/amount;
			//System.out.println(dx);
			double dy3=(p4.y-p.y)/amount;
		//	System.out.println(dy);
			Point[][] points = new Point[(int) (amount+1)][(int) (amount+1)];
			for(int i =0;i<=amount;i++) {
			for(int i2 =0;i2<=amount;i2++) {
			points[i][i2]=new Point((int)(p.x+(dx)*i+(dx3*i2)+(dxdx*i*i2)),(int)(p.y+(dy)*i+dy3*i2+dydy*i2*i));
			}
		}
			
			for(int x =0;x<amount;x++) {
				for(int y =0;y<amount;y++){
					
					Point p5=points[x][y];
					Point p6=points[x+1][y];
					Point p7=points[x+1][y+1];
					Point p8=points[x][y+1];
					if(sideImage!=null) {
						out2.add(new PolygonWr(new Polygon(new int[] {p5.x,p6.x,p7.x,p8.x},new int[] {p5.y,p6.y,p7.y,p8.y},4), po.r,new Color( sideImage.getRGB((int)(y*sideImage.getWidth()/amount), (int) (x*sideImage.getHeight()/amount))), po.type));
					}else {
						
					
					out2.add(new PolygonWr(new Polygon(new int[] {p5.x,p6.x,p7.x,p8.x},new int[] {p5.y,p6.y,p7.y,p8.y},4), po.r, po.c, po.type));
					}
				}
			}
			
		}
		
		public Polygon[][] subdivide(Polygon po,double amount) {
			Point p=new Point(po.xpoints[0],po.ypoints[0]);
			Point pp=new Point(po.xpoints[1],po.ypoints[1]);
			Point p3=new Point(po.xpoints[2],po.ypoints[2]);
			Point p4=new Point(po.xpoints[3],po.ypoints[3]);
		
			double dx=(pp.x-p.x)/amount;
			//System.out.println(dx);
			double dy=(pp.y-p.y)/amount;
		//	System.out.println(dy);
			double dx2=(p3.x-p4.x)/amount;
		//	System.out.println(dx2);
			double dy2=(p3.y-p4.y)/amount;
		//	System.out.println(dy2);
			double dxdx=(dx2-dx)/amount;
			double dydy=(dy2-dy)/amount;
		
			double dx3=(p4.x-p.x)/amount;
			//System.out.println(dx);
			double dy3=(p4.y-p.y)/amount;
		//	System.out.println(dy);
			Point[][] points = new Point[(int) (amount+1)][(int) (amount+1)];
			for(int i =0;i<=amount;i++) {
			for(int i2 =0;i2<=amount;i2++) {
			points[i][i2]=new Point((int)(p.x+(dx)*i+(dx3*i2)+(dxdx*i*i2)),(int)(p.y+(dy)*i+dy3*i2+dydy*i2*i));
			}
		}
			Polygon[][] out = new Polygon[(int) (amount+1)][(int) (amount+1)];
			for(int x =0;x<amount;x++) {
				for(int y =0;y<amount;y++){
					
					Point p5=points[x][y];
					Point p6=points[x+1][y];
					Point p7=points[x+1][y+1];
					Point p8=points[x][y+1];
					
						out[x][y]=(new Polygon(new int[] {p5.x,p6.x,p7.x,p8.x},new int[] {p5.y,p6.y,p7.y,p8.y},4));
					
				}
			}
			return out;
			
		}
		public PolygonWr[][] subdivide(Polygon po,double amount,BufferedImage sideImage, int dex, int dey) {
			Point p=new Point(po.xpoints[0],po.ypoints[0]);
			Point pp=new Point(po.xpoints[1],po.ypoints[1]);
			Point p3=new Point(po.xpoints[2],po.ypoints[2]);
			Point p4=new Point(po.xpoints[3],po.ypoints[3]);
		
			double dx=(pp.x-p.x)/amount;
			//System.out.println(dx);
			double dy=(pp.y-p.y)/amount;
		//	System.out.println(dy);
			double dx2=(p3.x-p4.x)/amount;
		//	System.out.println(dx2);
			double dy2=(p3.y-p4.y)/amount;
		//	System.out.println(dy2);
			double dxdx=(dx2-dx)/amount;
			double dydy=(dy2-dy)/amount;
		
			double dx3=(p4.x-p.x)/amount;
			//System.out.println(dx);
			double dy3=(p4.y-p.y)/amount;
		//	System.out.println(dy);
			Point[][] points = new Point[(int) (amount+1)][(int) (amount+1)];
			for(int i =0;i<=amount;i++) {
			for(int i2 =0;i2<=amount;i2++) {
			points[i][i2]=new Point((int)(p.x+(dx)*i+(dx3*i2)+(dxdx*i*i2)),(int)(p.y+(dy)*i+dy3*i2+dydy*i2*i));
			}
		}
			PolygonWr[][] out = new PolygonWr[(int) (amount+1)][(int) (amount+1)];
			for(int x =0;x<amount;x++) {
				for(int y =0;y<amount;y++){
					
					Point p5=points[x][y];
					Point p6=points[x+1][y];
					Point p7=points[x+1][y+1];
					Point p8=points[x][y+1];
					if(sideImage!=null) {
						out[x][y]=new PolygonWr(new Polygon(new int[] {p5.x+dex,p6.x+dex,p7.x+dex,p8.x+dex},new int[] {p5.y+dey,p6.y+dey,p7.y+dey,p8.y+dey},4),new Color( sideImage.getRGB((int)(y*sideImage.getWidth()/amount), (int) (x*sideImage.getHeight()/amount))));
					}else {
					
						out[x][y]=new PolygonWr(new Polygon(new int[] {p5.x+dex,p6.x+dex,p7.x+dex,p8.x+dex},new int[] {p5.y+dey,p6.y+dey,p7.y+dey,p8.y+dey},4));
					}
					
					
				}
			}
			return out;
			
		}
		public void fillImage(Polygon p, BufferedImage img, int i) {
			fillImage(p,  img,i,0,0);
			
		}
		public void fillImage(Polygon p4, BufferedImage img, int i, int j, int k) {
			 PolygonWr[][] polys= subdivide(p4,i,img,j,k);
			 for(int x =0;x<i;x++) {
					for(int y =0;y<i;y++){
						setColor(polys[x][y].c);
						fill(polys[x][y].p);
					}
			 }
			
		}
		public void drawImage(Polygon p, BufferedImage img, int i) {
			drawImage(p,  img,i,0,0);
			
		}
		public void drawImage(Polygon p4, BufferedImage img, int i, int j, int k) {
			 PolygonWr[][] polys= subdivide(p4,i,img,j,k);
			 for(int x =0;x<i;x++) {
					for(int y =0;y<i;y++){
						setColor(polys[x][y].c);
					for(int n =0;n<polys[x][y].p.npoints;n++) {
						drawPoint(polys[x][y].p.xpoints[n],polys[x][y].p.ypoints[n]);
					}
					}
			 }
			
		}
		public void drawCirclePoint3D(Point3D point3d, Camera camera,int radius) {
		drawCirclePoint(point3d.project(camera),radius);
			
		}
		public ArrayList<PolygonWr> shadeRect3D2(Camera camera, double x, double y, double z, double w, double l, double h) {
			// TODO Auto-generated method stub
			return shadeRect3D2(camera, x, y, z, w, l, h, false, new int[] {0,0,0,0,0,0}, new Color[] {getColor(),getColor(),getColor(),getColor(),getColor(),getColor()}, -1);
		}
		public void drawRect(double x, double y, double w, double h) {
			
drawRect((int)x,(int)y,(int)w,(int)h);
			
		}
		public void drawCirclePoint(double x, double y, int s) {
			drawCirclePoint((int)x,(int)y,s);
			
		}
	
}
