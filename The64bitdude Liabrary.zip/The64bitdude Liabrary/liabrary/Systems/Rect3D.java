package Systems;

import java.util.ArrayList;

public class Rect3D {

	public double x;
	public double y;
	public double z;
	public double w;
	public double l;
	public double h;

	public Rect3D(double x, double y, double z, double w, double l, double h) {
		this.x=x;
		this.y=y;
		this.z=z;
		this.w=w;
		this.l=l;
		this.h=h;
	}
	public Rect3D(double x, double y, double z, double s) {
		this.x=x;
		this.y=y;
		this.z=z;
		this.w=s;
		this.l=s;
		this.h=s;
	}
	public Point3D calcAveragePoint() {
		
		return new Point3D(x+w/2,y+l/2,z+h/2);
		
	}
	public double distance(Camera camera) {
		return calcAveragePoint().distance(camera);
	}
	public ArrayList<Point3D> getPoints() {
		ArrayList<Point3D> out = new ArrayList<Point3D>();
		out.add(new Point3D((int)x,(int)y,(int)z));
		out.add(new Point3D((int)x+h,(int)y,(int)z));
		out.add(new Point3D((int)x+h,(int)y+h,(int)z));
		out.add(new Point3D((int)x+h,(int)y+h,(int)z+h));
		out.add(new Point3D((int)x,(int)y+h,(int)z+h));
		out.add(new Point3D((int)x,(int)y,(int)z+h));
		out.add(new Point3D((int)x,(int)y+h,(int)z));
		return out;
		
	}

}
