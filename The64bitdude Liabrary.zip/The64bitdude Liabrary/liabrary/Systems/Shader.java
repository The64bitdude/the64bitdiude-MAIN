package Systems;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class Shader {
	Color[] sideColors;
	public BufferedImage[] sideImages;
	boolean transparent;
	public boolean Image=false;
	public int rez = 1;
	public Shader() {
		this.transparent=false;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		setAll(new Color(0,0,0));
		
	}
	public Shader(Color c) {
		this.transparent=false;
		sideImages = new BufferedImage[8];
		sideColors = new Color[8];
		setAll(c);
	}
	public Shader(Color c,BufferedImage b, int rez) {
		this.transparent=false;
		sideImages = new BufferedImage[8];
		setALL(b);
		this.rez = rez;
		sideColors = new Color[8];
		setAll(c);
		Image = true;
	}
	
	public Shader(Color c,BufferedImage[] b,int rez) {
		this.transparent=false;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		sideImages=b;
		this.rez = rez;
		Image = true;
		setAll(c);
	}
	public Shader(Color c,boolean transparent) {
		this.transparent=transparent;
		sideColors = new Color[8];
		sideImages = new BufferedImage[8];
		setAll(c);
	}
	public Shader(Color[] Sides) {
		
		this.transparent=false;
		sideImages = new BufferedImage[8];
		sideColors = Sides;
	}
	public void setAll(Color c) {
	for(int i = 0;i<8;i++) {
		sideColors[i]=c;
	}
	}
	public void setALL(BufferedImage b) {
		for(int i = 0;i<8;i++) {
			sideImages[i]=b;
		}
		
	}
	public void setWest(Color c) {
		sideColors[0]=c;
	}
	public void setSouth(Color c) {
		sideColors[1]=c;
	}
	public void setUp(Color c) {
		sideColors[2]=c;
	}
	public void setDown(Color c) {
		sideColors[3]=c;
	}
	public void setNorth(Color c) {
		sideColors[4]=c;
	}
	public void setEast(Color c) {
		sideColors[5]=c;
	}
	public void shade(double sunAngle) {
		shade(0,(sunAngle > Math.toRadians(90)?0.25:(0.25+Math.abs(0.75*Math.cos(sunAngle)))));
		shade(1,0.5);
		shade(2,Math.abs(0.65+0.35*Math.sin(sunAngle)));
		shade(3,0.2);
		shade(4,0.5);
		shade(5,(sunAngle < Math.toRadians(90)?0.25:(0.25+Math.abs(0.75*Math.cos(sunAngle)))));
	}
	public void shade(int side,double amount) {
		sideColors[side] =new Color((int) (sideColors[side].getRed()*amount),(int)(sideColors[side].getGreen()*amount),(int)(sideColors[side].getBlue()*amount),sideColors[side].getAlpha());
	}
	//west 0
	//south1
	//up   2
	//down 3
	//north4
	//east 5
		
		
	

}
