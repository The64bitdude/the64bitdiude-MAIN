package Systems;

import java.awt.Point;

import Physics.Vector3D;

public class Point3D extends Point{
	public double x;
	public double y;
	public double z;
	public Point3D() {
		this(0,0,0);
	}
	public Point3D(int x,int y, int z) {
		this.x=(double)x;
		this.y=(double)y;
		this.z=(double)z;
		
	}
	
	public Point3D(double r,double ang1,double ang2) {
		
		this.x=r*Math.cos(Math.toRadians(ang2))*Math.cos(Math.toRadians(ang1));
		this.y=r*Math.cos(Math.toRadians(ang2))*Math.sin(Math.toRadians(ang1));
		this.z=r*Math.sin(Math.toRadians(ang2));
		
		if((float)distance(0.0,0.0,0.0)!=(float)r) {
			System.out.println("FAIL "+distance(0.0,0.0,0.0)+" != "+r);
		}
	}
	public void translate(double anga, double angb) {
		double r = getRadius();
		double ang2 = getAngle2()+angb;
		double ang1 = getAngle1()+anga;
		this.x=r*Math.cos(Math.toRadians(ang2))*Math.cos(Math.toRadians(ang1));
		this.y=r*Math.cos(Math.toRadians(ang2))*Math.sin(Math.toRadians(ang1));
		this.z=r*Math.sin(Math.toRadians(ang2));
		
		if((float)distance(0.0,0.0,0.0)!=(float)r) {
			System.out.println("FAIL "+distance(0.0,0.0,0.0)+" != "+r);
		}
		
	}
	public void translate(double ang1, double ang2,Point3D p) {
		double r=distance(p);
		this.x=r*Math.cos(Math.toRadians(ang2))*Math.cos(Math.toRadians(ang1))+p.x;
		this.y=r*Math.cos(Math.toRadians(ang2))*Math.sin(Math.toRadians(ang1))+p.y;
		this.z=r*Math.sin(Math.toRadians(ang2))+p.z;
		
		
		
	}
	public double getRadius() {
		return distance(0.0,0.0,0.0);
	}
	public double getAngle1Degrees() {
		return Math.toDegrees(getAngle1());
	
	}
	public double getAngle1() {
		double r = getRadius();
		double ang2 = getAngle2();
		return Math.acos((x/r)/Math.cos(ang2));
	
	}
	public double getAngle1(Point3D p) {
		double r=distance(p);
		double ang2 = getAngle2(p);
		return Math.acos(((x-p.x)/r)/Math.cos(ang2));
	}
	public double getAngle1(Point3D p,double ang2) {
		double r=distance(p);
		return Math.acos(((x-p.x)/r)/Math.cos(ang2));
	}
	public double getAngle1n2(Point3D p,double dxy) {
		return Math.acos((x-p.x)/dxy);
	}
	public double getAngle2(Point3D p) {
		double r=distance(p);
		return Math.asin((z-p.z)/r);
		
	}
	public double getAngle2(Point3D p,double r) {
		return Math.asin((z-p.z)/r);
		
	}
	public double getAngle2Degrees() {
		return Math.toDegrees(getAngle2());
		
	}
	public double getAngle2() {
		double r = getRadius();
		return Math.asin(z/r);
		
	}
	//testing
	/*	double DXd =(Math.tan(ang1)*Math.cos(ang2)+(1/Math.tan(ang1))*(1/Math.cos(ang2)));
	double DXx = (((1/Math.tan(ang1))*(1/Math.cos(ang2))*dy)+dz)/DXd;
	double DXy = ((Math.tan(ang1)*Math.cos(ang2)*dz)+dy)/DXd;
	double DYd =(Math.tan(ang2)*Math.cos(ang1)+(1/Math.tan(ang2))*(1/Math.cos(ang1)));
	double DYx = (((1/Math.tan(ang2))*(1/Math.cos(ang1))*dy)+dx)/DYd;
	double DYy = ((Math.tan(ang2)*Math.cos(ang1)*dx)+dy)/DYd;
	double DX = Math.sqrt(DXx*DXx+DXy*DXy);
	double DY = Math.sqrt(DYx*DYx+DYy*DYy);*/
	
	public PointD project(Camera camera) {
		
	
	

	/*	double dz=doz;
		if(doy<0) {
			ang1*=-1;
			dz*=-1;
		}
		
		double dxy=Math.sqrt(dox*dox+doy*doy);
		double angle1 = Math.acos(dox/dxy)+ang1;
		double dx=dxy*Math.cos(angle1);
		double dy=dxy*Math.sin(angle1);
		
		
		double RB =(dy*Math.cos(ang2)+dz*Math.sin(ang2));
		
		
		double new2X =paneY*(((dx/RB)));
		if(doy<0) {
			new2X*=-1;
		}
		double new2Y =paneY*Math.sqrt(((dz)*(dz)+(dy)*(dy))/(RB*RB));
		if(doz < 0) {
			new2Y*=-1;
		}
		double angle3 = Math.atan(dy/dz)+ang2;
		double distyx = new2Y*Math.sin(angle3);
		double distY = new2Y*Math.cos(angle3);
		if(distyx<0) {
			new2X*=distyx;
			distY*=-distyx;
		}
		
		double newX = new2X+x;
		
		double newY = distY+y;
		OLD VERSON 11th grade
		*/
		/*
		 * 
		 * 
		 */
	
		
		Vector3D posV=new Vector3D(this.x-camera.cam.x, this.y-camera.cam.y,camera.cam.z-this.z);
		double distz = camera.camV.dot(posV);
		double newX=0;
		double newY=0;
	if(distz>0) {
		double pane=camera.panel/(distz);
		
	newX=(camera.SX.dot(posV))*pane+camera.screenWidth/2;
	newY=(camera.SY.dot(posV))*pane+camera.screenHeight/2;
	}else {
		
		double pane=camera.panel*-(distz);
		
		newX=(camera.SX.dot(posV))*pane+camera.screenWidth/2;
		newY=(camera.SY.dot(posV))*pane+camera.screenHeight/2;
	}
		
	
		
		
		return new PointD(new Point((int)newX,(int)newY),distz);
		
	}
	public Point fixPoint(Camera camera,Point3D B) {
		
		PointD b =B.project(camera);
		PointD a = new Point3D().setLocation(2*B.x-x,2*B.y-y,2*B.z-z).project(camera);
		PointD a2 = new Point3D().setLocation(3*B.x-2*x,3*B.y-2*y,3*B.z-2*z).project(camera);
			return new Point(3*b.x-3*a.x+a2.x,3*b.y-3*a.y+a2.y);
		
	
		
	}

	public double getX() {
        return x;
}
	public double getY() {
        return y;
}
	public double getZ() {
	        return z;
	}
	public static double distance(double x1, double y1,double z1,
            double x2, double y2,double z2)
	{
		x1 -= x2;
		y1 -= y2;
		z1 -= z2;
		return Math.sqrt((x1 * x1) + (y1 * y1) + (z1 * z1));
	}
	public void move(double ang1,double ang2) {
		double r = getRadius();
		this.x=r*Math.cos(Math.toRadians(ang2))*Math.cos(Math.toRadians(ang1));
		this.y=r*Math.cos(Math.toRadians(ang2))*Math.sin(Math.toRadians(ang1));
		this.z=r*Math.sin(Math.toRadians(ang2));
		
		if((float)distance(0.0,0.0,0.0)!=(float)r) {
			System.out.println("FAIL "+distance(0.0,0.0,0.0)+" != "+r);
		}
	}
	public static double distance(Point3D p1,Point3D p2)
	{
		return distance(p1.x,p1.y,p1.z,p2.x,p2.y,p2.z);
	}
	public double distance(Point3D p2)
	{
		return distance(x,y,z,p2.x,p2.y,p2.z);
	}
	public double distance(double x2,double y2,double z2)
	{
		return distance(x,y,z,x2,y2,z2);
	}
	public void setLocation(Point3D p) {
		setLocation(p.x,p.y,p.z);
	}
	 public Point3D setLocation(double x, double y,double z) {
	        this.x = x;
	        this.y = y;
	        this.z = z;
	        return this;
	    }
	 public Point3D translate(double dx, double dy,double dz) {
	        this.x += dx;
	        this.y += dy;
	        this.z += dz;
	        
	        return this;
	    }
	 public boolean equals(Object obj) {
	        if (obj instanceof Point3D) {
	            Point3D pt = (Point3D)obj;
	            return ((x == pt.x) && (y == pt.y))&&(z==pt.z);
	        }
	        return super.equals(obj);
	    }
	 public Point3D scale(int scale) {
			return new Point3D((int)(x/scale),(int)(y/scale),(int)(z/scale));
		}
	 public String toString() {
	        return getClass().getName() + "[x=" + x + ",y=" + y + ",z="+ z +"]" +"\n POLAR: "+"[r=" + getRadius() + ",angle1=" + getAngle1() + ",angle2="+ getAngle1() +"]";
	    }
	 public String toString2() {
	        return getClass().getName() + "[x=" + x + ",y=" + y + ",z="+ z +"]";
	    }
	
	
	public double distance(Camera camera) {
		return distance(camera.cam);
		
	}
	public Point3D getMoved(double d, double e, double f) {
		// TODO Auto-generated method stub
		return new Point3D((int)(x+d),(int)(y+e),(int)(z+f));
	}
	public void add(Point3D p12) {
		this.x+=p12.x;
		this.y+=p12.y;
		this.z+=p12.z;

		
	}
	public void div(double d) {
		this.x/=d;
		this.y/=d;
		this.z/=d;
		
	}
	
	
	 
}
