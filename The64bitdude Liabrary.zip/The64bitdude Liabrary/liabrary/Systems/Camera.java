package Systems;

import java.awt.Rectangle;

import Physics.Vector3D;

public class Camera {

	private double paneSize;
	public double FOV;
	public double panel;
	public Point3D cam;
	public double angle1 = 0;
	public double angle2 = 0;
	public double screenHeight;
	public double screenWidth;
	public Vector3D SX;
	public Vector3D camV;
	public Vector3D SY;
	

	public Camera(double fov,double screenWidth,double screenHeight,Point3D p,double a1,double a2) {
		this.screenWidth=screenWidth;
		this.screenHeight = screenHeight;
		FOV = fov;
		paneSize = this.screenWidth;
		if(this.screenWidth>this.screenHeight) {
		paneSize = this.screenHeight;
		}
		panel = (paneSize*(Math.tan(Math.toRadians((FOV/2)))/2));
		cam = p;
		angle1=a1;
		angle2=a2;
		
	}

	public Camera(Point3D p, double panel, double a1, double a2, double screenWidth, double screenHeight) {
		this.screenWidth=screenWidth;
		this.screenHeight=screenHeight;
		this.panel=panel;
		paneSize = this.screenWidth;
		if(this.screenWidth>this.screenHeight) {
		paneSize = this.screenHeight;
		}
		FOV = Math.toDegrees(Math.atan(this.panel/paneSize)*2)*2;
		cam = p;
		
	}

	public double getPanel() {
		return panel;
	}

	public void setPanel(double panel) {
		this.panel = panel;
	}
	
	public boolean CanSee(int x, int y, int z, int size) {
		int s2 = (int)((FOV/2)*(screenWidth/500*size/2.0)/70);
		Point3D point =new Point3D(x*size+s2,y*size+s2,z*size+s2);
		size*=(FOV*1.25)/70;
		int s3 = (int) (screenWidth*4);
		double dist = point.distance(this);
		if(dist >20*size) {
			s3 = (int) (s2/2.0);
		}else if(dist >12*size) {
			s3 = s2;
		}else if(dist >10*size) {
			s3 = (int) (s2+s2/2.0);
		}else if(dist >4*size) {
			s3 =(int) (3*s2);
		}else if(dist >2*size) {
			s3 =(int) (6*s2);
		}else if(dist >size) {
			s3 =(int) (screenWidth*2);
		}
		return (new Rectangle(-s3,-s3,(int)screenWidth+2*s3,(int)screenHeight+2*s3).contains(point.project(this)));
	}

	public void updateV() {
		camV=new Vector3D(Math.sin(angle1)*Math.cos(-angle2),Math.cos(angle1)*Math.cos(-angle2),Math.sin(-angle2));
		SX=new Vector3D(Math.cos(angle1),-Math.sin(angle1),0);
		SY=camV.cross(SX);
	camV.setmag();
		
	}

	public Vector3D getcamV() {
		// TODO Auto-generated method stub
		return camV;
	}

	public Vector3D getSX() {
		// TODO Auto-generated method stub
		return SX;
	}

	public Vector3D getSY() {
		// TODO Auto-generated method stub
		return SY;
	}
}
