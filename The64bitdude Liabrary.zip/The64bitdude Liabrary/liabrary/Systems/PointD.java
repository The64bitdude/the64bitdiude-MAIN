package Systems;

import java.awt.Point;

public class PointD extends Point {

	
	private double dist;

	public PointD(Point p,double dist) {
		this.setLocation(p);
		this.setDist(dist);
	}

	public double getDist() {
		return dist;
	}

	public void setDist(double dist) {
		this.dist = dist;
	}

	
	
}
