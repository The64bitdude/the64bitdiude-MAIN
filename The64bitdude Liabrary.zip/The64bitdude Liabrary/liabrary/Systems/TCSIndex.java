package Systems;

import java.awt.Color;
import java.util.HashMap;

public class TCSIndex {
	public HashMap<Integer,Shader> type;
	
	/**
	 * type color shader
	 * uses the number to define what block it represents and the color of each side
	 */
	public TCSIndex() {
		type = new HashMap<Integer,Shader>();
		
	}
	public void put(int index,Shader c) {
		type.put(index,c);
	}
	public Shader get(int index) {
		return type.get(index);
	}

}
