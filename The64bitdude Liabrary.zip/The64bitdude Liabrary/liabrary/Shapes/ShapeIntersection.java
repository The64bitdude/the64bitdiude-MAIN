package Shapes;

import java.awt.Shape;

public class ShapeIntersection {
	public boolean intersects(Shape A,Shape B){
		for(int x = A.getBounds().x;x<A.getBounds().x+A.getBounds().width;x++) {
			for(int y = A.getBounds().y;x<A.getBounds().y+A.getBounds().height;y++) {
				if(A.contains(x, y)&&B.contains(x, y)) {
					return true;
				}
			}
		}
		return false;
		
	}
}
