package Shapes;

import java.awt.Polygon;

import Systems.Polygon3D;

public class Sphere extends Polygon3D{

	public Sphere(double x,double y,double z,double radius,double verticies) {
		super();
		for(double a = 0;a<=360;a+=360.0/verticies) {
		for(double b = 0;b<=360;b+=360.0/verticies) {
			addPoint((radius*Math.cos(Math.toRadians(a))*Math.sin(Math.toRadians(b))),(radius*Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(b))),(radius*Math.sin(Math.toRadians(a))));
		}
		}
	
	}


}
