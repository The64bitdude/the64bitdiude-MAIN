package AI;

import java.awt.Graphics2D;

public class NeuralNetWork {
	Layer[] layers;
	public NeuralNetWork(int[] numNodes,int outputNodes,int inputNodes) {
		layers=new Layer[numNodes.length+2];
		for(int i =0;i<numNodes.length;i++) {
			layers[i+1]=new Layer(numNodes[i]);
		}
		layers[0]=new Layer(inputNodes);
		layers[layers.length-1]=new Layer(outputNodes);
		setupNodes();
	}
	public void learn(double learnAmount,double[]inputs,double[] expectedOutputs,int iterations,double leniency) {
		for(int i3 =0;i3<iterations;i3++) {
		for(int i =1;i<layers.length;i++) {
			for(int i2 =0;i2<layers[i].nodes.length;i2++) {
				double previousCost = Cost(inputs,expectedOutputs);
				layers[i].nodes[i2].randomize(learnAmount);
				if(Cost(inputs,expectedOutputs)>previousCost+leniency) {
					layers[i].nodes[i2].revert();
				}
			}
			}
			
		}
	}
	public void setupNodes() {
		for(int i =1;i<layers.length;i++) {
			for(int i2 =0;i2<layers[i].nodes.length;i2++) {
				layers[i].nodes[i2]= new Node(layers[i-1].nodes.length);
			}
		}
	}
	public double Cost(double[] inputs,double[]expectedOutputs) {
		double[] outputs = GetOut(inputs);
		double cost = 0;
		for(int i =0;i<outputs.length;i++) {
			cost+=cost(outputs[i],expectedOutputs[i]);
		}
		return cost;
	}
public double cost(double val ,double expected) {
	double error=val-expected;
	return error*error;
}
	public  double[] GetOut(double[] inputs) {
		layers[0].setVals(inputs);
		for(int i =1;i<layers.length;i++) {
			for(int i2 =0;i2<layers[i].nodes.length;i2++) {
			layers[i].nodes[i2].getValue(layers[i-1].getVals());
			}
		}
		return layers[layers.length-1].getVals();
	}
	public void ToDraw(Graphics2D g2,int size) {
		for(int i =0;i<layers.length;i++) {
			for(int i2 =0;i2<layers[i].nodes.length;i2++) {
				g2.fillRect(i*2*size, i2*2*size, size, size);
				if(i!=0) {
					for(int i3=0;i3<layers[i].nodes[i2].weights.length;i3++) {
						g2.drawLine(i*2*size+size/2, i2*2*size+size/2, (i-1)*2*size+size/2, i3*2*size+size/2);
					}
				}
			}
		}
		
	}
}
