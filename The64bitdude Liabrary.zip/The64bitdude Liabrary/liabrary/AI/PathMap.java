package AI;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PathMap {
	public int[][] map;
	int currentX = 0;
	int currentY = 0;
	public PathMap(int width,int height) {
		map = new int[width+1][height+1];
		for(int x = 0;x<map.length;x++) {
			for(int y = 0;y<map[x].length;y++) {
				if(x==0||y==0||x==map.length-1||y==map[x].length-1) {
				map[x][y]=-1;
				}else {
				map[x][y]=0;
				}
			}
		}
	}
	public void generate(int x1,int y1) {
		int count = 0;
		
		for(int x =0;x<map.length;x++) {
			for(int y =0;y<map[x].length;y++) {
			if(map[x][y]!=-1) {
				map[x][y]=0;
			}
			}
		}
		try {
		map[x1][y1]=1;
		}catch(Exception e) {
			
		}
		boolean done = false;
		while(!done) {
			
		for(int x =0;x<map.length;x++) {
			for(int y =0;y<map[x].length;y++) {
				
				if(map[x][y]!=0&&map[x][y]!=-1) {
					
					
					try {
					switch((int)(0)) {	
					case 0 :try {if(map[x+1][y]==0||map[x+1][y] > map[x][y]) {
					map[x+1][y]=map[x][y]+1;
				}}catch(Exception e){
					
				};
					
					case 1 :	try {if(map[x-1][y]==0||map[x-1][y] > map[x][y]) {
					map[x-1][y]=map[x][y]+1;
				}}catch(Exception e){
					
				};

					case 2 :		try {if(map[x][y+1]==0||map[x][y+1] > map[x][y]) {
					map[x][y+1]=map[x][y]+1;
				}}catch(Exception e){
					
				};
			
				
					case 3 :	try {if(map[x][y-1]==0||map[x][y-1] > map[x][y]) {
					map[x][y-1]=map[x][y]+1;
				}}catch(Exception e){
					
				};
					}
					}catch(Exception e){
						
					}
				}
				
			}
		}
			
		done=true;
		count++;
		for(int x = 0;x<map.length;x++) {
			for(int y = 0;y<map[x].length;y++) {
				if(map[x][y]==0) {
					done=false;
				}else if(count > map.length*map.length) {
					done=true;
				}
			}
		}
		
		}
		
	}
			
	public Path findPath(int x1,int y1,int x2,int y2) {

		ArrayList<Point> path = new ArrayList<Point>();
	try {
		map[x1][y1]=1;
	}catch(Exception e) {
		
	}
		if(x1!=currentX||y1!=currentY) {
			generate(x1,y1);
			currentX=x1;
			currentY=y1;
		}
		int cx=x2;
		int cy=y2;
		try {
		for(int i = map[x2][y2];i>=1;i--) {
			try {
			if(map[cx+1][cy]==i-1) {
				path.add(new Point(cx,cy));
				cx = cx+1;
				
			}
			}catch(Exception e) {
				
			}
			try {
			if(map[cx-1][cy]==i-1) {
				path.add(new Point(cx,cy));
				cx = cx-1;
				
			}
		}catch(Exception e) {
			
		}
			try {
			if(map[cx][cy+1]==i-1) {
				path.add(new Point(cx,cy));
			
				cy = cy+1;
			}
			
	}catch(Exception e) {
		
	}
			try {
			if(map[cx][cy-1]==i-1) {
				path.add(new Point(cx,cy));
				
				cy = cy-1;
			}
}catch(Exception e) {
	
}
		}
		}catch(Exception e) {
			
		}
		path.add(new Point(x1,y1));
		Collections.reverse(path);
		
		return new Path(path);
		
	}
	public void setOBS(int x,int y,boolean type) {
		try {
		map[x][y]=type?-1:0;
		}catch(Exception e) {
			
		}
	}
	public void reset(int x1,int y1) {
		for(int x = 0;x<map.length;x++) {
			for(int y = 0;y<map[x].length;y++) {
				if(x==0||y==0||x==map.length-1||y==map[x].length-1) {
				map[x][y]=-1;
				}else {
				map[x][y]=0;
				}
			}
		}
		generate(x1,y1);
	}
}
