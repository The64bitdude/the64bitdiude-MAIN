package AI;

public class Node {
	public double[] weights;
	public double bias;
	public double val=0;
	private double oldbias;
	private double[] oldweights;
	public Node(int numWeights) {
	this.weights=new double[numWeights];
	this.oldweights = new double[numWeights];
	}
	public double getValue(double[] nodeVals) {
		double sum =0;
		for(int i = 0;i< weights.length;i++) {
			sum+=Math.max(0,weights[i]*nodeVals[i]+bias);
		}
		val=sum;
		return sum;
	}
	
	public void randomize() {
		for(int i =0;i<weights.length;i++) {
		weights[i]=(Math.random()*2-1)/Math.sqrt(weights.length);
		}
		bias=(Math.random()*2-1)/Math.sqrt(weights.length);
	}
	public void randomize(double learnAmount) {
		
		for(int i =0;i<weights.length;i++) {
			oldweights[i] = weights[i];
			weights[i]+=learnAmount*(Math.random()*2-1)/Math.sqrt(weights.length);
			}
		oldbias = bias;
		
		bias+=learnAmount*(Math.random()*2-1)/Math.sqrt(weights.length);
		
	}
	public void revert() {
		for(int i =0;i<weights.length;i++) {
			weights[i] = oldweights[i];
			
			}
		bias = oldbias;
		
	}
	
}
