package runandImplement;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;

import Physics.PhysicsObject3D;
import Physics.PhysicsSystem;
import Screens.RefreshScreen;
import Screens.RefreshScreen3D;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.PolygonWr;

public class refreshS3D {
	
	

	public static void main(String[] args) {
		new RefreshScreen3D(500,500,Color.BLACK,60,3,70) {

			private PhysicsObject3D bob;
			@Override
			public void Update() {
				defaultCameraMovement(4,false);
				bob.runNextTime3D(1/currentFPS);
			
				bob.calcA();
			
				
			}

			@Override
			public ArrayList<PolygonWr> calcPaint(Graphics3D g3) {
				ArrayList<PolygonWr> out =new ArrayList<PolygonWr>();
				g3.setColor(Color.WHITE);
				
				out.addAll(g3.shadeRect3D2(camera,bob.prevPoint.x,bob.prevPoint.y,bob.prevPoint.z,50,50,50));
				g3.setColor(Color.GREEN);
				
				
			
				return out;
			}

			@Override
			public void drawFrame(Graphics3D g3) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
			
			PhysicsSystem sys;
			@Override
			public void initialize() {
				sys=new PhysicsSystem(2,2,2);
				sys.objects[0][0][0]=new PhysicsObject3D(100);
				sys.objects[1][0][0]=new PhysicsObject3D(100);
				bob=sys.TorDia();
				bob.addForce(00,00,bob.mass*10);
			}

			
			
		};

	}

}
