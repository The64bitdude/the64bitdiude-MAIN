package runandImplement;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;

import javax.imageio.ImageIO;

import javax.swing.JFrame;


import ImageMinipulation.ImageEditor;
import Screens.RefreshScreen;
import Systems.BlockMap;
import Systems.Camera;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.Polygon3D;
import Systems.PolygonWr;
import Systems.Rect3D;
import Systems.Shader;
import Systems.TCSIndex;



public class sim3D3GridClient {

	public static void main(String[] args) {
		
		Dimension e = Toolkit.getDefaultToolkit().getScreenSize();
		new RefreshScreen(500,500,Color.BLACK,60,3) {

			BlockMap map;
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Icon.png"));
				frame.setTitle("grid 3d thing");
				BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

				// Create a new blank cursor.
				Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
				    cursorImg, new Point(0, 0), "blank cursor");
				frame.getContentPane().setCursor(blankCursor);
				
				
				
			}
			int prevX = 250;
			int prevY = 250;
			private boolean enableda;
			private boolean click = true;
			int state = 1;
			int speed =8;
			int count =0;
			int suncount =0;
			public InputStream i;
			public OutputStream o;
			public ImageEditor test;
			Point3D player2 = new Point3D(0,0,0);
			@Override
			public void update() {
				try {
					o.write((((int)camera.cam.x)+":"+((int)camera.cam.y)+":"+((int)camera.cam.z)).getBytes());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
				String buf = "";
				byte[] b = new byte[255];
					i.read(b);
					
					for(byte l:b) {
					if((int)l > 32) {
						buf+=(char)l;
					}
						
					}
				
					int count2 =0;
					for(String s:buf.split(":")) {
						double out = 0;
						int countc = 0;
						byte[] bts = s.getBytes();
						for(byte y :bts) {
							double val = ((int)y-48);
							out+=((val))*(Math.pow(10, bts.length-1-countc));
							countc++;
						}
						if(count2 == 0) {
						player2.x=out;
						}else if(count2 ==1) {
							player2.y=out;
						}else if(count2 ==2){
							player2.z=out;
						}
						count2++;
					}
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if(count == 0) {
					interactions(map,50);
					
				count =2;
				}
				if(suncount == 0) {
					
					sunAngle -= Math.toRadians(1);
					if(sunAngle < 0 ){
						sunAngle = Math.toRadians(180);
					}
					doShading();
			
					suncount =(int) Math.round(	60*10/180.0*60.0);
				}
				suncount--;
				count--;
				if(PressedKeys.containsKey(KeyEvent.VK_W)) {
					if(PressedKeys.get(KeyEvent.VK_W)) {
						int state = map.map[(int) ((camera.cam.x+speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y+speed*Math.cos(camera.angle1))/map.size)][(int) (camera.cam.z/map.size)];
						if(state==0||state==5){
							camera.cam.y+=speed*Math.cos(camera.angle1);
							camera.cam.x+=speed*Math.sin(camera.angle1);
						}
						
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_S)) {
					if(PressedKeys.get(KeyEvent.VK_S)) {
						int state = map.map[(int) ((camera.cam.x-speed*Math.sin(camera.angle1))/map.size)][(int) ((camera.cam.y-speed*Math.cos(camera.angle1))/map.size)][(int) (camera.cam.z/map.size)];
						if(state==0||state==5){
						camera.cam.y-=speed*Math.cos(camera.angle1);
						camera.cam.x-=speed*Math.sin(camera.angle1);
						}
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_A)) {
					if(PressedKeys.get(KeyEvent.VK_A)) {
						int state = map.map[(int) ((camera.cam.x-speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.y+8*Math.sin(camera.angle1))/map.size)][(int) (camera.cam.z/map.size)];
						if(state==0||state==5){
						camera.cam.x-=speed*Math.cos(camera.angle1);
						camera.cam.y+=8*Math.sin(camera.angle1);
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_D)) {
					if(PressedKeys.get(KeyEvent.VK_D)) {
						int state = map.map[(int) ((camera.cam.x+speed*Math.cos(camera.angle1))/map.size)][(int) ((camera.cam.y-speed*Math.sin(camera.angle1))/map.size)][(int) (camera.cam.z/map.size)];
						if(state==0||state==5){
						camera.cam.x+=speed*Math.cos(camera.angle1);
						camera.cam.y-=speed*Math.sin(camera.angle1);
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_Q)) {
					if(PressedKeys.get(KeyEvent.VK_Q)) {
						int state =map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) ((camera.cam.z+speed)/map.size)];
						if(state==0||state==5){
					camera.cam.z+=speed;	
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_E)) {
					if(PressedKeys.get(KeyEvent.VK_E)) {
						int state = map.map[(int) (camera.cam.x/map.size)][(int) (camera.cam.y/map.size)][(int) ((camera.cam.z-speed)/map.size)];
						if(state==0||state==5){
					camera.cam.z-=speed;	
						}
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_1)) {
					if(PressedKeys.get(KeyEvent.VK_1)) {
						state = 1;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_2)) {
					if(PressedKeys.get(KeyEvent.VK_2)) {
						state = 2;
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_3)) {
					if(PressedKeys.get(KeyEvent.VK_3)) {
						state = 3;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_4)) {
					if(PressedKeys.get(KeyEvent.VK_4)) {
						state = 4;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_5)) {
					if(PressedKeys.get(KeyEvent.VK_5)) {
						state = 5;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_6)) {
					if(PressedKeys.get(KeyEvent.VK_6)) {
						state = 6;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_7)) {
					if(PressedKeys.get(KeyEvent.VK_7)) {
						state =7;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_8)) {
					if(PressedKeys.get(KeyEvent.VK_8)) {
						state =8;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_9)) {
					if(PressedKeys.get(KeyEvent.VK_9)) {
						state =9;
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_0)) {
					if(PressedKeys.get(KeyEvent.VK_0)) {
						state =10;
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_Y)) {
					if(PressedKeys.get(KeyEvent.VK_Y)) {
				sunAngle += Math.toRadians(1);
				if(sunAngle >Math.toRadians(180) ){
					sunAngle = Math.toRadians(180);
				}
				doShading();
				
					}
				}
				
				if(PressedKeys.containsKey(KeyEvent.VK_T)) {
					if(PressedKeys.get(KeyEvent.VK_T)) {
				sunAngle -= Math.toRadians(1);
				if(sunAngle < 0 ){
					sunAngle = 0;
				}
				doShading();
					}
				}
				camera.angle1 = Math.toRadians(((mouseX-250)/500.0)*360);
				camera.angle2 = Math.toRadians(((mouseY-250)/500.0)*360);
				
				Graphics3D g3= new Graphics3D();
				polys=g3.shade(map,camera,50,allShading);
				int x = 0;
				int y = 0;
				int z =  0;
				for(int i = 0;i<= 5;i++) {
					try {
					x = (int)((camera.cam.x+map.size*i*Math.sin(camera.angle1)*Math.cos(camera.angle2))/map.size);
					y =  (int)((camera.cam.y+map.size*i*Math.cos(camera.angle1)*Math.cos(camera.angle2))/map.size);
					z =  (int)((camera.cam.z+map.size*i*Math.sin(camera.angle2))/map.size);
					if(map.map[x][y][z]!=0) {
						i=map.size*6;
					}
					}catch(Exception e) {
						
					}
				}
				
				selec = g3.shadeR(map, camera,x,y,z);
					if(mousePressed) {
						try {
							
						if(click) {
							if((map.map[x][y][z]==0)) {
							map.map[x][y][z]=state;
							}else if(map.map[x][y][z]!=0) {
							map.map[x][y][z]=0;
							}
							
							
							click = false;
						}else if(state ==5 ) {
							if((map.map[x][y][z]==0)) {
								map.map[x][y][z]=state;
								}
						}else if(state ==10 ) {
							if((map.map[x][y][z]!=state)) {
								map.map[x][y][z]=state;
							}
								
						}
						}catch(Exception e) {
							
						}
					}else {
						
						
						click  = true;
					}
					sun = g3.shadeRect3D(camera, new Rect3D(camera.cam.x-1000*Math.cos(sunAngle),camera.cam.y,camera.cam.z+1000*Math.sin(-sunAngle),100), false);
					
				
			}
			
		
			private void doShading() {
				Shader shading = new Shader(Color.GREEN);
				shading.shade(sunAngle);
				allShading.put(1, shading);
				shading = new Shader(new Color(124,98,0));
				shading.shade(sunAngle);
				allShading.put(2, shading);
				shading = new Shader(new Color(25,200,0));
				shading.shade(sunAngle);
				allShading.put(3, shading);
				shading = new Shader(new Color(0,200,255));
				shading.shade(sunAngle);
				allShading.put(4, shading);
				shading = new Shader(new Color(0,0,255,100),true);
				shading.shade(sunAngle);
				allShading.put(5, shading);
				shading = new Shader(new Color(255,255,255,50),true);
				shading.shade(sunAngle);
				allShading.put(6, shading);
				shading = new Shader(new Color(250, 240, 50));
				shading.shade(sunAngle);
				allShading.put(7, shading);
				shading = new Shader(new Color(255, 255, 255));
				shading.shade(sunAngle);
				allShading.put(8, shading);
				shading = new Shader(new Color(183, 184, 186));
				shading.shade(sunAngle);
				allShading.put(9, shading);
				shading = new Shader(new Color(255, 0, 0));
				shading.shade(sunAngle);
				allShading.put(10, shading);
				
			}
			//left
			//back
			//down
			//up
			//forward
			//right
			
			ArrayList<PolygonWr> polys = new ArrayList<PolygonWr>();
		
			ArrayList<Polygon> selec = new ArrayList<Polygon>();
			ArrayList<Polygon> sun = new ArrayList<Polygon>();
			double FOV = 70;
			long limit = screenWidth*4;
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				Graphics3D g3= new Graphics3D(g2);
				
				g3.setColor(new Color(0,(int)Math.abs(Color.WHITE.getGreen()*Math.sin(sunAngle)),(int)Math.abs(Color.WHITE.getBlue()*Math.sin(sunAngle))));
				g3.fillRect(0, 0, screenWidth, screenHeight);
				g3.setColor(Color.YELLOW);
				for(Polygon p:sun) {
					g3.fill(p);	
				}
				g3.setColor(Color.WHITE);
		
			

				
			
				
						for(PolygonWr p:polys) {
						
						g3.setColor(p.c);
							
							/*if(p.type==1&&p.side==1) {
								g3.drawImage(test.fillPolygon(p.p,this,0),0,0,this);
							}else {
								g3.fill(p.p);	
							}*/
							g3.fill(p.p);	
					
						
						
				
						}

					
				
				
				for(Polygon p:selec) {
					g3.setColor(new Color(255,0,0,200));
					g3.draw(p);	
				
				
					
				}
	
			g3.drawCirclePoint3d(player2, 10, camera);
			g3.drawString(player2.toString2(), 0, 40);
			g3.drawString(camera.cam.toString2(), 0, 60);
				g3.drawString( currentFPS+"", 20, 20);
				g3.dispose();
		
				
			}
		
			int sizeB = 500;
			Camera camera;
			
			TCSIndex allShading = new TCSIndex();
			double sunAngle = Math.toRadians(90);
			public Socket s;
			
			@Override
			public void initialize() {
				try {
					s = new Socket(InetAddress.getLocalHost(),1234);
					i = s.getInputStream();
					o = s.getOutputStream();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			

				try {
					test = new ImageEditor(ImageIO.read(new File("src/Images/testImage.jpg")));
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				allShading = new TCSIndex();
				 map = new BlockMap(sizeB,sizeB,sizeB,100);
			map.tperlin(20,15,2,25,5,0);
				camera = new Camera(FOV, screenWidth, screenHeight, new Point3D((sizeB*map.size)/2,(sizeB*map.size)/2,(sizeB*map.size)-map.size*30), 0, 0);
				sunAngle = Math.toRadians(90);
				doShading();
					
				
				
			
				
				
				
			}
			private void interactions(BlockMap map,int chunksize) {
				Point3D cam = camera.cam;
				int camX=(int)Math.round(cam.x/map.size);
				int camY=(int)Math.round(cam.y/map.size);
				int camZ=(int)Math.round(cam.z/map.size);
				int halfchunk =(int)Math.round(chunksize/2);
				
				for(int x=camX-halfchunk;x<camX+halfchunk;x++) {
					for(int y=camY-halfchunk;y<camY+halfchunk;y++) {
						try {
						for(int z=map.map[x][y].length;z>0;z--) {
							try {
								if(map.map[x][y][z]==7) {
							boolean[] touching = map.touching(x,y,z);
							if(!touching[3]) {
								if(map.map[x][y][z+1]==0) {
									map.map[x][y][z]=0;
									map.map[x][y][z+1]=7;
								}
							}else if(map.map[x][y][z+1]==5) {
								map.map[x][y][z]=5;
								map.map[x][y][z+1]=7;
							}
							
							
							}else if(map.map[x][y][z]==5) {
							
								if(map.map[x][y][z+1]==0) {
										map.map[x][y][z]=0;
										map.map[x][y][z+1]=5;
									
								}else if(map.map[x][y+1][z]==0&&(int)(Math.random()*10)==1) {
									
									map.map[x][y][z]=0;
									map.map[x][y+1][z]=5;
									
								}else if(map.map[x+1][y][z]==0&&(int)(Math.random()*10)==1) {
								
									map.map[x][y][z]=0;
									map.map[x+1][y][z]=5;
									
								}else if(map.map[x-1][y][z]==0&&(int)(Math.random()*10)==1) {
									
									map.map[x][y][z]=0;
									map.map[x-1][y][z]=5;
									
								}else if(map.map[x][y-1][z]==0&&(int)(Math.random()*10)==1) {
									
									map.map[x][y][z]=0;
									map.map[x][y-1][z]=5;
									
								}else if(map.map[x][y][z+1]==8) {
									map.map[x][y][z]=0;
									map.map[x][y][z+1]=5;
								
							}else if(map.map[x][y+1][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x][y+1][z]=5;
								
							}else if(map.map[x+1][y][z]==8&&(int)(Math.random()*10)==1) {
							
								map.map[x][y][z]=0;
								map.map[x+1][y][z]=5;
								
							}else if(map.map[x-1][y][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x-1][y][z]=5;
								
							}else if(map.map[x][y-1][z]==8&&(int)(Math.random()*10)==1) {
								
								map.map[x][y][z]=0;
								map.map[x][y-1][z]=5;
								
							}else if(map.map[x][y][z+1]==9&&(int)(Math.random()*500)==1&&z<map.map[x][y].length-17) {
								map.map[x][y][z]=0;
								map.map[x][y][z+1]=5;
							
						}else if(map.map[x][y+1][z]==9&&(int)(Math.random()*500)==1&&z<map.map[x][y].length-17) {
							
							map.map[x][y][z]=0;
							map.map[x][y+1][z]=5;
							
						}else if(map.map[x+1][y][z]==9&&(int)(Math.random()*500)==1&&z<map.map[x][y].length-17) {
						
							map.map[x][y][z]=0;
							map.map[x+1][y][z]=5;
							
						}else if(map.map[x-1][y][z]==9&&(int)(Math.random()*500)==1&&z<map.map[x][y].length-17) {
							
							map.map[x][y][z]=0;
							map.map[x-1][y][z]=5;
							
						}else if(map.map[x][y-1][z]==9&&(int)(Math.random()*500)==1&&z<map.map[x][y].length-17) {
							
							map.map[x][y][z]=0;
							map.map[x][y-1][z]=5;
							
						}
								
								
								
								
							}else if(map.map[x][y][z]==10) {
								if(map.map[x+1][y][z] != 0) {//right
									map.map[x+1][y][z]=0;
								}
								
								if(map.map[x][y+1][z] != 0) {//forward
									map.map[x][y+1][z]=0;	
								}
								if(map.map[x][y][z+1] != 0) {//up
									map.map[x][y][z+1] =0;	
								}
								if(map.map[x-1][y][z] != 0) {//left
									map.map[x-1][y][z]=0;					
								}
								if(map.map[x][y-1][z] != 0) {//back
									map.map[x][y-1][z]	=0;					
								}
								if(map.map[x][y][z-1] != 0) {//down
									map.map[x][y][z-1]=0;							
								}
							}
							}catch(Exception e) {
							
						}
						}
					}catch(Exception e) {
						
					}
					}
						
					
				}
				
			}
			
		};
		}


			
}
			