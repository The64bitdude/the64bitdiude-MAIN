package runandImplement;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;



public class ClientTester {

	public static void main(String[] args) {
		try {
			Socket s = new Socket(InetAddress.getLocalHost(),1234);
			InputStream i = s.getInputStream();
			OutputStream o = s.getOutputStream();
			Scanner in = new Scanner(System.in);
			String ea="";
			while(!ea.equals("0")) {
				
					ea =in.nextLine();
				
					o.write((ea+" ").getBytes());
				
			}
				s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	
		}
	}


