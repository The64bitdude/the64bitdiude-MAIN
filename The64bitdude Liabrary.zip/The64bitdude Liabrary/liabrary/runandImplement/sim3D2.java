package runandImplement;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;

import javax.swing.JFrame;



import Screens.RefreshScreen;
import Systems.Camera;
import Systems.Graphics3D;
import Systems.Point3D;
import Systems.Polygon3D;
import Systems.Rect3D;



public class sim3D2 {
	public static void main(String[] args) {
		
		
		new RefreshScreen(500,500,Color.BLACK,60,3) {

		
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				points = new ArrayList<ArrayList<Point3D>>();
				
			}
			int prevX = 250;
			int prevY = 250;
			private boolean enableda;
			@Override
			public void update() {
				if(PressedKeys.containsKey(KeyEvent.VK_W)) {
					if(PressedKeys.get(KeyEvent.VK_W)) {
						camera.cam.y+=4*Math.cos(camera.angle1);
						camera.cam.x+=4*Math.sin(camera.angle1);
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_S)) {
					if(PressedKeys.get(KeyEvent.VK_S)) {
						camera.cam.y-=4*Math.cos(camera.angle1);
						camera.cam.x-=4*Math.sin(camera.angle1);
							}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_A)) {
					if(PressedKeys.get(KeyEvent.VK_A)) {
						camera.cam.x-=4*Math.cos(camera.angle1);
						camera.cam.y+=4*Math.sin(camera.angle1);
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_D)) {
					if(PressedKeys.get(KeyEvent.VK_D)) {
						camera.cam.x+=4*Math.cos(camera.angle1);
						camera.cam.y-=4*Math.sin(camera.angle1);
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_Q)) {
					if(PressedKeys.get(KeyEvent.VK_Q)) {
					camera.cam.z+=4;	
					}
				}
				if(PressedKeys.containsKey(KeyEvent.VK_E)) {
					if(PressedKeys.get(KeyEvent.VK_E)) {
					camera.cam.z-=4;	
					}
				}
			
				camera.angle1 = Math.toRadians(((mouseX-250)/500.0)*360);
				camera.angle2 = Math.toRadians(((mouseY-250)/500.0)*360);
				
				if(mousePressed) {
					if(enableda) {
						points.add(new ArrayList<Point3D>());
						enableda = false;
					}
					if(points.size()>0) {
					if(points.get(points.size()-1).size()>0) {
						Point3D next = new Point3D((int)(camera.cam.getX()+50*Math.sin(camera.angle1)*Math.cos(camera.angle2)),(int)(camera.cam.getY()+50*Math.cos(camera.angle1)*Math.cos(camera.angle2)),(int)(camera.cam.getZ()+50*Math.sin(camera.angle2)));
					if(points.get(points.size()-1).get(points.get(points.size()-1).size()-1).distance(next) > 1) {
						points.get(points.size()-1).add(next);
					
					}
					}else {
						points.get(points.size()-1).add( new Point3D((int)(camera.cam.getX()+50*Math.sin(camera.angle1)*Math.cos(camera.angle2)),(int)(camera.cam.getY()+50*Math.cos(camera.angle1)*Math.cos(camera.angle2)),(int)(camera.cam.getZ()+50*Math.sin(camera.angle2))));
					}
					}else {
						points.add(new ArrayList<Point3D>());
					}
				}else {
					enableda = true;
				}
					
					
				
			}

			ArrayList<ArrayList<Point3D>> points = new ArrayList<ArrayList<Point3D>>();
			double FOV = 70;
			
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				Graphics3D g3= new Graphics3D(g2);
				g3.setColor(Color.WHITE);
			
			
				for(ArrayList<Point3D> p2:points) {
					Point b = null;
					for(Point3D p:p2) {
					Point a = p.project(camera);
					if(b==null) {
						b=a;
					}
					g3.drawCirclePoint(a, 10);
					g3.drawLine(a,b);
					b=a;
					}
				}
				
				

				g3.drawCirclePoint((new Point3D(0,0,0)).project(camera),10);
				g3.setColor(Color.GREEN);
				g3.drawCirclePoint((new Point3D(100,0,0)).project(camera),10);
				g3.setColor(Color.BLUE);
				g3.drawCirclePoint((new Point3D(0,100,0)).project(camera),10);
				g3.setColor(Color.RED);
				g3.drawCirclePoint((new Point3D(0,-100,0)).project(camera),10);
				g3.setColor(Color.CYAN);
				g3.drawCirclePoint((new Point3D(-100,0,0)).project(camera),10);
				g3.drawString( currentFPS+"", 20, 20);
				g3.dispose();
		
				
			}
		

			Camera camera;
			@Override
			public void initialize() {
			
				camera = new Camera(FOV, screenWidth, screenHeight, new Point3D(100,-100,100), 0, 0);
				
				
			
				
				
				
			}
			
		};
		}
}
