package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import Screens.RefreshScreen;
import Systems.Graphics3D;
import Systems.Point3D;



public class sim3DBasic {
	public static void main(String[] args) {
		
		
		new RefreshScreen(500,500,Color.BLACK,60,3) {

		
			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				points= new Point3D[16][16];
				pointsproj= new Point[16][16];
				
			}
		
			@Override
			public void update() {
				
				if(isKeyPressed(KeyEvent.VK_W)) {
					
						cam.y+=4*Math.cos(Math.toRadians(ang1));
						cam.x+=4*Math.sin(Math.toRadians(ang1));
					
				}
				if(isKeyPressed(KeyEvent.VK_S)) {
					
						cam.y-=4*Math.cos(Math.toRadians(ang1));
						cam.x-=4*Math.sin(Math.toRadians(ang1));
							
				}
				if(isKeyPressed(KeyEvent.VK_A)) {
				
				cam.x-=4*Math.cos(Math.toRadians(ang1));
				cam.y+=4*Math.sin(Math.toRadians(ang1));
					
				}
				if(isKeyPressed(KeyEvent.VK_D)) {
					
						cam.x+=4*Math.cos(Math.toRadians(ang1));
						cam.y-=4*Math.sin(Math.toRadians(ang1));
					
				}
				if(isKeyPressed(KeyEvent.VK_Q)) {
					
					cam.z+=4;	
					
				}
				if(isKeyPressed(KeyEvent.VK_E)) {
					
					cam.z-=4;	
					
				}
				ang1 = ((mouseX-250)/500.0)*360;
				ang2 = ((mouseY-250)/500.0)*360;
				
			
				
			}
		
			double ang1 = 0;
			double ang2 = 0;
			double FOV = 70;
			double dis = (screenWidth/(Math.tan(Math.toRadians(FOV))/2));
			
			@Override
			public void paint(Graphics g) {
				Graphics2D g2 = (Graphics2D)g;
				Graphics3D g3= new Graphics3D(g2);
				g3.fillRect(0, 0, screenWidth, screenHeight);
				g3.setColor(Color.WHITE);
				
				int x=0;
				int y=0;
						Point3D p2=new Point3D(0,0,0);
						Point p=p2.setLocation(0, 0, 0).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
						Point pp=p2.setLocation(300, 0, 0).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);;
						Point p3=p2.setLocation(300, 0, 300).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
						
						Point p4=p2.setLocation(0, 0, 300).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2);
						
							
					
					
					//System.out.println("L  :"+L.toString());
					//System.out.println("P  :"+p.toString());
					//System.out.println("");
				//	g3.setColor(new Color(b.getRGB((int)(p2.x), (int)(p2.z))));
					
				//	g3.fill(new Polygon(new int[] {p.x,pp.x,p3.x,p4.x},new int[] {p.y,pp.y,p3.y,p4.y},4));
					g3.setColor(Color.WHITE);
					double dx=(pp.x-p.x)/30.0;
					//System.out.println(dx);
					double dy=(pp.y-p.y)/30.0;
				//	System.out.println(dy);
					double dx2=(p3.x-p4.x)/30.0;
				//	System.out.println(dx2);
					double dy2=(p3.y-p4.y)/30.0;
				//	System.out.println(dy2);
					double dxdx=(dx2-dx)/30.0;
					double dydy=(dy2-dy)/30.0;
				
					double dx3=(p4.x-p.x)/30.0;
					//System.out.println(dx);
					double dy3=(p4.y-p.y)/30.0;
				//	System.out.println(dy);

					for(double i =0;i<=30;i++) {
					for(double i2 =0;i2<=30;i2++) {
					g3.drawLine(p.x+(dx)*i+(dx3*i2)+(dxdx*i*i2),p.y+(dy)*i+dy3*i2+dydy*i2*i,p.x+(dx)*(i)+dx3*i2+(dxdx*i*i2),p.y+(dy)*(i)+dy3*i2+dydy*i2*i);
					}
					
					
						}
					//g3.drawCirclePoint(proj,10);
					
					//g3.drawString(""+Math.round(p.x)+","+Math.round(p.y)+","+Math.round(p.z)+"",proj.x,proj.y);
					//g3.drawString(""+Math.round(p.x-cam.x)+","+Math.round(p.y-cam.y)+","+Math.round(p.z-cam.z)+"",proj.x,proj.y);
					//System.out.println(""+Math.round(proj.x)+","+Math.round(proj.y));
			
					
				
				
			

				
				
			
				g3.drawCirclePoint((new Point3D(0,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.GREEN);
				g3.drawCirclePoint((new Point3D(100,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.BLUE);
				g3.drawCirclePoint((new Point3D(0,100,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.RED);
				g3.drawCirclePoint((new Point3D(0,-100,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.setColor(Color.CYAN);
				g3.drawCirclePoint((new Point3D(-100,0,0)).project(cam,dis,Math.toRadians(ang1),Math.toRadians(ang2),screenWidth/2,screenHeight/2),10);
				g3.drawString( currentFPS+"", 20, 20);
				g3.dispose();
		
				
			}
		Point3D[][] points= new Point3D[17][17];
		Point[][] pointsproj= new Point[17][17];

			
		
			Point3D cam =new Point3D(100,-100,100);
			BufferedImage b;
			@Override
			public void initialize() {
				System.gc();
				dis = (screenWidth/(Math.tan(Math.toRadians(FOV))/2));
			//	cam =new Point3D(100,-100,100);
			//	points = new ArrayList<Point3D>();
				BufferedImage buf = new BufferedImage(17,17,1);
				try {
					b=ImageIO.read(new File("src/Images/testImage.jpg"));
					for(double i = 0;i<b.getHeight();i+=b.getHeight()/16.0) {
						for(double k = 0;k<b.getWidth();k+=b.getWidth()/16.0) {
							buf.setRGB((int)Math.round(k/(b.getHeight()/16.0)), (int)Math.round(i/(b.getHeight()/16.0)),b.getRGB((int)Math.round(k),(int)Math.round(i)));
						}
					}
					b=buf;
				} catch (IOException e) {
					System.exit(0);
				}
				
				
				/*for(int i = 0;i<360;i+=18) {
					for(int k = 0;k<360;k+=18) {
						if(k==0) {
							for(double l = 200;l<800;l+=100) {
								points.add(new Point3D(l,i,k));	
							}
						}
				points.add(new Point3D(810.0,i,k));
						
					}
				}*/
			
			
				
				
				
			}
			
		};
		}
}
