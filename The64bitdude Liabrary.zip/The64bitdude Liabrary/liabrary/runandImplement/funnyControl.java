package runandImplement;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import Screens.RefreshScreen;

public class funnyControl {
 public static void main(String[] args) {
	new RefreshScreen(750,500,Color.BLACK,1000,3) {
		Dimension e = Toolkit.getDefaultToolkit().getScreenSize();
		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {

			
		}

		@Override
		public void update() {
		
	
			
				//r.mouseMove(0, 0);
			if(isKeyPressed(KeyEvent.VK_SPACE)) {
				b=r.createScreenCapture(new Rectangle(0,0,e.width,e.height));
			}
			
					
		
			
		}
		Robot r;
		@Override
		public void paint(Graphics g) {
		g.drawImage(b,0,0,this);
		}
		Color col;
		BufferedImage b;
		@Override
		public void initialize() {
			try {
				r = new Robot();
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		col=Color.BLACK;
		b=new BufferedImage(1,1,1);
			
		}
		
	};
 }
}
