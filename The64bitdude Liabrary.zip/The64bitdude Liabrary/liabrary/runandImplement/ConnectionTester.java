package runandImplement;

import dataServer2.ConnectionManager;

public class ConnectionTester {

	public static void main(String[] args) {
		ConnectionManager m = new ConnectionManager();
m.setAcceptingConnections(true);

	}

}
