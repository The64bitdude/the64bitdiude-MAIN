package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JFrame;

import Physics.PhysicsObject3D;
import Screens.RefreshScreen;
import Systems.Graphics3D;

public class RigidBodySIm {
 public static void main(String[] args) {
	 new RefreshScreen(500,500,Color.black,60,3) {
	
		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void update() {
		
			
		}

		@Override
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D)g;
			Graphics3D g3 =new Graphics3D(g2);
			g3.setColor(Color.white);
			
			g3.dispose();
			
		}
		
		@Override
		public void initialize() {
		
			
		}
		 
	 };
 }
}
