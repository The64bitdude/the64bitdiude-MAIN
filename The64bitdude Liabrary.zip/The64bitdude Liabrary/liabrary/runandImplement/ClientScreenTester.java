package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.JFrame;

import DataServer.DataClientScreen;
import DataServer.SBD;
import Screens.RefreshScreen;

public class ClientScreenTester {
 public static void main(String[] args) {
	 try {
		new DataClientScreen(500,500,Color.BLACK,60,1234,InetAddress.getLocalHost()) {
			boolean receved=false;
			@Override
			public SBD send() {
				// TODO Auto-generated method stub
				Scanner in = new Scanner(System.in);
			if(!receved) {
				return new SBD(1,StringData("test"));
			}else {
				return new SBD(1,StringData(in.next()));
			}
			}

			@Override
			public void receive(String s) {
				System.out.println(s);
				receved=true;
			}

			@Override
			public void receive(BufferedImage image) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void define() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void itorate() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void paint(Graphics g) {
				// TODO Auto-generated method stub
				
			}
			 
		 };
	} catch (UnknownHostException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
}
