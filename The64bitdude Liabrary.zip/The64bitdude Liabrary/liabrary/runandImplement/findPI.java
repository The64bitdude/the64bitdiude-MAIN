package runandImplement;

import java.util.Scanner;

public class findPI {
 public static void main(String[] args) {
	 Scanner s = new Scanner(System.in);
	 System.out.println(Integer.MAX_VALUE/2);
	 int size = Integer.MAX_VALUE/2;
	 int precision = s.nextInt();
	double pi =3*precision;
	 for(int i = 2;i<size;i+=4) {
		 pi+=(4.0/(i*(i+1.0)*(i+2.0)))*precision;
		 pi-=(4.0/((i+2.0)*(i+3.0)*(i+4.0)))*precision;
	 }
	 System.out.println(pi);
 }
}
