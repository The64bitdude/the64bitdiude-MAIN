package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;



import Physics.PhysicsObject;
import RayTrace.RayTracer;
import RayTrace.RayTracer.Ray;
import Screens.RefreshScreen;
import Systems.Graphics3D;

public class Raytraceor {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.BLACK,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}
double ang=0;
int x = 250;
int y =250;
			@Override
			public void update() {
			if(isKeyPressed(KeyEvent.VK_1)) {
				ang+=1;
			}
			if(isKeyPressed(KeyEvent.VK_2)) {
				ang-=1;
			}
			if(!isKeyPressed(KeyEvent.VK_R)) {
				
		
				R.calc(time,new Polygon(new int[] {(int) (mouseX-50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.sin(Math.toRadians(ang)))},new int[] {(int) (mouseY-50*Math.sin(Math.toRadians(ang))),(int) (mouseY+50*Math.sin(Math.toRadians(ang))),(int) (mouseY-50*Math.cos(Math.toRadians(ang)))},3),new Point(x,y));
				R2.calc(time,new Polygon(new int[] {(int) (mouseX-50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.sin(Math.toRadians(ang)))},new int[] {(int) (mouseY-50*Math.sin(Math.toRadians(ang))),(int) (mouseY+50*Math.sin(Math.toRadians(ang))),(int) (mouseY-50*Math.cos(Math.toRadians(ang)))},3),new Point(250,250));
				R3.calc(time,new Polygon(new int[] {(int) (mouseX-50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.sin(Math.toRadians(ang)))},new int[] {(int) (mouseY-50*Math.sin(Math.toRadians(ang))),(int) (mouseY+50*Math.sin(Math.toRadians(ang))),(int) (mouseY-50*Math.cos(Math.toRadians(ang)))},3),new Point(150,150));
				
			}
			if(WASD(0)) {
				y-=1;
			}
			if(WASD(1)) {
				x-=1;
			}
			if(WASD(2)) {
				y+=1;
			}
			if(WASD(3)) {
				x+=1;
			}
			
				
			}

			@Override
			public void paint(Graphics g) {
				Graphics2D g3 = (Graphics2D)g;
			g3.setColor(Color.black);
			g3.fillRect(0, 0, screenWidth, screenHeight);
				g3.setColor(Color.WHITE);
				g3.fillRect(100,100,1,400);
				g3.fillRect(100,100,400,1);
				g3.drawLine(100,500,500,100);
			
				g3.draw(new Polygon(new int[] {(int) (mouseX-50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.cos(Math.toRadians(ang))),(int) (mouseX+50*Math.sin(Math.toRadians(ang)))},new int[] {(int) (mouseY-50*Math.sin(Math.toRadians(ang))),(int) (mouseY+50*Math.sin(Math.toRadians(ang))),(int) (mouseY-50*Math.cos(Math.toRadians(ang)))},3));

				R.draw(g3,Color.WHITE,75);
				R2.draw(g3,Color.WHITE,75);
				R3.draw(g3,Color.WHITE,75);

				g3.dispose();
				
			}
			double startLight=200;
			double time= 1;
			RayTracer R;
			RayTracer R2;
			RayTracer R3;
			@Override
			public void initialize() {
				R=new RayTracer(360,(int)startLight, new Point(250,250));
				R2=new RayTracer(360,(int)startLight, new Point(250,250));
				R3=new RayTracer(360,(int)startLight, new Point(150,150));
				
			}
			
		};

	}

}
