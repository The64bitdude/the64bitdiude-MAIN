package runandImplement;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JFrame;

import GameTypes.Idol;
import GameTypes.Upgrade;
import Screens.RefreshScreen;

public class idolgametester {
 public static void main(String[] args) {
	 new RefreshScreen(500,500,Color.BLACK,60,3) {

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void update() {
			game.update(currentFPS);
			game.collectAll();
			if(b3.contains(new Point(mouseX,mouseY))&&mousePressed) {
				game.buy(2);
			}
			if(b2.contains(new Point(mouseX,mouseY))&&mousePressed) {
				game.buy(0);
			}
			if(b1.contains(new Point(mouseX,mouseY))&&mousePressed) {
				game.buy(1);
			}
			if(b4.contains(new Point(mouseX,mouseY))&&mousePressed) {
				game.buy(3);
			}
		}

		@Override
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D)g;
			g2.setColor(Color.white);
			g2.drawString(game.toString(),50,50);
			g2.fill(b1);
			g2.fill(b2);
			g2.fill(b3);
			g2.fill(b4);
			g2.drawString(game.Upgrades.get(0).toString(),50,70);
			g2.drawString(game.Upgrades.get(1).toString(),50,90);
			g2.drawString(game.Upgrades.get(2).toString(),50,110);
			g2.drawString(game.Upgrades.get(3).toString(),50,130);
			g2.dispose();
			
		}
		Idol game;
		Rectangle b1;
		Rectangle b2;
		Rectangle b3;
		Rectangle b4;
		@Override
		public void initialize() {
			game = new Idol(1,FPS,0);
			game.add(new Upgrade(1.15,2, 1, 0.50, true));
			game.add(new Upgrade(1.1,100, 10, 0.75, false));
			game.add(new Upgrade(1.05,10000, 1000, 0.80, false));
			game.add(new Upgrade(1.01,1000000, 100000, 0.85, false));
			b1 = new Rectangle(200,155,50,100);
			b2 = new Rectangle(100,155,50,100);
			b3 = new Rectangle(300,155,50,100);
			b4 = new Rectangle(400,155,50,100);
			
		}
		 
	 };
 }
}
