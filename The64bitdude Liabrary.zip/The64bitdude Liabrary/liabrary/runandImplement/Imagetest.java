package runandImplement;


import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Shapes.Circle;

public class Imagetest extends JPanel implements Runnable{
	public Thread tt;
	int mx = 0;
	int my = 0;
	public Imagetest() {
		this.setSize(1000,500);
		this.setPreferredSize(getSize());
		this.setDoubleBuffered(true);
		this.setBackground(Color.white);
		this.setFocusable(true);
		this.addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseDragged(MouseEvent e) {
				mx=e.getX();
				my=e.getY();
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				mx=e.getX();
				my=e.getY();
				
			}
			
		});
	}
	
	public static void main(String[] args) {
		JFrame out = new JFrame();
		out.setDefaultCloseOperation(3);
		out.setSize(500,500);
		
		Imagetest scre = new Imagetest();
		out.add(scre);
		out.pack();
		
		out.setVisible(true);
		
		scre.rT();
		
	}
	public void rT() {
		tt = new Thread(this);
		tt.start();
	}

	int mxb = 0;
	int myb =0;
	public BufferedImage img4;
	public BufferedImage img5;
	int counttimes = 0;
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		g2.drawImage(img2,0,0, this);
		g2.drawImage(img3,500,0, this);
		if((mxb!=mx)||(myb!=my)) {
			try {
			
		img4 = invirt(img2, mx,my,140,140, false);
			//blur(img2,mx-70,my-70,140,140,10,false);
				
			}catch(ArrayIndexOutOfBoundsException e) {
				
			}
			try {
				if(mx>500-140) {
					img4 = invirt(img3, mx-500,my,140, 140, false);
					blur(img4,0,0,img4.getWidth(),img4.getHeight(),10,true);
					
					
					
					
					c = new Circle(img4.getWidth()/2,img4.getHeight()/2, img4.getWidth()/2, 20);
					cutPoly(img4,c);
			}
					}catch(ArrayIndexOutOfBoundsException e) {
						
					}
		mxb = mx;
		myb = my;
		}
		if(img4!=null) {
			g2.drawImage(img4,mx,my, this);
		}else {
			g2.drawImage(img2,0,0, this);
		}
		
		g2.dispose();
	}
	public Circle c;
	public BufferedImage img2;
	public BufferedImage img3;
	public BufferedImage img2d;
	public BufferedImage img3d;
	public void run() {
		
		try {
			img2 = ImageIO.read(new File("src/Images/test.png"));
			//blur(img2,100,300,200,200,20,true);
			
			//CBlur(img2,100,200,200,200,5,true);
			//invirt(img2,200,100,100,100);
		
			img2d = img2;
			img3 = ImageIO.read(new File("src/Images/kfc.png"));
			
			//softblur(img3,75,50,100,150,2,1);
			//BBlur(img3,75,50,100,150,10,true);
			//removeColor(img3,Color.WHITE,10);
			img3d = img3;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		long btime = System.nanoTime();
		long atime;
		long dtime = 1000000000/60;
		while(tt!=null) {
			atime = System.nanoTime();
			if((atime-btime) >= dtime) {
				update();
				repaint();
				
				
				btime = atime;
			}
		}
		
	}
	public BufferedImage invirt(BufferedImage img, int x, int y, int w1, int h1,boolean b) {
		BufferedImage outI;
		if(img!= null) {
			 outI = new BufferedImage(w1, h1,  img.getType());
		}else {
		 outI = new BufferedImage(w1, h1,  6);
		}
		for(int h = y;h<y+h1;h++) {
			for(int w = x;w<x+w1;w++) {
				Color c;
				if(w>=img.getWidth()||h>=img.getHeight()||h<0||w<0) {
					c = Color.BLACK;
				}else {
				c = new Color(img.getRGB(w, h));
				}
				Color invert = new Color(255-c.getRed(),255-c.getGreen(),255-c.getBlue());
				if(b) {
					if(!(w>img.getWidth()||h>img.getHeight())) {
						
						img.setRGB(w, h, invert.getRGB());
					}
			
				}else {	
					outI.setRGB(w-x, h-y, invert.getRGB());
				}
			}
		}
		return outI;
		
	}
	public void removeColor(BufferedImage img,Color color,int tolerence) {
		for(int h = 0;h<img.getHeight();h++) {
			for(int w = 0;w<img.getWidth();w++) {
				Color pixelColor = new Color(img.getRGB(w, h));
				int r = pixelColor.getRed();
				int g = pixelColor.getGreen();
				int b = pixelColor.getBlue();
				int a = pixelColor.getAlpha();
				if(r+tolerence>color.getRed()&&(r-tolerence<color.getRed())) {
					if(g+tolerence>color.getGreen()&&(g-tolerence<color.getGreen())) {
						if(b+tolerence>color.getBlue()&&(b-tolerence<color.getBlue())) {
							img.setRGB(w, h,(new Color(0,0,0,0)).getRGB());
						}
					}
				}
			}
			
		}
	}
	private void softblur(BufferedImage img,int x,int y,int width,int height,int amount,int n) {

		if(n != 0) {
			
		
if(n +amount !=1) {
		if(n % amount ==0) {
			n+=1;
		}
}

		for(int p = 0;p<width;p+=amount+n) {
			blur(img,x+p,y,width-p,height,amount,true);
			blur(img,x,y+p,width,height-p,amount,true);
			}
		}else {
			for(int p = 0;p<width;p+=1) {
				blur(img,x+p,y,width-p,height,amount,true);
				blur(img,x,y+p,width,height-p,amount,true);
				}
		}
			
		
		
	}
	public BufferedImage BBlur(BufferedImage img,int x,int y,int width,int height,int amount,boolean b) {
		ArrayList<ArrayList<Integer>> rgb5= new ArrayList<ArrayList<Integer>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		for(int h = 0;h<height;h++) {
			rgb5.add(new ArrayList<Integer>());
			for(int w = 0;w<width;w++) {
				double sumr = 0;
				double sumg = 0;
				double sumb = 0;
				double suma= 0;
				for(int dh = 0;dh<amount*2;dh++) {
					for(int dw = 0;dw<amount*2;dw++) {
						Color ave =new Color(img.getRGB(w-amount+dw+x, h-amount+dh+y));
						sumr +=ave.getRed();
						sumg += ave.getGreen();
						sumb += ave.getBlue();
						suma += ave.getAlpha();
					}
				}
				sumr /=amount*2*amount*2;
				sumg /=amount*2*amount*2;
				sumb /=amount*2*amount*2;
				suma /=amount*2*amount*2;
				Color out = new Color((int)sumr,(int)sumg,(int)sumb,(int)suma);
				rgb5.get(h).add(w, out.getRGB());
				
			}
		}
		for(int h = 0;h<height;h++) {
			for(int w = 0;w<width;w++) {
				if(b) {
					img.setRGB(w+x, h+y, rgb5.get(h).get(w));	
					}else {
					outI.setRGB(w, h,rgb5.get(h).get(w));
					}
			}
		}
		return outI;
	}
	public BufferedImage CBlur(BufferedImage img,int x,int y,int width,int height,int amount, boolean b) {
		ArrayList<ArrayList<Integer>> rgb5= new ArrayList<ArrayList<Integer>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		for(int h = 0;h<height;h++) {
			rgb5.add(new ArrayList<Integer>());
			for(int w = 0;w<width;w++) {
				double sumr = 0;
				double sumg = 0;
				double sumb = 0;
				double suma= 0;
				double sum = 0;
				for(int dh = -amount;dh<amount;dh++) {
					for(int dw = -amount;dw<amount;dw++) {
						if(Math.sqrt(Math.pow(dh, 2)+Math.pow(dw, 2))<=amount) {
							try {
						Color ave =new Color(img.getRGB(w+dw+x, h+dh+y));
						sumr +=ave.getRed();
						sumg += ave.getGreen();
						sumb += ave.getBlue();
						suma += ave.getAlpha();
						sum++;
							}catch(ArrayIndexOutOfBoundsException|NullPointerException e) {
								
							}
						}
					}
				}
				sumr /=sum;
				sumg /=sum;
				sumb /=sum;
				suma /=sum;
				Color out = new Color((int)sumr,(int)sumg,(int)sumb,(int)suma);
				rgb5.get(h).add(w, out.getRGB());
				
			}
		}
		
		for(int h = 0;h<height;h++) {
			for(int w = 0;w<width;w++) {
				try {
					if(b) {
					img.setRGB(w+x, h+y, rgb5.get(h).get(w));	
					}else {
					outI.setRGB(w, h,rgb5.get(h).get(w));
					}
				}catch(ArrayIndexOutOfBoundsException e) {
					
				}
			}
		}
		return outI;
	}
	
	private BufferedImage blur(BufferedImage img,int x,int y,int width,int height,int amount,boolean b)throws ArrayIndexOutOfBoundsException {
		ArrayList<ArrayList<Color>> rgb5= new ArrayList<ArrayList<Color>>();
		ArrayList<ArrayList<Point>> points= new ArrayList<ArrayList<Point>>();
		BufferedImage outI;
		if(img!= null) {
			outI = new BufferedImage(width, height,  img.getType());
		}else {
			outI = new BufferedImage(width, height,  6);
		}
		if(x+width > img.getWidth()) {
			width = img.getWidth()-x;
		}
		if(y+height > img.getHeight()) {
			height = img.getHeight()-y;
		}
		int countbox = 0;
		double countw = width/amount;
		double counth = height/amount;
		int count = 0;
		double tcount = countw*counth;
		int	realCount;
		rgb5.add(new ArrayList<Color>());
		points.add(new ArrayList<Point>());
		for(int i =0;i<=tcount;i++) {
			rgb5.add(new ArrayList<Color>());
			points.add(new ArrayList<Point>());
		}
		for(int h = 0;h<=height-amount;h+=amount) {
			for(int w = 0;w<=width-amount;w+=amount) {
				for(int i = 0;i<amount;i++) {
					for(int k = 0;k<amount;k++) {
						if((x+w+k > 0)&&(y+h+i > 0)){
				rgb5.get(countbox).add(new Color(img.getRGB(x+w+k, y+h+i)));
				points.get(countbox).add(new Point(x+w+k,y+h+i));
				
					}
					}
				}
				countbox++;
			}
		}
		for(int i = 0;i<tcount+1;i++) {
			double sumr = 0;
			double sumg = 0;
			double sumb = 0;
			double suma = 0;
			for(Color ave:rgb5.get(i)) {
				sumr += ave.getRed();
				sumg += ave.getGreen();
				sumb += ave.getBlue();
				suma += ave.getAlpha();
			}
			sumr/=amount*amount;
			sumb/=amount*amount;
			sumg/=amount*amount;
			suma/=amount*amount;
			for(Point p:points.get(i)) {
				if(b) {
				img.setRGB(p.x, p.y, (new Color((int)sumr,(int)sumg,(int)sumb,(int)suma).getRGB()));
				}else {
					outI.setRGB(p.x-x, p.y-y, (new Color((int)sumr,(int)sumg,(int)sumb,(int)suma).getRGB()));
				}
			}
		}
		return outI;
		
		
		
	}
	public BufferedImage blurPoly(BufferedImage img,Polygon poly,int amount,boolean b) {
		 BufferedImage thebuf = blur(img,poly.getBoundingBox().x, poly.getBoundingBox().y, poly.getBoundingBox().width, poly.getBoundingBox().height, amount, false);
		for(int h = 0;h<thebuf.getHeight();h++) {
			for(int w = 0;w<thebuf.getWidth();w++) {
				if(!poly.contains(poly.getBoundingBox().x+w,poly.getBoundingBox().y+h)) {
					thebuf.setRGB(w, h, (new Color(0,0,0,0)).getRGB());
				}else if(b){
					img.setRGB(poly.getBoundingBox().x+w, poly.getBoundingBox().x+h,thebuf.getRGB(w, h));
				}
			}
		}
		 return thebuf;
		
	}
	public BufferedImage cutPoly(BufferedImage img,Polygon poly) {
		for(int h = 0;h<img.getHeight();h++) {
			for(int w = 0;w<img.getWidth();w++) {
				if(!poly.contains(poly.getBoundingBox().x+w,poly.getBoundingBox().y+h)) {
					img.setRGB(w, h, (new Color(0,0,0,0)).getRGB());
				}
			}
		}
		 return img;
		
	}
	
	private void update() {
	
		
		
	}
}
