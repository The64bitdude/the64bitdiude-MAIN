package runandImplement;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import com.github.sarxos.webcam.Webcam;

import Screens.RefreshScreen;

public class webcamtester {

	public static void main(String[] args) {
		new RefreshScreen(500,500,Color.black,60,3) {

			@Override
			public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void update() {
				img = SystemCamera.getImage();
				
			}

			@Override
			public void paint(Graphics g) {
				if(img !=null) {
			g.drawImage(img,0,0,this);
				}
				g.dispose();
				
			}
			BufferedImage img;
Webcam SystemCamera;
			@Override
			public void initialize() {
			
			SystemCamera=Webcam.getDefault();
				SystemCamera.open();
				SystemCamera.isOpen();
			}
			
		};

	}

}
