package RayTrace;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.ArrayList;

import RayTrace.RayTracer.Ray;
import Systems.Graphics3D;

public class RayTracer {
	public ArrayList<Ray> Rays;
	public int StartLight = 200;
	public int Precision;
	public Point startPoint= new Point(0,0);
	public RayTracer(int Precision,int StartLight,Point startPoint) {
		Rays= new ArrayList<Ray>();
		for(double i = 0;i<=360;i+=360.0/Precision) {
			Rays.add(new Ray(Math.cos(i),Math.sin(i),StartLight,startPoint));
		}
		this.StartLight=StartLight;
		this.Precision=Precision;
		this.startPoint=startPoint;
	}
			
	public class Ray{
		public double x=0;
		public double y=0;
		public double Vx=0;
		public ArrayList<Point> lastPoints;
		public double Vy=0;
		public double LightValue = 0;
		public boolean mode = true;
		public Ray(double Vx,double Vy,int LightValue,Point startPoint) {
			this.x=startPoint.x;
			this.y=startPoint.y;
			this.Vx=Vx;
			this.Vy=Vy;
			this.LightValue=LightValue;
			lastPoints = new ArrayList<Point>();
			lastPoints.add(startPoint);
		}
		public Point Advance(double time,double LightvalueLoss) {
			lastPoints.add(new Point((int)x,(int) y));
			x+=Vx*time;
			y+=Vy*time;
			LightValue-=LightvalueLoss;
			return new Point((int)(x),(int)(y));
			
		}
		public void Reflect(double ang,double LightvalueLosspercent) {
			lastPoints.add(new Point((int)x,(int) y));
			double mag = Math.sqrt(Vy*Vy+Vx*Vx);
			double newangle=-Math.toDegrees(Math.atan2(Vy,Vx))-2*ang;
			LightValue/=LightvalueLosspercent;
			Vy=mag*Math.sin(Math.toRadians(newangle));
			Vx=mag*Math.cos(Math.toRadians(newangle));
			
			
		}
		
	}

	public void calc(double time,Polygon pa,Point startPoint) {
		this.startPoint=startPoint;
		Rays= new ArrayList<Ray>();
		for(double i = 0;i<360;i+=360.0/Precision) {
			Rays.add(new Ray(Math.cos(i),Math.sin(i),StartLight,startPoint));
		}
		int count = (int) StartLight;
		for(Ray r :Rays) {
		count = (int) StartLight;
		while(r.mode) {

			
		Point p = r.Advance(time,0);
		
		if(new Rectangle(100,100,1,400).contains(p)) {
			//r.Reflect(90,2);
			r.mode=false;
			
		}
		if(new Polygon(new int[] {500,500,100},new int[] {100,500,500},3).contains(p)) {
			//r.Reflect(45,2);
			r.mode=false;
			
		}
		if(new Rectangle(100,100,400,1).contains(p)) {
			//r.Reflect(0,2);
			r.mode=false;
			
		}
		if(pa.contains(p)){
		
			r.mode=false;
		}
			}
		count--;
		if(count<0) {
			r.mode=false;	
		}
		
		}
		
	}

	public void draw(Graphics2D g2, Color c,int dissapate) {
		int count = (int) StartLight;
		for(Ray r :Rays) {

			Point lastPoint = r.lastPoints.get(0);
			count = (int) StartLight;
			for(Point l:r.lastPoints) {
				if(count>=0) {
					if(dissapate >0&&dissapate <255) {
				g2.setColor(new Color((int)(c.getRed()),(int)(c.getGreen()),(int)(c.getBlue()),(int)(dissapate*count/StartLight)));
					}else {
						g2.setColor(c);
					}
				g2.drawLine(lastPoint.x, lastPoint.y, l.x, l.y);
				}
				lastPoint=l;
				
				count--;
			}
		
	
		}
		
	}
	
}
