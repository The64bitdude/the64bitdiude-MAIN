package DataServer;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Event;
import java.awt.event.AWTEventListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;



import Screens.RefreshScreen;

public abstract class DataSystemScreen extends RefreshScreen{
	int failCount = 0;
	Socket CNTS;
	public int port;

	public DataSystemScreen(int sw,int sh,Color c,int fps,int port) {
		super(sw, sh, c, fps);
	this.port = port;
	
	}
	
	public DataSystemScreen(int sw,int sh,Color c,int fps,int type,int port) {
		super(sw, sh, c, fps, type);
		this.port = port;
	}

	public void Output(ObjectOutputStream o) {
		try {
	
			if(send().sign!=-1) {
				o.writeObject(send().getData());
				}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
	
		}
	}
	public void input(ObjectInputStream i) {
		try {

			int[] b = (int[]) i.readObject();
			int sign = b[0];
			if(sign ==3) {
		
			}
			if(sign ==1) {
				String buf = "";
				for(int k =1;k<b.length;k++) {
					buf+=(char)b[k];
				}
				receive(buf);
			}
			if(sign ==2) {
				int Width = b[1];
				int Height= b[2];
				System.out.println(Width);
				System.out.println(Height);
				BufferedImage buf = new BufferedImage(Math.abs(Width),Math.abs(Height),2);
				int count = 3;
				for(int h = 0;h<Height;h++) {
					for(int w = 0;w<Width;w++) {
					buf.setRGB(w, h,b[count]);
						count++;
					}
				}
				receive(buf);
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public abstract SBD send();
	public abstract void receive(String s);
	public abstract void receive(BufferedImage image);
	public abstract void define();
	public abstract void itorate();
	
	public int[] ImageData(BufferedImage image) {
		int area = image.getWidth()*image.getHeight();
		int[] out = new int[area+2];
		out[0]=image.getWidth();
		out[1]=image.getHeight();
		System.out.println(out[0]+" : "+image.getWidth());
		System.out.println(out[1]+" : "+image.getHeight());
	int count = 2;
	for(int h = 0;h<image.getHeight();h++) {
		for(int w = 0;w<image.getWidth();w++) {
			out[count]=image.getRGB(w, h);
				count++;
		}
	}
		return out;
	}
	public int[] StringData(String s) {
		
		int[] out = new int[s.length()];
		for(int i =0;i<s.length();i++) {
			out[i]=s.charAt(i);
		}
		return out;
	}

}
