package Physics;

import java.awt.Point;

import Systems.Point3D;

public class Vector3D {
	public double x;
	public double y;
	public double z;
	public double mag;
	public Vector3D() {
		this(0,0,0);
	}
	public Vector3D(double x,double y, double z) {
		this.x=(double)x;
		this.y=(double)y;
		this.z=(double)z;
		
	}
	public Vector3D translate(double dx, double dy, double dz) {
		
		return new Vector3D(x+dx,y+dy,z+dz);
	}
	public Vector3D mul(double dx, double dy, double dz) {
	
		return new Vector3D(x*dx,y*dy,z*dz);
		
	}
	public Vector3D div(double dx, double dy, double dz) {
		
		return new Vector3D(x/dx,y/dy,z/dz);
	}
	public static Vector3D cross(Vector3D A,Vector3D B) {
		
		
		
		return new Vector3D(A.y*B.z-A.z*B.y,-(A.x*B.z-A.z*B.x),(A.x*B.y-A.y*B.x));
		
	}
	
	
public Vector3D cross(Vector3D B) {
		
		
		
		return cross(this,B);
		
}
public double mag() {
	// TODO Auto-generated method stub
	return Math.sqrt(x*x+y*y+z*z);
}
public double angle(Vector3D B) {
	// TODO Auto-generated method stub
	return angle(this,B);
}
private double angle(Vector3D A, Vector3D B) {
	return Math.acos(A.dot(B)/(A.mag()*B.mag()));
}
public double dot(Vector3D B) {
	// TODO Auto-generated method stub
	return dot(this,B);
}
private double dot(Vector3D A, Vector3D B) {
	
	return A.x*B.x+A.y*B.y+A.z*B.z;
}
public double angle(double dox,double doy,double doz) {
	// TODO Auto-generated method stub
	return angle(new Vector3D(dox,doy,doz));
}
public Vector3D Reflect(Vector3D A,Vector3D B) {
	double angle = 2*Math.atan2(B.y, B.x)-Math.atan2(A.y, A.x);
	double angle2 = 2*Math.atan2(B.z, B.x)-Math.atan2(A.z, A.x);
	double angle3 = 2*Math.atan2(B.z, B.y)-Math.atan2(A.z, A.y);
	double mag=A.mag();
	double xs =A.x>=0?-1:1;
	double ys=A.y>=0?-1:1;
	return new Vector3D(mag*xs*Math.cos(angle)*xs*Math.cos(angle2),mag*xs*Math.sin(angle)*ys*Math.cos(angle3),mag*xs*Math.sin(angle2)*ys*Math.sin(angle3));
	
}
public Point3D getPoint() {
	
	return new Point3D().setLocation(x, y, z);
}
public Vector3D Reflect(Vector3D B) {
	// TODO Auto-generated method stub
	return Reflect(this,B);
}
public Vector3D mul(Vector3D B) {
	// TODO Auto-generated method stub
	return mul(B.x,B.y,B.z);
}
public void setmag() {
	mag=mag();
	
}
public double dot(double x, double y, double z) {
	// TODO Auto-generated method stub
	return  this.x*x+this.y*y+this.z*z;
}
}
