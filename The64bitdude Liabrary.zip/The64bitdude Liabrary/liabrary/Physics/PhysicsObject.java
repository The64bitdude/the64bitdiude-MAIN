package Physics;

public class PhysicsObject {
	public double Xo =0;
	public double Vxo =0;
	public double Axo =0;
	public double mass =0;
	public double netForceX = 0;
	public PhysicsObject() {
		
	}
	public PhysicsObject(double mass,double Xo,double Vxo,double Axo) {
		this.Xo=Xo;
		this.Vxo=Vxo;
		this.Axo=Axo;
		this.mass =mass;
	}
	public PhysicsObject(double mass) {
		this.mass=mass;
	}
	public void addForceX(double Fx) {
		netForceX+=Fx;
	}
	public void removeForceZ(double Fx) {
		netForceX-=Fx;
	}
	public void addForce(double Fx) {
		addForceX(Fx);
		
	}
	public double calcAx() {
		Axo=netForceX/mass;
		return Axo;
		
	}
	public void calcA() {
		calcAx();

		
	}
	public void resetNet() {
		netForceX = 0;
		
	}
	public double runTime(double t) {
		return Xo+(Vxo*t)+((Axo/2)*(t*t));
	}
	
}
