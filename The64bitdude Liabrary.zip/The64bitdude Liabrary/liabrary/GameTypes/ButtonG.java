package GameTypes;

import java.awt.Point;
import java.awt.Rectangle;

public class ButtonG extends Rectangle{
	public boolean holding = false;
	public int side;
	public int pos;
	public int state;
	public int index;
	public ButtonG(int x,int y,int width,int height,int side,int pos, int index) {
		super(x,y,width,height);
		this.side = side;
		this.state=this.side;
		this.pos=pos;
		this.index=index;
	}
	public boolean isClicked(int mouseX,int mouseY,boolean mouseState) {
		if(!holding&&contains(new Point(mouseX,mouseY))&&mouseState) {
			holding=true;
			return true;
		}else if(!mouseState){
			holding=false;
			return false;
		}else {
			return false;
		}
	}
	
}
