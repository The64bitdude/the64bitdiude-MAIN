package runners;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.JFrame;

import systems.Camera;
import systems.Light;
import systems.RefreshScreenConnection;
import systems.Renderer;
import systems.Vector3D;
import systems.Shapes.Cuboid;
import systems.Shapes.Cylander;
import systems.Shapes.Ovel3D;
import systems.Shapes.Shape3D;

public class Graphicstest2 {

	public static void main(String[] args) {
		try {
			new RefreshScreenConnection(500,500,Color.black,60,3) {

				private static final long serialVersionUID = 1L;
				private String outIP;
				private int outPort;

				public void setScreen(RefreshScreenConnection refreshScreen, JFrame frame) {
				Scanner bob=new Scanner(System.in);
				this.connectionManager.setPort(bob.nextInt());
					System.out.println(connectionManager.myIP()+" <-- my IP \nsend address");
					outIP=bob.next();
					System.out.println("sending port");
					outPort=bob.nextInt();
					bob.close();
				connectionManager.start();
					
				
					a=new Camera(new Vector3D(0,0,0),0,0,500,70);
				b=new Camera(new Vector3D(0,0,0),0,0,500,70);
					render = new Renderer(a);
				}
			
				public void update() {
				
						try {
							connectionManager.write(outIP,outPort,a.toString().getBytes());
						} catch (Exception e) {
				
					
					}
			
				
							
				render.cam.update(Math.toRadians((mouseX/500.0)*360), Math.toRadians(((mouseY/500.0)*180)+90));
				render.cam.move((isKeyPressed(KeyEvent.VK_W)?1:0)+(isKeyPressed(KeyEvent.VK_S)?-1:0),(isKeyPressed(KeyEvent.VK_D)?1:0)+(isKeyPressed(KeyEvent.VK_A)?-1:0),(isKeyPressed(KeyEvent.VK_E)?1:0)+(isKeyPressed(KeyEvent.VK_Q)?-1:0));
				//render.allShapes.get(5).translateThis(0f, 1f, 0);
				render.allShapes.get(0).setRotationThis(0,0,(float)-a.lastAngle1);
render.allShapes.get(0).setPosition(a.pos.sub(0, 0, 20));

render.allShapes.get(1).setRotationThis(0f,0f,(float)-b.lastAngle1);
render.allShapes.get(1).setPosition(b.pos);
				L.update(a.pos,a.SV);
				L2.update(b.pos.add(b.SV.mul(50)),b.SV.inv());
			render.update(false);
			//	out=render.updateRender(false,screenWidth, screenHeight, 250,250, draw);
				
				
				
					if(isKeyPressed(KeyEvent.VK_C)) {
						draw=false;
					}else {
						draw=true;
					}
				}
				
boolean draw=true;
BufferedImage out;
				public void paint(Graphics g) {
					g.fillRect(0,0,1000,1000);
					g.setColor(Color.RED);
					g.setClip(0,0, screenWidth, screenHeight);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
					((Graphics2D) g).setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,RenderingHints.VALUE_COLOR_RENDER_SPEED);
				
render.paintRender((Graphics2D)g, 250, 250,draw);
			
					
				//	g.drawImage(out,0,0,this);
				
g.setColor(Color.WHITE);
g.drawString("FPS : "+this.currentFPS, 20,20);
render.paintDebug(g,20,40,20);
					g.dispose();
				}

Camera a;
Camera b;
Renderer render;
			Light L;
			Light L2;

	
				public void initialize() {
				
				
					Shape3D jeff=new Shape3D();
					jeff.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.GRAY,90f,270f,0f,180f));
					jeff.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.white,270f,450f,0f,180f));
					jeff.add(new Cylander(new Vector3D(-100,150,10),new Vector3D(20,20,40),20f,Color.white,false));
					jeff.add(new Ovel3D(new Vector3D(-100,150,10),new Vector3D(20,20,20),20f,20f,Color.white,0f,360f,180f,360f));
					//6
					render.add(jeff);
				
					/*Shape3D bob=new Shape3D();
					bob.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.red,90f,270f,0f,360f));
					bob.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.white,270f,450f,0f,360f));
					render.add(bob);*/
					Shape3D jeff2=new Shape3D();
					jeff2.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.white,90f,270f,0f,180f));
					jeff2.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.GRAY,270f,450f,0f,180f));
					jeff2.add(new Cylander(new Vector3D(-100,150,10),new Vector3D(20,20,40),20f,Color.white,false,90,270));
					jeff2.add(new Cylander(new Vector3D(-100,150,10),new Vector3D(20,20,40),20f,Color.GRAY,false,270,450));
					jeff2.add(new Ovel3D(new Vector3D(-100,150,10),new Vector3D(20,20,20),20f,20f,Color.white,0f,360f,180f,360f));
					//6
					render.add(jeff2);
				
					render.add(new Cuboid(new Vector3D(0,0,-100),new Vector3D(800,800,20),Color.white,new boolean[] {false,true,false,false,false,false}).rezdivThis(13));
				
				render.add(new Light(new Vector3D(200,(float)(100+100*Math.sqrt(3)+0.5f),600),new Vector3D(0,0,-100),Color.RED, 100f,300f,15f,40f),true,100);
				render.add(new Light(new Vector3D(100,100,600),new Vector3D(0,0,-100),Color.blue, 100f,300f,15f,40f),true,100);
				render.add(new Light(new Vector3D(300,100,600),new Vector3D(0,0,-100),Color.green,100f,300f,15f,40f),true,100);
			
			render.add(new Light(new Vector3D(400,400,900),new Vector3D(0,0,-100),Color.WHITE, 100f,100f,0,180f),true,100);
			render.add(new Light(new Vector3D(400,-400,100),new Vector3D(0,100,0),Color.WHITE, 100f,100f,0,180f),true,100);
			render.add(new Light(new Vector3D(-400,400,100),new Vector3D(100,0,0),Color.WHITE, 100f,100f,0,180f),true,100);
			render.add(new Light(new Vector3D(400,1200,100),new Vector3D(0,-100,0),Color.WHITE, 100f,100f,0,180f),true,100);
			render.add(new Light(new Vector3D(1200,400,100),new Vector3D(-100,0,0),Color.WHITE, 100f,100f,0,180f),true,100);
			
				//render.bake();
				L=new Light(render.cam.pos,render.cam.SV,Color.WHITE,100f, 50f,10f,90f);
				L2=new Light(render.cam.pos.sub(render.cam.SV),render.cam.SV.inv(),Color.RED,100f, 7f,10f,20f);
				render.add(L2);
			//render.add(L);
				out=render.updateRender(false,screenWidth, screenHeight, 250,250, draw);
			
				
				}
				@Override
				public void StringDataEvent(String s) {

					String[] in=s.split(" ");
					b.update(Math.toRadians(Float.parseFloat(in[0])), Math.toRadians(Float.parseFloat(in[1])));
					b.pos.i=Float.parseFloat(in[2]);
					b.pos.j=Float.parseFloat(in[3]);
					b.pos.k=Float.parseFloat(in[4]);
					
				}
				@Override
				public void byteDataEvent(byte[] data) {
					// TODO Auto-generated method stub
					
				}
				
			};
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
