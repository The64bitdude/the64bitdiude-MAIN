package runners;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JFrame;

import systems.RefreshScreenConnection;

public class MultiPlayerBoxGame {
	
	public static void main(String[] args) {
		try {
			new RefreshScreenConnection(500,500,Color.BLACK,60,3) {
				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
				HashMap<String,Point> players;
				private String outIP;
				private int outPort;
				private String username;
				private int playerx;
				private int playery;
				boolean sending;
				@Override
				public void setScreen(RefreshScreenConnection refreshScreen, JFrame frame) {
					players=new HashMap<String,Point>();
					Scanner in=new Scanner(System.in);
					System.out.println("your username");
					username=in.nextLine().replace(':', ';');
					System.out.println("your port");
					playerx=250;
					playery=250;
					this.connectionManager.setPort(in.nextInt());
						System.out.println(connectionManager.myIP()+" <-- my IP");
						System.out.println("are you sending by default?");
						sending=in.nextBoolean();
						if(sending) {
						System.out.println("send address");
						outIP=in.next();
						System.out.println("sending port");
						outPort=in.nextInt();
						}
						in.close();
					connectionManager.start();
					
				}
			
				@Override
				public void StringDataEvent(String s) {
					
					String[] dat=s.split(":");
					if(!dat[0].equals(username)) {
					if(players.containsKey(dat[0])) {
					players.get(dat[0]).setLocation(Integer.parseInt(dat[1]),Integer.parseInt(dat[2]));
					}else {
						
						players.put(dat[0], new Point(Integer.parseInt(dat[1]),Integer.parseInt(dat[2])));
						
					}
					if(dat.length>3) {
					try {
						connectionManager.write(dat[3], Integer.parseInt(dat[4]),(username+":"+playerx+":"+playery).getBytes());
					} catch (Exception e) {
						// TODO Auto-generated catch block
					
					}
					for(String S:players.keySet()) {
						if(!S.equals(dat[0])) {
						try {
						
							Point p =players.get(S);
							connectionManager.write(dat[3], Integer.parseInt(dat[4]),(S+":"+p.x+":"+p.y).getBytes());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							
						}
						}
					}
					
					}
					}
				}

				@Override
				public void byteDataEvent(byte[] data) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void update() {
				WASD(playerx,playery);
		
				if(sending) {
				try {
					connectionManager.write(outIP, outPort,(username+":"+playerx+":"+playery+":"+connectionManager.myIP()+":"+connectionManager.port).getBytes());
				} catch (Exception e) {
					// TODO Auto-generated catch block
				
				}
				for(String S:players.keySet()) {
					try {
					
						Point p =players.get(S);
						connectionManager.write(outIP, outPort,(S+":"+p.x+":"+p.y).getBytes());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						
					}
					
				}
				}
					
				}

				private void WASD(int playerx2, int playery2) {
				 playerx+=(isKeyPressed(KeyEvent.VK_D)?1:0)-(isKeyPressed(KeyEvent.VK_A)?1:0);
				 playery+=(isKeyPressed(KeyEvent.VK_S)?1:0)-(isKeyPressed(KeyEvent.VK_W)?1:0);
				}

				@Override
				public void paint(Graphics g) {
					g.setColor(Color.black);
					g.fillRect(0, 0,500,500);
					g.setColor(Color.white);
					g.drawString(username, playerx-20, playery-20);
					g.fillRect(playerx-20,playery-20,40,40);
					for(String s:players.keySet()) {
					
						Point p =players.get(s);
						g.drawString(s, p.x-20, p.y-20);
						g.fillRect(p.x-20,p.y-20,40,40);
					}
					
				}

				@Override
				public void initialize() {
					// TODO Auto-generated method stub
					
				}
				
			};
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
