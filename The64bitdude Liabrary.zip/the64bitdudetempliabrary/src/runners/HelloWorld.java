package runners;

import systems.MultiObjArray;
import systems.Vector3D;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("ello there");
MultiObjArray test= new MultiObjArray();
test.add(new Vector3D(23,3,5).reflect(1, 1, 0));
test.add(3);
test.add(4f);
test.add("hello");
Vector3D x=test.get(0);
int y=test.get(1);
float z= test.get(2);
String f=test.get(3);
for(int i =0;i<test.size();i++) {
	Object e=test.get(i);
	System.out.println(e);
}



System.out.println(x+" "+y+" "+z+" "+f+" "+test.getClassName(0));
	}

}
