package runners;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.util.Observer;
import java.util.Vector;

import javax.swing.JFrame;

import systems.Camera;
import systems.Light;
import systems.RefreshScreen;
import systems.Renderer;
import systems.Vector3D;
import systems.Shapes.Cuboid;
import systems.Shapes.Cylander;
import systems.Shapes.Line3D;
import systems.Shapes.Ovel3D;
import systems.Shapes.Shape3D;
import systems.Shapes.Sphere;
import systems.Shapes.Triangle3D;

public class Graphicstest {
public static void main(String[] args) {
	new RefreshScreen(500,500,Color.black,60,3) {

		private static final long serialVersionUID = 1L;

		@Override
		public void setScreen(RefreshScreen refreshScreen, JFrame frame) {
		a=new Camera(new Vector3D(0,0,0),0,0,500,70);
		b=new Camera(new Vector3D(0,0,0),0,0,500,70);
			render = new Renderer(a);
		}

		@Override
		public void update() {
	
			if(isKeyPressed(KeyEvent.VK_O)) {
				render.setCamera(b);
				
			}
			if(isKeyPressed(KeyEvent.VK_P)) {
				render.setCamera(a);
				
			}
	
		render.cam.update(Math.toRadians((mouseX/500.0)*360), Math.toRadians(((mouseY/500.0)*180)+90));
		render.cam.move((isKeyPressed(KeyEvent.VK_W)?1:0)+(isKeyPressed(KeyEvent.VK_S)?-1:0),(isKeyPressed(KeyEvent.VK_D)?1:0)+(isKeyPressed(KeyEvent.VK_A)?-1:0),(isKeyPressed(KeyEvent.VK_E)?1:0)+(isKeyPressed(KeyEvent.VK_Q)?-1:0));
		//render.allShapes.get(5).translateThis(0f, 1f, 0);
		render.allShapes.get(6).setRotationThis(0,0,(float)-a.lastAngle1);
render.allShapes.get(6).setPosition(a.pos.sub(0, 0, 20));

render.allShapes.get(7).setRotationThis(0f,0f,(float)-b.lastAngle1);
render.allShapes.get(7).setPosition(b.pos);
		L.update(a.pos,a.SV);
		L2.update(a.pos.add(a.SV.mul(50)),a.SV.inv());
	
	render.update(false);
	//	out=render.updateRender(false,screenWidth, screenHeight, 250,250, draw);
		
		
		
			if(isKeyPressed(KeyEvent.VK_C)) {
				draw=false;
			}else {
				draw=true;
			}
		}
		
boolean draw=true;
BufferedImage out;
		@Override
		public void paint(Graphics g) {
			g.fillRect(0,0,1000,1000);
			g.setColor(Color.RED);
			g.setClip(0,0, screenWidth, screenHeight);
			((Graphics2D) g).setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_SPEED);
			((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
			((Graphics2D) g).setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,RenderingHints.VALUE_COLOR_RENDER_SPEED);
		
render.paintRender((Graphics2D)g, 250, 250,draw);
	
			
		//	g.drawImage(out,0,0,this);
			
g.setColor(Color.WHITE);
g.drawString("FPS : "+this.currentFPS, 20,20);
render.paintDebug(g,20,40,20);
			g.dispose();
		}

Camera a;
Camera b;
Renderer render;
	Light L;
	Light L2;


		public void initialize() {
			
			//render = new Renderer(new Camera(new Vector3D(0,0,0),0,0,500,70));
			
			//0
			render.add(new Ovel3D(new Vector3D(400,600,200),new Vector3D(200,50,50),100,Color.BLUE));
			//1
			render.add(new Cuboid(new Vector3D(315,590,130),new Vector3D(30,20,30),new Color(255,255,255,125)).rezdivThis(10));
			//2
			render.add(new Cuboid(new Vector3D(-400,-400,-110),new Vector3D(1600,1600,10),Color.WHITE,new boolean[] {true,true,false,false,false,false}).rezdivThis(15));
			//3
			render.add(new Cuboid(new Vector3D(-400,-400,-110),new Vector3D(1600,1600,10),Color.WHITE,new boolean[] {false,false,true,true,true,true}).rezdivThis(1));
			//4
			render.add(new Ovel3D(new Vector3D(400,600,150),new Vector3D(100,25,25),100,Color.GRAY));
		
			//5
			render.add(new Sphere(new Vector3D(200,(float) (((100+100*Math.sqrt(3)+0.5f)+200f)/3f),100),200,200,Color.WHITE));
			Shape3D jeff=new Shape3D();
			jeff.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.GRAY,90f,270f,0f,180f));
			jeff.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.white,270f,450f,0f,180f));
			jeff.add(new Cylander(new Vector3D(-100,150,30),new Vector3D(20,20,20),20f,Color.white,false));
			jeff.add(new Cylander(new Vector3D(-100,150,10),new Vector3D(20,20,20),20f,Color.green,false));
			jeff.add(new Ovel3D(new Vector3D(-100,150,10),new Vector3D(20,20,20),20f,20f,Color.white,0f,360f,180f,360f));
			//6
			render.add(jeff);
		
			Shape3D bob=new Shape3D();
			bob.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.red,90f,270f,0f,360f));
			bob.add(new Ovel3D(new Vector3D(-100,150,50),new Vector3D(20,20,20),20f,20f,Color.white,270f,450f,0f,360f));
			render.add(bob);
			//render.add(new Sphere(new Vector3D(200,200,200),200,200,Color.WHITE).flipThis());
		//	render.add(new Cuboid(new Vector3D((float)(100),(float)(100),(float)(-100)),new Vector3D(100,100,200),Color.white).rezdivThis(13));
			render.add(new Cylander(new Vector3D(-100,-100,100),new Vector3D(50,50,100),10,Color.white).rotateThis(90f,0f,0f).rezdivThis(0));
		
		
					//render.add(new Cuboid(new Vector3D(0,0,-1000),new Vector3D(1000,1000,1000),new Color(255,255,255)).rezdivThis(16));	
					
		render.add(new Light(new Vector3D(200,(float)(100+100*Math.sqrt(3)+0.5f),600),new Vector3D(0,0,-100),Color.RED, 100f,300f,15f,40f,36),true,100);
		render.add(new Light(new Vector3D(100,100,600),new Vector3D(0,0,-100),Color.blue, 100f,300f,15f,40f),true,100);
		render.add(new Light(new Vector3D(300,100,600),new Vector3D(0,0,-100),Color.green,100f,300f,15f,40f),true,100);
	
	render.add(new Light(new Vector3D(400,400,900),new Vector3D(0,0,-100),Color.WHITE, 100f,100f,0,180f),true,100);
	render.add(new Light(new Vector3D(400,-400,100),new Vector3D(0,100,0),Color.WHITE, 100f,100f,0,180f),true,100);
	render.add(new Light(new Vector3D(-400,400,100),new Vector3D(100,0,0),Color.WHITE, 100f,100f,0,180f),true,100);
	render.add(new Light(new Vector3D(400,1200,100),new Vector3D(0,-100,0),Color.WHITE, 100f,100f,0,180f),true,100);
	render.add(new Light(new Vector3D(1200,400,100),new Vector3D(-100,0,0),Color.WHITE, 100f,100f,0,180f),true,100);
	
		//render.bake();
		L=new Light(render.cam.pos,render.cam.SV,Color.WHITE,100f, 50f,10f,90f);
		L2=new Light(render.cam.pos.sub(render.cam.SV),render.cam.SV.inv(),Color.RED,100f, 7f,10f,20f);
		render.add(L2);
	render.add(L);
		out=render.updateRender(false,screenWidth, screenHeight, 250,250, draw);
	
		
		}
		
	};
}
}
