package systems;

public class Vector2D extends Vector3D{
	public Vector2D(float x,float y) {
		super(x,y,0);
	}
}
