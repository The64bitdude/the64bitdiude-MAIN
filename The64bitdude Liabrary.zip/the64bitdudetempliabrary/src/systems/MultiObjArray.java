package systems;

import java.util.ArrayList;

public class MultiObjArray {
	ArrayList<Node<?>> list;
	public MultiObjArray() {
		list = new ArrayList<Node<?>>();
	}
	public int size() {
		return list.size();
	}
	public <A> void add(A a) {
		list.add(new Node<A>(a));
	}
	@SuppressWarnings("unchecked")
	public <A> A get(int index) {
		return (A)list.get(index).dat;
	}
	public void remove(int index) {
	 list.remove(index);
	}
	public String getClassName(int index) {
		return getClass(index).getName();
	}
	public Class<?> getClass(int index) {
		return list.get(index).dat.getClass();
	}
	
}
