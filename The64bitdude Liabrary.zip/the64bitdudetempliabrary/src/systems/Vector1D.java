package systems;

public class Vector1D extends Vector2D{

	public Vector1D(float x) {
		super(x, 0);
		// TODO Auto-generated constructor stub
	}

}
