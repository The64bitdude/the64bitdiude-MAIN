package systems;

import java.util.Arrays;

import systems.Shapes.Shape3D;
import systems.Shapes.Triangle3D;

public class Collider {
	byte type;
	public Vector3D center;
	public Vector3D size;
	public float radius;
	public PointVector[] sides;
	public Vector3D[] corners;
	public Vector3D currentRotation=new Vector3D(0,0,0);
	Shape3D shape;
	
	public Collider(Shape3D shape) {
		this.type=2;
	this.shape=shape;
	
	}
	public Collider(Vector3D center,float radius) {
		this.type=0;
		this.center=center;
		this.radius=radius;
		
	}
	public Collider(Vector3D center,Vector3D size) {
		this.type=1;
		this.center=center;
		this.size=size;
		getPointVectors();
	}
	
	public boolean inside(Vector3D v) {
		switch(type) {
		case 0:return insideSphere(v);
		case 1:return insideRect(v);
		case 2:return insideShape(v);
		}
		return false;
	}
	private boolean insideShape(Vector3D v) {
	for(Triangle3D t:shape.triangles) {
	
		if(t.midPoint.sub(v).dot(t.shapeVector)<0) {
			return false;
		}
	}
		return true;
	}
	public boolean inside(Collider c) {
		switch(c.type) {
		case 0:return insideSphere(c);
		case 1:return insideRect(c);
		case 2:return c.insideShape(this);
		}
		return false;
	}
	private boolean insideShape(Collider c) {
	
		if(c.inside(shape.center)) {
			return true;
		}
		for(Triangle3D t:shape.triangles) {
			for(Vector3D v:t.points) {
				if(c.inside(v)) {
					return true;
				}
			}
			if(c.inside(t.midPoint)){
			return true;
			}
		}
			return false;
	}
	private boolean insideSphere(Collider c) {
		// TODO Auto-generated method stub
	
	switch(type) {
	case 0:return c.center.sub(center).div(c.radius+radius).magSqrd()<=1;
	case 1:return insideRectSp(c);
	case 2:return insideShapeSp(c);
		}
	return false;
	

	}

	private boolean insideShapeSp(Collider c) {
	
		for(int i=0;i<shape.triangles.size();i++) {
			if(insideShape(shape.triangles.get(i).shapeVector.mul(-c.radius).add(c.center))) {
				return true;		
			}

			
		}
		return false;
	}
	private boolean insideRectSp(Collider c) {
		
		for(int i=0;i<6;i++) {
		
			if(insideRect(sides[i].vector.mul(c.radius).add(c.center))) {
				return true;		
			}

			
		}
		for(int i=0;i<8;i++) {
			
			if(c.insideSphere(corners[i])) {
				return true;		
			}

			
		}
		for(int i=0;i<4;i++) {
			Vector3D v=corners[i].sub(c.center);

			Vector3D[] v2 = new Vector3D[3];
			
			if(i <2) {
			v2[0]=corners[i].sub(corners[4]);
			v2[1]=corners[i].sub(corners[5]);
			v2[2]=corners[i].sub(corners[6+i]);
			}else {
				v2[0]=corners[i].sub(corners[6]);
				v2[1]=corners[i].sub(corners[7]);
				v2[2]=corners[i].sub(corners[4+i-2]);
				}
			for(int l=0;l<3;l++) {
			float vmag=v2[l].mag();
			float v1m=(float) (v2[l].dot(v)/vmag);
		
		
			if((v2[l].cross(v).mag()/(vmag))<c.radius&&((v1m)<(c.radius/2+vmag)&&(v1m)>-(c.radius/2))) {
			//	System.out.println(v1m+ " " +i+" " + l+" "+vmag+" "+c.radius+" "+(v2[l].cross(v).mag()/(vmag)));
				return true;		
			}
			
			}
		
			
		}
		
		return false;
	}
	/*
	
	 * 
	 * corners[0]=sides[0].pos.add(sides[2].vector).add(sides[4].vector); 
	corners[4]=sides[0].pos.add(sides[4].vector).add(sides[3].vector);//j
	corners[5]=sides[0].pos.add(sides[5].vector).add(sides[2].vector);//i
	corners[6]=sides[1].pos.add(sides[2].vector).add(sides[4].vector);//k
	
	corners[1]=sides[0].pos.add(sides[3].vector).add(sides[5].vector);
	corners[4]=sides[0].pos.add(sides[4].vector).add(sides[3].vector);//i
	corners[5]=sides[0].pos.add(sides[5].vector).add(sides[2].vector);//j
	corners[7]=sides[1].pos.add(sides[3].vector).add(sides[5].vector);//k
		
	corners[2]=sides[1].pos.add(sides[4].vector).add(sides[3].vector);
	corners[6]=sides[1].pos.add(sides[2].vector).add(sides[4].vector);//j
	corners[7]=sides[1].pos.add(sides[3].vector).add(sides[5].vector);//i
	corners[4]=sides[0].pos.add(sides[4].vector).add(sides[3].vector);//k
	
	corners[3]=sides[1].pos.add(sides[5].vector).add(sides[2].vector);
	corners[6]=sides[1].pos.add(sides[2].vector).add(sides[4].vector);//i
	corners[7]=sides[1].pos.add(sides[3].vector).add(sides[5].vector);//j
	corners[5]=sides[0].pos.add(sides[5].vector).add(sides[2].vector);//k
	 */
	private boolean insideRect(Collider c) {
		switch(type) {
		case 0:return c.insideRectSp(this);
		case 1:
		for(int i=0;i<8;i++) {
			if(insideRect(c.corners[i])) {
				return true;		
			}
		}
		for(int i=0;i<6;i++) {
			if(insideRect(c.sides[i].pos)) {
				return true;		
			}

			
		};break;
		case 2:return c.insideShape(this);
		}
		
		return false;
	}
	private boolean insideRect(Vector3D v) {
		for(PointVector p:sides) {
			if(p.pos.sub(v).dot(p.vector)<0) {
				return false;
			}
		}
		return true;
	}
	public void rotate(Vector3D r) {
		
		
		rotate(r.i,r.j,r.k);
		}
public void rotate(float roll, float pitch,float yaw) {
		
	rotate(center,roll,pitch,yaw);
	}
public void setRotate(float roll, float pitch,float yaw) {
	
	rotate(new Vector3D(roll, pitch, yaw).sub(currentRotation));
}


private void rotate(Vector3D center2, float roll, float pitch, float yaw) {
	currentRotation.addThis(roll,pitch,yaw);
	rotatePointVectors(center2,getRotationMatrix(roll,pitch,yaw));
	
	
}
public float[][] getRotationMatrix(float rolla,float  pitcha,float yawa){
	double roll= Math.toRadians(rolla);
	double pitch= Math.toRadians(pitcha);
	double yaw=Math.toRadians(yawa);
	float cosa1=(float) Math.cos(roll);
	float sina1=(float) Math.sin(roll);
	float cosa2=(float) Math.cos(pitch);
	float sina2=(float) Math.sin(pitch);
	float cosa3=(float) Math.cos(yaw);
	float sina3=(float) Math.sin(yaw);


return new float[][]{new float[] {cosa3*cosa2,cosa3*sina2*sina1-sina3*cosa1,cosa3*sina2*cosa1+sina3*sina1},
new float[]  {sina3*cosa2,sina3*sina2*sina1+cosa3*cosa1,sina3*sina2*cosa1-cosa3*sina1},
new float[] {-sina2,cosa2*sina1,cosa2*cosa1}};
}
	
	private void rotatePointVectors(Vector3D o,float[][] currentRot) {
		
		for(int i=0;i<6;i++) {
			sides[i].pos=sides[i].pos.sub(o).matrixMul(currentRot).add(o);
			sides[i].vector=sides[i].pos.sub(o).normalize();
		
		}
		for(int i=0;i<8;i++) {
			corners[i]=corners[i].sub(o).matrixMul(currentRot).add(o);
		}
		
	}
	private boolean insideSphere(Vector3D v) {
		// TODO Auto-generated method stub
		
		return v.sub(center).mag()<=radius;
	}
	/**
	 * @author The64BitDude
	 * @param sides [ 0 bottom , 1 Top ,  2 back , 3 front , 4 right , 5 left ]
	 * @param corners [ 0 bottom back , 1 bottom front ,  2 back , 3 front , 4 right , 5 left ]
	 * 			
	 */
	private void getPointVectors() {
		sides=new PointVector[6];
		sides[0]=new PointVector(center.add(0,0,-size.k),new Vector3D(0,0,-size.k));
		sides[1]=new PointVector(center.add(0,0,size.k),new Vector3D(0,0,size.k));
		sides[2]=new PointVector(center.add(0,-size.j,0),new Vector3D(0,-size.j,0));
		sides[3]=new PointVector(center.add(0,size.j,0),new Vector3D(0,size.j,0));
		sides[4]=new PointVector(center.add(size.i,0,0),new Vector3D(size.i,0,0));
		sides[5]=new PointVector(center.add(-size.i,0,0),new Vector3D(-size.i,0,0));
		corners=new Vector3D[8];
		corners[0]=sides[0].pos.add(sides[2].vector).add(sides[4].vector);
		corners[4]=sides[0].pos.add(sides[4].vector).add(sides[3].vector);
		corners[5]=sides[0].pos.add(sides[5].vector).add(sides[2].vector);
		corners[6]=sides[1].pos.add(sides[2].vector).add(sides[4].vector);
		corners[1]=sides[0].pos.add(sides[3].vector).add(sides[5].vector);
		corners[7]=sides[1].pos.add(sides[3].vector).add(sides[5].vector);
		corners[2]=sides[1].pos.add(sides[4].vector).add(sides[3].vector);
		corners[3]=sides[1].pos.add(sides[5].vector).add(sides[2].vector);
		
	}
	public void setAll(Vector3D v,Vector3D rotation) {
	
	
	
		if(type == 1) {
	
		setRotate(rotation);
		translate(v.sub(center));
		
		}
		
	}
	private void translate(Vector3D dv) {
		center.addThis(dv);
		for(int i=0;i<6;i++) {
			sides[i].pos.addThis(dv);
		
		
		}
		for(int i=0;i<8;i++) {
			corners[i].addThis(dv);
		}
		
	}
	private void setRotate(Vector3D rotation) {
		setRotate(rotation.i,rotation.j,rotation.k);
		
	}
	
}
