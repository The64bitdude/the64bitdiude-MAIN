package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Sphere extends Ovel3D{

	public Sphere(Vector3D pos, float r, float rez, Color c) {
		super(pos, new Vector3D(r,r,r), rez, c);
		this.center=pos;
		// TODO Auto-generated constructor stub
	}





	
	

}
