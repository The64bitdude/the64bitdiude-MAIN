package systems.Shapes;


import java.util.Vector;

import systems.DoubleVector3D;
import systems.Vector3D;

public class Shape3D {
	public Vector<Triangle3D> triangles;
public Vector3D center;
public Vector3D currentRotation;
	public Shape3D() {
		triangles=new Vector<Triangle3D>();
center = new Vector3D(0,0,0);
currentRotation = new Vector3D(0,0,0);
	}
	public void add(Triangle3D t){
		
center.mulThis(triangles.size());
center.addThis(t.midPoint);
center.divThis(triangles.size()+1);
		triangles.add(t);
		
	}
	public void add(Shape3D t){
	
		center.mulThis(triangles.size());
		center.addThis(t.center.mul(t.triangles.size()));
		center.divThis(triangles.size()+t.triangles.size());
		
		triangles.addAll(t.triangles);
		
	}
	public void translateThis(float x,float y,float z) {
		center.addThis(x, y, z);
		for(Triangle3D t:triangles) {
			t.translateThis(x,y,z);
		}
	}
	public void translateThis(Vector3D v) {
		translateThis(v.i,v.j,v.k);
		
	}
	
	public Shape3D rotateThis(float roll, float pitch,float yaw) {
		return rotateThis(center,roll,pitch,yaw);
		
	}
	public Shape3D rotate(float roll, float pitch,float yaw) {
		return rotate(center,roll,pitch,yaw);
		
	}
	public Shape3D setRotationThis(float roll, float pitch,float yaw) {
	
		return rotateThis(new Vector3D(roll, pitch, yaw).sub(currentRotation));
	}
	
	private Shape3D rotateThis(Vector3D v) {
		// TODO Auto-generated method stub
		return rotateThis(v.i,v.j,v.k);
	}
	public Shape3D rotate(Vector3D o,float roll, float pitch,float yaw) {
		return this.clone().rotateThis(o,roll,pitch,yaw);
	}
	public float[][] getRotationMatrix(float rolla,float  pitcha,float yawa){
		double roll= Math.toRadians(rolla);
		double pitch= Math.toRadians(pitcha);
		double yaw=Math.toRadians(yawa);
		float cosa1=(float) Math.cos(roll);
		float sina1=(float) Math.sin(roll);
		float cosa2=(float) Math.cos(pitch);
		float sina2=(float) Math.sin(pitch);
		float cosa3=(float) Math.cos(yaw);
		float sina3=(float) Math.sin(yaw);
	
	
return new float[][]{new float[] {cosa3*cosa2,cosa3*sina2*sina1-sina3*cosa1,cosa3*sina2*cosa1+sina3*sina1},
	new float[]  {sina3*cosa2,sina3*sina2*sina1+cosa3*cosa1,sina3*sina2*cosa1-cosa3*sina1},
	new float[] {-sina2,cosa2*sina1,cosa2*cosa1}};
	}
	public Shape3D rotateThis(Vector3D o,float roll, float pitch,float yaw) {
		currentRotation.addThis((float)roll,(float)pitch,(float)yaw);
		applyRotationMatrix(o,getRotationMatrix(roll,pitch,yaw));
		
		return this;
	}
	public void applyRotationMatrix(Vector3D o, float[][] rotation) {
		for(Triangle3D t:triangles) {
			t.rotateThis(o,rotation);
		}
	}
	public Shape3D rezDiv2This() {
		Vector<Triangle3D> v=new Vector<Triangle3D>();
		for(Triangle3D t:triangles) {
			v.addAll(t.rezDiv2().triangles);
		}
		triangles=v;
		return this;
	}
	public Shape3D flipThis() {
		
		for(Triangle3D t:triangles) {
			t.flipThis();
		}
	
		return this;

	}
	public Vector<Triangle3D>  flip() {
		Vector<Triangle3D> v=new Vector<Triangle3D>();
		for(Triangle3D t:triangles) {
			v.add(t.flip());
		}
		return v;

	}
	public Vector<Triangle3D> rezdiv2(Vector<Triangle3D> start) {
		Vector<Triangle3D> out=new Vector<Triangle3D>();
		for(int i=0;i<start.size();i++) {
			out.addAll(start.get(i).rezDiv2().triangles);
		}
		return out;
	}
	public Shape3D rezdiv(int n) {
		Shape3D out=new Shape3D();
		Vector<Triangle3D> buf=this.triangles;
		for(int i=0;i<n;i++) {
			buf=rezdiv2(buf);
		}
		out.triangles=buf;
		return out;
	}
	public Shape3D rezdivThis(int n) {
		for(int i =0;i<n;i++) {
			rezDiv2This();
		}
		return this;
	}
	public Shape3D clone() {
		Shape3D out =new Shape3D();
	out.add(this);
		return out;
	}
	public void setCenter(Vector3D v) {
		center =v;
		
	}
	public void setPosition(Vector3D pos) {
		this.translateThis(pos.sub(center));
		
	}
	
	
}
