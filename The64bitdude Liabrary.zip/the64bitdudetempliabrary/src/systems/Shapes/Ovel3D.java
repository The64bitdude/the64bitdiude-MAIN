package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Ovel3D extends Shape3D{

	public Ovel3D(Vector3D pos,Vector3D r, float rez,Color c) {
		this(pos,r,rez,rez,c,0,360,0,360);
	}
	public Ovel3D(Vector3D pos,Vector3D r, float rez,float rez2,Color c) {
		this(pos,r,rez,rez2,c,0,360,0,360);
	}
	public Ovel3D(Vector3D pos,Vector3D r, float rez,float rez2,Color c,float angle1,float angle2,float angle3,float angle4) {
		super();
		if(rez%2!=0) {
			rez=rez-rez%2;
		}
		if(rez2%2!=0) {
			rez2=rez2-rez2%2;
		}
	
		float dO =360/rez;
		float dO2 =360/rez2;
		for(float i=angle1;i<angle2;i+=dO) {
			
			for(float j=angle3;j<angle4;j+=dO2) {
				float x= (float) (Math.sin(Math.toRadians(i))*Math.cos(Math.toRadians(j)));
				float y= (float) (Math.cos(Math.toRadians(i))*Math.cos(Math.toRadians(j)));
				float z= (float) Math.sin(Math.toRadians(j));
				float di=i+dO;
				float dj=j+dO2;
				float x2= (float) (Math.sin(Math.toRadians(di))*Math.cos(Math.toRadians(j)));
				float y2= (float) (Math.cos(Math.toRadians(di))*Math.cos(Math.toRadians(j)));
				float x3= (float) (Math.sin(Math.toRadians(di))*Math.cos(Math.toRadians(dj)));
				float y3= (float) (Math.cos(Math.toRadians(di))*Math.cos(Math.toRadians(dj)));
				float x4= (float) (Math.sin(Math.toRadians(i))*Math.cos(Math.toRadians(dj)));
				float y4= (float) (Math.cos(Math.toRadians(i))*Math.cos(Math.toRadians(dj)));
				float z2= (float) Math.sin(Math.toRadians(dj));
				if(z<z2) {
				add(new Rect3D(pos.add(r.i*x4,r.j*y4,r.k*z2),pos.add(r.i*x,r.j*y,r.k*z),pos.add(r.i*x2,r.j*y2,r.k*z),pos.add(r.i*x3,r.j*y3,r.k*z2),c));
				}
			
			}
		}
	}

	

}
