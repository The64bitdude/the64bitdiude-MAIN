package systems.Shapes;

import java.awt.Color;

import systems.Vector3D;

public class Point3D extends Shape3D{

	public Point3D(Vector3D pos,Color c) {
		super();
		add(new Triangle3D(c));
		this.triangles.get(0).addPoint(pos);
		this.triangles.get(0).addPoint(pos);
		this.triangles.get(0).midPoint=pos;

		}


}
