package systems;

public class Vector3D {
	public float i;
	public float j;
	public float k;
	public Vector3D(float x,float y,float z) {
		i=x;
		j=y;
		k=z;

	}
  
	public float dot(float x,float y,float z) {
		return i*x+j*y+k*z;
	}
	public float dot(Vector3D v) {
		return dot(v.i,v.j,v.k); 
	}
	public Vector3D cross(float x,float y,float z) {
		return new Vector3D(j*z-y*k, x*k-i*z, i*y-x*j);
	}
	public Vector3D cross(Vector3D v) {
		return cross(v.i,v.j,v.k);
	}
	public Vector3D reflect(float x,float y,float z) {
		return reflect(new Vector3D(x,y,z));
	}
	public Vector3D reflect(Vector3D v) {
		return sub(v.normalize().mul(2).mul(dot(v.normalize())));
	}
	public Vector3D add(float x,float y,float z) {
		return new Vector3D(i+x,j+y, k+z);
	}
	public Vector3D sub(float x,float y,float z) {
		return new Vector3D(i-x,j-y, k-z);
	}
	public Vector3D mul(float x,float y,float z) {
		return new Vector3D(i*x,j*y, k*z);
	}
	public Vector3D	div(float x,float y,float z) {
		return new Vector3D(i/x,j/y, k/z);
	}
	public Vector3D	add(float m) {
		return add(m,m,m);
	}
	public Vector3D	sub(float m) {
		return sub(m,m,m);
	}
	public Vector3D	mul(float m) {
		return mul(m,m,m);
	}
	public Vector3D	div(float m) {
		return div(m,m,m);
	}
	public Vector3D add(Vector3D v) {
		return add(v.i,v.j,v.k);
	}
	public Vector3D sub(Vector3D v) {
		return sub(v.i,v.j,v.k);
	}
	public Vector3D mul(Vector3D v) {
		return mul(v.i,v.j,v.k);
	}
	public Vector3D	div(Vector3D v) {
		return div(v.i,v.j,v.k);
	}
	public Vector3D normalize() {
		return div(mag());
	}
	public Vector3D normalize(float maxVal) {
		return normalize().mul(maxVal);
	}
	public Vector3D max(float x,float y,float z) {
		return new Vector3D(Math.max(x, i),Math.max(y, j),Math.max(z, k));
	}
	public Vector3D max(Vector3D v) {
		return max(v.i,v.j,v.k);
	}
	public Vector3D max(float m) {
		return max(m,m,m);
	}
	public Vector3D  min(float x,float y,float z) {
		return new Vector3D(Math.min(x, i),Math.min(y, j),Math.min(z, k));
	}
	public Vector3D min(Vector3D v) {
		return min(v.i,v.j,v.k);
	}
	public Vector3D min(float m) {
		return min(m,m,m);
	}
	public Vector3D  abs() {
		return new Vector3D(Math.abs(i),Math.abs(j),Math.abs(k));
	}
	
	public void crossThis(float x,float y,float z) {
	set(j*z-y*k, x*k-i*z, i*y-x*j);
	}
	public void crossThis(Vector3D v) {
		crossThis(v.i,v.j,v.k);
	}
	public void reflectThis(float x,float y,float z) {
		reflectThis(new Vector3D(x,y,z));
	}
	public void reflectThis(Vector3D v) {
		subThis(v.normalize().mul(2).mul(dot(v.normalize())));
	}
	public void addThis(float x,float y,float z) {
		i+=x;
		j+=y;
		k+=z;
	}
	public void subThis(float x,float y,float z) {
		i-=x;
		j-=y;
		k-=z;
	}
	public void mulThis(float x,float y,float z) {
		i*=x;
		j*=y;
		k*=z;
	}
	public void	divThis(float x,float y,float z) {
		i/=x;
		j/=y;
		k/=z;
	}
	public void modThis(float f) {
		i%=f;
		j%=f;
		k%=f;
		
	}
	public void modThis(float x,float y,float z) {
		i%=x;
		j%=y;
		k%=z;
		
	}
	public void	addThis(float m) {
		addThis(m,m,m);
	}
	public void	subThis(float m) {
		subThis(m,m,m);
	}
	public void	mulThis(float m) {
		mulThis(m,m,m);
	}
	public void	divThis(float m) {
		divThis(m,m,m);
	}
	public void addThis(Vector3D v) {
		addThis(v.i,v.j,v.k);
	}
	public void subThis(Vector3D v) {
		subThis(v.i,v.j,v.k);
	}
	public void mulThis(Vector3D v) {
		mulThis(v.i,v.j,v.k);
	}
	public void	divThis(Vector3D v) {
		divThis(v.i,v.j,v.k);
	}
	public void modThis(Vector3D v) {
		modThis(v.i,v.j,v.k);
		
	}
	public void normalizeThis() {
		divThis(mag());
	}
	public void normalizeThis(float maxVal) {
		normalizeThis();
		mulThis(maxVal);
	}
	public void maxThis(float x,float y,float z) {
		i=Math.max(x, i);
		j=Math.max(y, j);
		k=Math.max(z, k);
	}
	public void maxThis(Vector3D v) {
		maxThis(v.i,v.j,v.k);
	}
	public void maxThis(float m) {
		maxThis(m,m,m);
	}
	public void minThis(float x,float y,float z) {
		i=Math.min(x, i);
		j=Math.min(y, j);
		k=Math.min(z, k);
	}
	public void minThis(Vector3D v) {
		minThis(v.i,v.j,v.k);
	}
	public void minThis(float m) {
		minThis(m,m,m);
	}
	public void  absThis() {
	i=Math.abs(i);
	j=Math.abs(j);
	k=Math.abs(k);
	}
	
	public float mag() {
		return (float)Math.sqrt(magSqrd() );
	}
	public float mag3d2() {
		return (float)Math.pow(magSqrd(),3/2f );
	}
	public float magSqrd() {
		return dot(this);
	}
	public float magCubed() {
		return dot(this.mul(this));
	}
	public String toString() {
		return "[ "+i+"i + "+j+"j + "+ k+"k ]";
	}
	public boolean equals(Vector3D v) {
		// TODO Auto-generated method stub
		return equals(v.i,v.j,v.k);
	}
	public boolean equals(float x,float y,float z) {
		// TODO Auto-generated method stub
		return i==x&&j==y&&k==z;
	}
	public boolean iequals(Vector3D v) {
		// TODO Auto-generated method stub
		return equals(v)||equals(-v.i,-v.j,-v.k);
	}

	public void set(float x, float y, float z) {
		this.i=x;
		this.j=y;
		this.k=z;
		
	}
	

	public float dist(Vector3D midPoint) {
		// TODO Auto-generated method stub
		return sub(midPoint).mag();
	}

	public Vector3D inv() {
		// TODO Auto-generated method stub
		return mul(-1,-1,-1);
	}

	public float mag(float f) {
		return (float)Math.pow(magSqrd(),f );
	}

	public void set(Vector3D v) {
	set(v.i,v.j,v.k);
		
	}
	public Vector3D getRotation(float y,float p) {
		Vector3D forward=new Vector3D((float)(Math.cos(y)*Math.cos(p)), (float)(Math.sin(p)), (float)(Math.sin(y)*Math.cos(p)));
		Vector3D right = forward.cross( 0, 1, 0);
		Vector3D up = right.cross(forward);
		return new Vector3D((float)Math.atan2(right.dot( up),right.dot( forward)), (float)Math.asin(forward.j), (float)Math.atan2(-forward.k, forward.i));
	}
	public Vector3D matrixMul(float[][] fs) {
	
		return new Vector3D(i*fs[0][0]+j*fs[0][1]+k*fs[0][2]
		,i*fs[1][0]+j*fs[1][1]+k*fs[1][2],
		i*fs[2][0]+j*fs[2][1]+k*fs[2][2]);
	
	
	}


	



	
}
